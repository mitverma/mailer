export const environment = {
	production: false,
	firebase: {
		apiKey: "AIzaSyA3WZLxl63CKvzj4sIg2fZjOVaUYvtzrwY",
		authDomain: "chat-666d8.firebaseapp.com",
		databaseURL: "https://chat-666d8.firebaseio.com",
		projectId: "chat-666d8",
		storageBucket: "",
		messagingSenderId: "162204499457"
	}
};