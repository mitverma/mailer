  import { Component, ViewChild, NgZone } from '@angular/core';
  import { Nav, Platform, MenuController, AlertController,ToastController} from 'ionic-angular';
  import { StatusBar } from '@ionic-native/status-bar';
  import { SplashScreen } from '@ionic-native/splash-screen';
  import { AuthUser, DeviceInformation } from '../providers/entities/entities';
  import { FcmserviceProvider } from '../providers/fcmservice/fcmservice';
  import { AuthProvider } from '../providers/auth/auth'
  import { environment } from '../environment';
  import { Device } from '@ionic-native/device';
  import { Push, PushObject, PushOptions } from '@ionic-native/push';
  import { DevicestorageProvider } from '../providers/devicestorage/devicestorage';



  @Component({
    templateUrl: 'app.html'
  })
  export class MyApp {
    @ViewChild(Nav) nav: Nav;

    rootPage: any = 'RegisterPage';
    firebaseConfig: any;
    pages: Array<{title: string, component: any, image: string}>;
    notificationDrawer: any;
    notificationList: any = [];

    constructor(public menu: MenuController, public platform: Platform,
      public statusBar: StatusBar, public splashScreen: SplashScreen, 
      public User: AuthUser, public authService: AuthProvider,
      public device: Device, public push: Push, 
      public deviceInfo: DeviceInformation, public deviceStorage: DevicestorageProvider, 
      public alertCtrl: AlertController, public toastCtrl: ToastController, public ngZone: NgZone,
      public fcmService: FcmserviceProvider) {
      this.initializeApp();

      this.notificationDrawer = 'hide-notification';

      // used for an example of ngFor and navigation
      this.pages = [ 
      {
        title: 'My Profile',
        component: 'ProfilePage',
        image: 'profile.png',
      },{
        title: 'Home',
        component: 'HomePage',
        image: 'home-icon.png',
      },{
        title: 'Users list',
        component: 'UserlistPage',
        image: 'list.png',
      }
      ];

      this.notificationPermission();
      this.fcmService.initToken();
    }

    initializeApp() { 
      this.platform.ready().then(() => {
        // Okay, so the platform is ready and our plugins are available.
        // Here you can do any higher level native things you might need.
        this.statusBar.styleDefault();
        this.splashScreen.hide();

        console.log(this.User, 'user exact value after refresh');

        this.authService.ensureAuthenticate().then(user=>{
          if (user && user.uid) {
            Object.assign(this.User, user);
            this.menu.swipeEnable(true);
            this.nav.setRoot('HomePage');
          }else {
            this.menu.swipeEnable(false);
          }
        })
      });
      console.log(this.device, 'device info');
    }

    openPage(page) {
      // Reset the content nav to have just this page
      // we wouldn't want the back button to show in this scenario
      if (page.component == 'HomePage') {
        this.nav.setRoot(page.component);
      }else {
        this.nav.push(page.component);
      }
    }

    logOut(){
      this.authService.logout().then(()=>{
        this.nav.setRoot('RegisterPage');
        this.menu.close();
        this.menu.swipeEnable(false);
      }).catch(error=>{
        console.log(error, 'error');
      }); 
    }

    toggleNotification(){
      if (this.notificationDrawer == 'show-notification') {
        this.notificationDrawer = 'hide-notification';
      }else {
        this.notificationDrawer = 'show-notification';
      }
    }

    notificationPermission(){
      this.platform.ready().then(()=>{
        this.push.hasPermission().then((res: any)=>{
          if (res.isEnabled) {
            console.log('We have permission to send push notifications');
            const options: PushOptions = {
              android: {
                senderID: 'YOUR_SENDER_ID'
              },
              ios: {
                alert: 'true',
                badge: false,
                sound: 'true'
              },
              windows: {}
            };

            // init push
            const pushObject: PushObject = this.push.init(options);
            // init push end

            // device registration
            pushObject.on('registration').subscribe((data: any) => {
              if (data) {
                let deviceData = {
                  deviceToken: data.registrationId,
                  Platform : this.device.platform,
                  Version : this.device.version,
                  Uuid : this.device.uuid,
                  Model : this.device.model,
                  Serial : this.device.serial,
                }
                

                Object.assign(this.deviceInfo, deviceData);
                this.deviceStorage.setDeviceInfo(this.deviceInfo);
              }
            });
            // device registration end

            // notification received
            pushObject.on('notification').subscribe((data: any)=>{
              console.log(data, 'data notification');
              if (data.additionalData.foreground) {
                // this.notificationDrawer = 'show-notification';
                // this.ngZone.run((data)=>{
                  //   this.notificationDrawer = 'show-notification';
                  // })

                  // let notificationList = {
                    //   id: data.additionalData.from_userid ? data.additionalData.from_userid : '',
                    //   roomId: data.additionalData.roomId ? data.additionalData.roomId : '',
                    //   title: data.title,
                    //   message: data.message,
                    //   clickType: data.additionalData.click_action,
                    //   icon: data.additionalData.icon
                    // }

                    // if (this.notificationList.length) {
                      //   this.notificationList.forEach(list=>{
                        //     if ((list.id == notificationList.id) || (list.roomId == notificationList.roomId)) {
                          //       list.message = data.message;
                          //     }
                          //   })
                          // }else {
                            //   this.notificationList.push(notificationList);
                            // }


                            // setTimeout(()=>{
                              //   this.notificationDrawer = 'hide-notification';
                              //   this.ngZone.run((data)=>{
                                //     this.notificationDrawer = 'hide-notification';
                                //   })
                                // },4000);

                                // // toaster
                                let toastAlert = this.toastCtrl.create({
                                  message: data.message,
                                  duration: 2000,
                                  position: 'top',
                                  showCloseButton: true,
                                  dismissOnPageChange: true,
                                  closeButtonText: 'X',
                                  cssClass: 'notification-toaster'
                                });
                                toastAlert.present();

                                toastAlert.onDidDismiss(()=>{
                                });
                                // toaster end

                                // if application open, show popup
                                // let confirmAlert = this.alertCtrl.create({
                                  //   cssClass: "OneinsurePopup",
                                  //   title: data.title,
                                  //   message: data.message,

                                  // });
                                  // confirmAlert.present();
                                  // if application open, show popup end

                                  // close alert controller in 3 seconds
                                  // setTimeout(()=>{
                                    //   confirmAlert.dismiss();
                                    // }, 3000);
                                    // close alert controller in 3 seconds end


                                  }else {
                                    // for one to one chat
                                    if (data.additionalData.click_action == 'ChatPage') {
                                      this.nav.push(data.additionalData.click_action, {'id': data.additionalData.to_user_id, 'displayName': data.additionalData.displayName} );
                                    }
                                    // for one to one chat end

                                    // for room chat page 
                                    if (data.additionalData.click_action == 'RoomChatPage') {
                                      this.nav.push(data.additionalData.click_action, {'roomId': data.additionalData.roomId, 'displayName': data.additionalData.displayName} );
                                    }
                                    // for room chat page end
                                  }
                                });
  // notification received end
}
})
})
}
}
