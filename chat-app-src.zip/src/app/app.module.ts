import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { HttpClientModule  } from '@angular/common/http';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { RegisterPageModule } from '../pages/register/register.module';
import { AuthProvider } from '../providers/auth/auth';
import { AuthserviceProvider } from '../providers/authservice/authservice';
import { AuthUser, RoomDetail, MembersAndRooms,DeviceInformation,CopiedData } from '../providers/entities/entities';
import { DevicestorageProvider } from '../providers/devicestorage/devicestorage';
import { RoomserviceProvider } from '../providers/roomservice/roomservice';
import { UserServiceProvider } from '../providers/user-service/user-service';
import { MessageServiceProvider } from '../providers/message-service/message-service';
import { OrderByPipe } from '../pipes/filters/filters';

import * as firebase from 'firebase';
import { IonicStorageModule } from "@ionic/storage";
import { DatePipe } from '@angular/common';
import { File } from '@ionic-native/file';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { Clipboard } from '@ionic-native/clipboard';
import { InAppBrowser } from '@ionic-native/in-app-browser';
import { Device } from '@ionic-native/device';
import { Push, PushObject, PushOptions } from '@ionic-native/push';
import { FcmserviceProvider } from '../providers/fcmservice/fcmservice';


// export const config = {
  //   apiKey: "AIzaSyA3WZLxl63CKvzj4sIg2fZjOVaUYvtzrwY",
  //   authDomain: "chat-666d8.firebaseapp.com",
  //   databaseURL: "https://chat-666d8.firebaseio.com",
  //   projectId: "chat-666d8",
  //   storageBucket: "",
  //   messagingSenderId: "162204499457"
  // };
  export const config = {
    apiKey: "AIzaSyBRjdIf9S7z1yPGWzCaOt-Mc-GRoBNQn7k",
    authDomain: "salesapp-61b90.firebaseapp.com",
    databaseURL: "https://salesapp-61b90.firebaseio.com",
    projectId: "salesapp-61b90",
    storageBucket: "salesapp-61b90.firebaseapp.com",
    messagingSenderId: "1950497765"
  };

  firebase.initializeApp(config);
  export const messaging =  firebase.messaging();

  messaging.onMessage(function(payload) {
    console.log("Message received. ", payload);
    var notificationO = {};
    notificationO['title']=payload.notification.title;
    notificationO['body']=payload.notification.body;
    notificationO['badge']= payload.notification && payload.notification.badge ? payload.notification.badge : 'assets/imgs/chat-logo.png';
    notificationO['icon']= payload.notification && payload.notification.icon ? payload.notification.icon : 'assets/imgs/chat-logo.png';
    var nt = new Notification(notificationO['title'],notificationO);
  });


  @NgModule({
    declarations: [
    MyApp,
    ],
    imports: [
    BrowserModule,
    RegisterPageModule,
    HttpClientModule,
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot(),
    ],
    bootstrap: [IonicApp],
    entryComponents: [
    MyApp,
    ],
    providers: [  
    DatePipe,
    OrderByPipe,
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    AuthProvider,
    AuthserviceProvider,
    AuthUser,
    RoomDetail,
    MembersAndRooms,
    DeviceInformation,
    CopiedData,
    DevicestorageProvider,
    RoomserviceProvider,
    UserServiceProvider,
    MessageServiceProvider,
    File,
    FileTransfer,
    FileTransferObject,
    Camera,
    Clipboard,
    InAppBrowser,
    Device,
    Push,
    FcmserviceProvider
    ]
  })
  export class AppModule {}
