var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, ViewChild, NgZone } from '@angular/core';
import { Nav, Platform, MenuController, AlertController, ToastController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { AuthUser, DeviceInformation } from '../providers/entities/entities';
import { AuthProvider } from '../providers/auth/auth';
import { Device } from '@ionic-native/device';
import { Push } from '@ionic-native/push';
import { DevicestorageProvider } from '../providers/devicestorage/devicestorage';
var MyApp = /** @class */ (function () {
    function MyApp(menu, platform, statusBar, splashScreen, User, authService, device, push, deviceInfo, deviceStorage, alertCtrl, toastCtrl, ngZone) {
        this.menu = menu;
        this.platform = platform;
        this.statusBar = statusBar;
        this.splashScreen = splashScreen;
        this.User = User;
        this.authService = authService;
        this.device = device;
        this.push = push;
        this.deviceInfo = deviceInfo;
        this.deviceStorage = deviceStorage;
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
        this.ngZone = ngZone;
        this.rootPage = 'RegisterPage';
        this.notificationList = [];
        this.initializeApp();
        this.notificationDrawer = 'hide-notification';
        // used for an example of ngFor and navigation
        this.pages = [
            {
                title: 'My Profile',
                component: 'ProfilePage',
                image: 'profile.png',
            }, {
                title: 'Home',
                component: 'HomePage',
                image: 'home-icon.png',
            }, {
                title: 'Users list',
                component: 'UserlistPage',
                image: 'list.png',
            }
        ];
        this.notificationPermission();
    }
    MyApp.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            // Okay, so the platform is ready and our plugins are available.
            // Here you can do any higher level native things you might need.
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
            console.log(_this.User, 'user exact value after refresh');
            _this.authService.ensureAuthenticate().then(function (user) {
                if (user && user.uid) {
                    Object.assign(_this.User, user);
                    _this.menu.swipeEnable(true);
                    _this.nav.setRoot('HomePage');
                }
                else {
                    _this.menu.swipeEnable(false);
                }
            });
        });
        console.log(this.device, 'device info');
    };
    MyApp.prototype.openPage = function (page) {
        // Reset the content nav to have just this page
        // we wouldn't want the back button to show in this scenario
        if (page.component == 'HomePage') {
            this.nav.setRoot(page.component);
        }
        else {
            this.nav.push(page.component);
        }
    };
    MyApp.prototype.logOut = function () {
        var _this = this;
        this.authService.logout().then(function () {
            _this.nav.setRoot('RegisterPage');
            _this.menu.close();
            _this.menu.swipeEnable(false);
        }).catch(function (error) {
            console.log(error, 'error');
        });
    };
    MyApp.prototype.toggleNotification = function () {
        if (this.notificationDrawer == 'show-notification') {
            this.notificationDrawer = 'hide-notification';
        }
        else {
            this.notificationDrawer = 'show-notification';
        }
    };
    MyApp.prototype.notificationPermission = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.push.hasPermission().then(function (res) {
                if (res.isEnabled) {
                    console.log('We have permission to send push notifications');
                    var options = {
                        android: {
                            senderID: 'YOUR_SENDER_ID'
                        },
                        ios: {
                            alert: 'true',
                            badge: false,
                            sound: 'true'
                        },
                        windows: {}
                    };
                    // init push
                    var pushObject = _this.push.init(options);
                    // init push end
                    // device registration
                    pushObject.on('registration').subscribe(function (data) {
                        if (data) {
                            var deviceData = {
                                deviceToken: data.registrationId,
                                Platform: _this.device.platform,
                                Version: _this.device.version,
                                Uuid: _this.device.uuid,
                                Model: _this.device.model,
                                Serial: _this.device.serial,
                            };
                            Object.assign(_this.deviceInfo, deviceData);
                            _this.deviceStorage.setDeviceInfo(_this.deviceInfo);
                        }
                    });
                    // device registration end
                    // notification received
                    pushObject.on('notification').subscribe(function (data) {
                        console.log(data, 'data notification');
                        if (data.additionalData.foreground) {
                            // this.notificationDrawer = 'show-notification';
                            // this.ngZone.run((data)=>{
                            //   this.notificationDrawer = 'show-notification';
                            // })
                            // let notificationList = {
                            //   id: data.additionalData.from_userid ? data.additionalData.from_userid : '',
                            //   roomId: data.additionalData.roomId ? data.additionalData.roomId : '',
                            //   title: data.title,
                            //   message: data.message,
                            //   clickType: data.additionalData.click_action,
                            //   icon: data.additionalData.icon
                            // }
                            // if (this.notificationList.length) {
                            //   this.notificationList.forEach(list=>{
                            //     if ((list.id == notificationList.id) || (list.roomId == notificationList.roomId)) {
                            //       list.message = data.message;
                            //     }
                            //   })
                            // }else {
                            //   this.notificationList.push(notificationList);
                            // }
                            // setTimeout(()=>{
                            //   this.notificationDrawer = 'hide-notification';
                            //   this.ngZone.run((data)=>{
                            //     this.notificationDrawer = 'hide-notification';
                            //   })
                            // },4000);
                            // // toaster
                            var toastAlert = _this.toastCtrl.create({
                                message: data.message,
                                duration: 2000,
                                position: 'top',
                                showCloseButton: true,
                                dismissOnPageChange: true,
                                closeButtonText: 'X',
                                cssClass: 'notification-toaster'
                            });
                            toastAlert.present();
                            toastAlert.onDidDismiss(function () {
                            });
                            // toaster end
                            // if application open, show popup
                            // let confirmAlert = this.alertCtrl.create({
                            //   cssClass: "OneinsurePopup",
                            //   title: data.title,
                            //   message: data.message,
                            // });
                            // confirmAlert.present();
                            // if application open, show popup end
                            // close alert controller in 3 seconds
                            // setTimeout(()=>{
                            //   confirmAlert.dismiss();
                            // }, 3000);
                            // close alert controller in 3 seconds end
                        }
                        else {
                            // for one to one chat
                            if (data.additionalData.click_action == 'ChatPage') {
                                _this.nav.push(data.additionalData.click_action, { 'id': data.additionalData.to_user_id, 'displayName': data.additionalData.displayName });
                            }
                            // for one to one chat end
                            // for room chat page 
                            if (data.additionalData.click_action == 'RoomChatPage') {
                                _this.nav.push(data.additionalData.click_action, { 'roomId': data.additionalData.roomId, 'displayName': data.additionalData.displayName });
                            }
                            // for room chat page end
                        }
                    });
                    // notification received end
                }
            });
        });
    };
    __decorate([
        ViewChild(Nav),
        __metadata("design:type", Nav)
    ], MyApp.prototype, "nav", void 0);
    MyApp = __decorate([
        Component({
            templateUrl: 'app.html'
        }),
        __metadata("design:paramtypes", [MenuController, Platform,
            StatusBar, SplashScreen,
            AuthUser, AuthProvider,
            Device, Push,
            DeviceInformation, DevicestorageProvider,
            AlertController, ToastController, NgZone])
    ], MyApp);
    return MyApp;
}());
export { MyApp };
//# sourceMappingURL=app.component.js.map