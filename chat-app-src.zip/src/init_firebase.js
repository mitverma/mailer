var config = {
	apiKey: "AIzaSyBRjdIf9S7z1yPGWzCaOt-Mc-GRoBNQn7k",
	authDomain: "salesapp-61b90.firebaseapp.com",
	databaseURL: "https://salesapp-61b90.firebaseio.com",
	projectId: "salesapp-61b90",
	storageBucket: "salesapp-61b90.firebaseapp.com",
	messagingSenderId: "1950497765"
};
// var config = {
// 	apiKey: "AIzaSyA3WZLxl63CKvzj4sIg2fZjOVaUYvtzrwY",
// 	authDomain: "chat-666d8.firebaseapp.com",
// 	databaseURL: "https://chat-666d8.firebaseio.com",
// 	projectId: "chat-666d8",
// 	storageBucket: "",
// 	messagingSenderId: "162204499457"
// };
firebase.initializeApp(config);
const messaging=firebase.messaging();
messaging.onMessage(function(payload) {
	console.log("Message received. ", payload);
	var notificationO={};
	notificationO.title=payload.notification.title;
	notificationO.body=payload.notification.body;
	notificationO.badge=payload.notification.icon;
	notificationO.icon=payload.notification.icon;
	var nt = new Notification(notificationO.title,notificationO);
	//nt.onclikc=function(){alert('in')};

});

