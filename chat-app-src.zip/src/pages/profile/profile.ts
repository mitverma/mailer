import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { UserServiceProvider } from '../../providers/user-service/user-service';

/**
 * Generated class for the ProfilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

 @IonicPage()
 @Component({
 	selector: 'page-profile',
 	templateUrl: 'profile.html',
 })
 export class ProfilePage {
 	profileDetail: any;
 	userProfile: any;
 	constructor(public navCtrl: NavController, public navParams: NavParams, public userService: UserServiceProvider, public toastCtrl: ToastController) {
 		this.userProfile = {
 			displayName : '',
 			email: '',
 		}
 	}

 	ionViewDidLoad() {
 		console.log('ionViewDidLoad ProfilePage');
 		this.userService.getMemberDetails().then((data)=>{
 			if (data) {
 				this.profileDetail =  data;
 				this.userProfile.displayName = this.profileDetail.displayName;
 				this.userProfile.email = this.profileDetail.email;
 			}
 		})
 	}

 	updateProfileDetails(){
 		if (this.profileDetail.displayName != this.userProfile.displayName.trim() && this.userProfile.displayName.trim() != '') {
 			this.userService.updateProfile(this.userProfile.displayName).then((data)=>{
 				this.profileDetail.displayName = this.userProfile.displayName;
 				this.toaster();
 			})
 		} 		
 	}

 	toaster(){
 		const  toast = this.toastCtrl.create({
 			message: 'User name updated successfully',
 			duration: 3000
 		});
 		toast.present();
 	}

 }
