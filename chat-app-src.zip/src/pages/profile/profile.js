var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { UserServiceProvider } from '../../providers/user-service/user-service';
/**
 * Generated class for the ProfilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
var ProfilePage = /** @class */ (function () {
    function ProfilePage(navCtrl, navParams, userService, toastCtrl) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.userService = userService;
        this.toastCtrl = toastCtrl;
        this.userProfile = {
            displayName: '',
            email: '',
        };
    }
    ProfilePage.prototype.ionViewDidLoad = function () {
        var _this = this;
        console.log('ionViewDidLoad ProfilePage');
        this.userService.getMemberDetails().then(function (data) {
            if (data) {
                _this.profileDetail = data;
                _this.userProfile.displayName = _this.profileDetail.displayName;
                _this.userProfile.email = _this.profileDetail.email;
            }
        });
    };
    ProfilePage.prototype.updateProfileDetails = function () {
        var _this = this;
        if (this.profileDetail.displayName != this.userProfile.displayName.trim() && this.userProfile.displayName.trim() != '') {
            this.userService.updateProfile(this.userProfile.displayName).then(function (data) {
                _this.profileDetail.displayName = _this.userProfile.displayName;
                _this.toaster();
            });
        }
    };
    ProfilePage.prototype.toaster = function () {
        var toast = this.toastCtrl.create({
            message: 'User name updated successfully',
            duration: 3000
        });
        toast.present();
    };
    ProfilePage = __decorate([
        IonicPage(),
        Component({
            selector: 'page-profile',
            templateUrl: 'profile.html',
        }),
        __metadata("design:paramtypes", [NavController, NavParams, UserServiceProvider, ToastController])
    ], ProfilePage);
    return ProfilePage;
}());
export { ProfilePage };
//# sourceMappingURL=profile.js.map