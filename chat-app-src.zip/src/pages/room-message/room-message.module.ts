import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RoomMessagePage } from './room-message';

@NgModule({
	declarations: [
	RoomMessagePage,
	],
	imports: [
	IonicPageModule.forChild(RoomMessagePage),
	],
	entryComponents: [
	RoomMessagePage
	],
	exports: [
	RoomMessagePage
	]
})
export class RoomMessagePageModule {}
