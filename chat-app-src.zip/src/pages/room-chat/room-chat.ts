import { Component, NgZone } from '@angular/core';
import { IonicPage, NavController, NavParams, Events,AlertController  } from 'ionic-angular';
import { MessageServiceProvider } from '../../providers/message-service/message-service';
import { AuthUser,RoomDetail, CopiedData } from '../../providers/entities/entities';
import { RoomserviceProvider } from  '../../providers/roomservice/roomservice';
import { UserServiceProvider } from '../../providers/user-service/user-service';
import { Clipboard } from '@ionic-native/clipboard'; 
import { InAppBrowser } from '@ionic-native/in-app-browser';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { OrderByPipe } from '../../pipes/filters/filters';

/**
 * Generated class for the RoomChatPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.`
 */

 @IonicPage()
 @Component({
 	selector: 'page-room-chat',
 	templateUrl: 'room-chat.html' 
 })
 export class RoomChatPage {

 	roomChatList: any = [];
 	formMessage: any = {};
 	roomInfo: any = {};
 	groupMemberList: any = [];
 	viewGroupList: boolean = false;
 	remaningUserList: any = [];
 	selectedMemberList: any = [];
 	currentIndex: any = -1;
 	viewMemberSection: boolean = true;
 	viewAddMemberSection: boolean = false;
 	fullImageView: boolean = false;
 	imageViewData: any;
 	copiedText: any;
 	viewCopyArea: boolean = false;
 	selectedIndex: any;
 	uploadUrlPath: any;
 	searchremaningUserList: any = [];
 	searchgroupMemberList: any = [];
 	searchModel: any = '';
 	messageLoadIndex: number = 20;
 	loadforFirstTime: boolean = true;
 	constructor(public navCtrl: NavController, public navParams: NavParams, public messageService: MessageServiceProvider, public User: AuthUser, public events: Events, public ngZone: NgZone, public roomDetail: RoomDetail, public roomService: RoomserviceProvider, public userService: UserServiceProvider, public alertCtrl: AlertController, public clipboard: Clipboard, public camera: Camera, public inAppBrowser: InAppBrowser, public transfer: FileTransfer, public orderBy: OrderByPipe, public copiedData: CopiedData) {
 		// image view data
 		this.imageViewData = {
 			imgUrl: '',
 			text: '',
 		}
 		// image view data end

 		this.formMessage = {
 			text: ''
 		}

 		this.uploadUrlPath = 'https://www.oneinsure.com/onegolive/api/Profile/SaveUploadedData';
 	}

 	ionViewDidLoad() {
 		if (this.navParams.data) {
 			this.roomInfo = this.navParams.data;
 		}
 		let roomId = this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
 		this.messageService.setUpGroupMessageListiner(roomId).then(res=>{
 			if (res && res.length) {
 				this.getGroupMessage().then(()=>{
 					if (document.querySelector('.roomchat-content')) {
 						let element = document.querySelector('.roomchat-content').children[1];
 						if (element) {						
 							element.scrollTop = element.scrollHeight;
 						}
 					}
 				});
 			}
 		});

 		this.events.subscribe('groupMessage:Added', (groupMsg) =>{
 			if (groupMsg) {
 				this.getGroupMessage();
 			}
 		});
 		

 		// javascript get clipboard event listener
 		let textarea = document.querySelector('.group-textarea');
 		if (textarea) {
 			textarea.addEventListener('paste', (event)=>{
 				if (event) {
 					this.formMessage.imgUrl =  this.copiedData.imgUrl ? this.copiedData.imgUrl : '';
 				}
 			})
 		}

 		// javascript get clipboard event listener end
 	}


 	// alert remove member to delete
 	confirmRemoveMember(memberDetail){
 		const alertRemoveMem = this.alertCtrl.create({
 			message: "Are you sure you want to remove this member from group",
 			buttons: [
 			{
 				text: 'Yes',
 				handler: data => {
 					this.removeMember(memberDetail);
 				}
 			},
 			{
 				text: 'No',
 				handler: data => {

 				}
 			}
 			]

 		});
 		alertRemoveMem.present();
 	}
 	// alert remove member to delete end

 	getGroupMessage(): Promise<any>{
 		let promise = new Promise((resolve, reject)=>{
 			let roomId =  this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
 			this.messageService.bindGroupMessages(roomId,this.messageLoadIndex).then((res)=>{
 				if (res) {
 					let chatMsgArray = [];
 					res.forEach((chatMsg)=>{
 						chatMsg.createdAt = new Date(chatMsg.createdAt);
 						chatMsgArray.push(chatMsg);
 					})
 					this.roomChatList = chatMsgArray;
 					setTimeout(()=>{
 						this.ngZone.run(()=>{
 							this.roomChatList = chatMsgArray;
 							resolve();
 							// if (document.querySelector('.roomchat-content') && this.loadforFirstTime) {
 								// 	let element = document.querySelector('.roomchat-content').children[1];
 								// 	if (element) {						
 									// 		element.scrollTop = element.scrollHeight;
 									// 		this.scrollToBottom(element).then(()=>{
 										// 			this.loadforFirstTime = false;
 										// 			resolve();
 										// 		})
 										// 	}
 										// }else{
 											// 	resolve();
 											// }
 										})
 						
 						this.messageLoadIndex+=20;						
 					},500);
 				}
 			});
 		});
 		return promise;
 	}

 	sendGroupMsg(formMessage){
 		// text area clear height to defualt
 		let textareaElement = document.getElementById('form-textarea');
 		textareaElement.style.height = '40px';
 		// text area clear height to defualt end

 		let roomId =  this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
 		let roomNameTitle = this.roomInfo.name ? this.roomInfo.name: this.roomDetail.name;
 		let imgUrl =  formMessage.imgUrl ? formMessage.imgUrl: '';
 		formMessage.imgUrl = imgUrl;
 		this.messageService.sendGroupMessage(roomId, formMessage, roomNameTitle).then(()=>{
 			this.formMessage.text = '';
 			// this.formMessage = {};
 			this.getGroupMessage().then(()=>{
 				setTimeout(()=>{
 					if (document.querySelector('.roomchat-content')) {
 						let element = document.querySelector('.roomchat-content').children[1];
 						if (element) {						
 							element.scrollTop = element.scrollHeight;
 						}
 					}
 				}, 500);
 			});
 		});
 	}

 	groupInfo(){
 		this.viewGroupList = true;
 		let roomId =  this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
 		this.roomService.getMemberInRoom(roomId).then((res)=>{
 			if (res) {
 				this.groupMemberList = res;

 				this.orderBy.transform(this.groupMemberList, ['+name']);

 				this.searchgroupMemberList = res;
 				// get user list
 				this.getUserList();
 				// get user list end
 			}
 		});
 	}

 	// remove member
 	removeMember(memberInfo){
 		let roomId = this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
 		let memberId = memberInfo ? memberInfo.id : '';
 		this.roomService.deleteRoomMember(roomId,memberId).then((res)=>{
 			// splice Array
 			var index = this.groupMemberList.indexOf(memberInfo);
 			if (index > -1) {
 				this.groupMemberList.splice(index, 1);

 				this.ngZone.run(data=>{
 					this.groupMemberList = this.groupMemberList;
 				});

 				// close group info list
 				this.viewGroupList = false;
 				// close group info list end

 			}
 		});
 	}
 	// remove member end


 	// get remaining user list not present in group
 	getUserList(){
 		this.userService.loadUsers().then((userlist)=>{
 			this.groupMemberList.forEach((groupMember)=>{
 				userlist.forEach((list, index)=>{
 					if (list.id == groupMember.id) {
 						userlist.splice(index, 1);
 					}
 				})
 			});
 			this.remaningUserList = userlist;

 			this.orderBy.transform(this.remaningUserList, ['+email']);
 			this.searchremaningUserList = userlist;
 			this.ngZone.run(data=>{
 				this.remaningUserList = userlist;
 				this.searchremaningUserList = userlist;
 			})
 		});
 	}
 	// get remaining user list not present in group end

 	// add members to group
 	addMemberGroup(){
 		let membersToAdd : any =[];
 		membersToAdd = this.selectedMemberList && this.selectedMemberList.length ?  this.selectedMemberList : [];
 		let roomId = this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
 		this.roomService.addMemberToGroup(membersToAdd, roomId).then((data)=>{
 			// console.log(data, 'data');
 			this.selectedMemberList = [];
 			if (data) {
 				data.forEach((member)=>{
 					if (member) {
 						this.groupMemberList.push(member);

 						this.ngZone.run(data=>{
 							this.groupMemberList = this.groupMemberList;
 						})

 						// close group info list
 						this.viewGroupList = false;
 						// close group info list end

 						// on set view member group info list
 						this.toggleViewList('viewMember');
 						// on set view member group info list end

 					}
 				})
 			}
 		});
 	}
 	// add members to group end


 	// select members to add to group
 	createMemList(member){
 		console.log(member, 'member');
 		if (this.selectedMemberList.length) {
 			this.currentIndex = this.selectedMemberList.indexOf(member);
 		}
 		if (this.currentIndex !== -1 ) {
 			this.selectedMemberList.splice(this.currentIndex, 1);
 		}else {
 			this.selectedMemberList.push(member);
 		}
 		this.currentIndex = -1;
 	}
 	// select members to add to group end


 	// toggle function for remove view member and add members 
 	toggleViewList(type){
 		this.searchModel = ''
 		if (type == 'viewMember') {
 			this.viewMemberSection = true;
 			this.viewAddMemberSection = false;
 			this.groupMemberList = this.searchgroupMemberList;
 			this.orderBy.transform(this.groupMemberList, ['+email']);
 			// remove selected list
 			this.selectedMemberList = [];
 			// remove selected list end
 		}
 		if (type == 'viewAddMembers') {
 			this.viewAddMemberSection = true;
 			this.viewMemberSection = false;
 			this.remaningUserList = this.searchremaningUserList;
 			
 			this.remaningUserList = this.remaningUserList.sort((a,b)=>{
 				a.email = a.email.toLowerCase();
 				b.email = b.email.toLowerCase();
 				if (a.email < b.email) {
 					return -1;
 				}
 				if (a.email > b.email) {
 					return 1;
 				}
 				return 0;
 			});
 		}
 	}
 	// toggle function for remove view member and add members using end

 	// full view image and close functions
 	viewFullImage(imageViewDetails){
 		this.fullImageView = true;
 		this.imageViewData.imgUrl =  imageViewDetails.imgUrl;
 		this.imageViewData.text =  imageViewDetails.content;
 		this.imageViewData.name =  imageViewDetails.sender_username ? imageViewDetails.sender_username : imageViewDetails.sender_email;
 		this.imageViewData.createdAt =  imageViewDetails.createdAt;

 	}
 	closeFullImageView(){
 		this.fullImageView = false;
 		this.imageViewData = {};
 	}

 	// full view image and close functions end

 	// copy text and clear text and long press
 	longPress(chatObj, index){
 		if (chatObj.text) {
 			this.viewCopyArea = true;
 			this.copiedText = chatObj.text;
 			this.selectedIndex = index;

 			// copied data
 			this.copiedData.text = chatObj.text;
 			this.copiedData.imgUrl = chatObj.imgUrl ? chatObj.imgUrl: '';
 			Object.assign(this.copiedData, this.copiedData);
 			// copied data end
 		}
 	}

 	copyText(){
 		this.clipboard.copy(this.copiedText);
 		this.viewCopyArea = false;
 		this.selectedIndex = -1;
 	}

 	clearCopyText(){
 		this.clipboard.clear();
 		this.viewCopyArea = false;
 		this.selectedIndex = -1;
 	}
 	// copy text and clear text and long press end


 	// textarea key down 
 	chatKeyDown(event){
 		if (event && event.target) {
 			event.target.style.height = event.target.scrollHeight;
 			event.target.style.cssText = 'height: 40px';
 			event.target.style.cssText = 'height: ' + event.target.scrollHeight + 'px';
 		}
 	}
 	// textarea key down end


 	// view file in InAppBrowser
 	viewFileInBrowser(file){
 		let fileTypeArray = file.split('.');
 		let fileType = fileTypeArray[fileTypeArray.length - 1];
 		if (fileType == 'pdf' || fileType == 'docx' || fileType == 'xlsx') {
 			file = "https://docs.google.com/gview?embedded=true&url=" + encodeURIComponent(file);	
 		}
 		const browser = this.inAppBrowser.create(file);
 	}
 	// view file in InAppBrowser end

 	uploadFile(fileUpload){
 		let filetypeArray = fileUpload.split('.');
 		let fileFormatType = filetypeArray ?  filetypeArray[1] : 'jpg';
 		fileFormatType = fileFormatType.toLocaleLowerCase();

 		// file upload name
 		let fileArray = fileUpload.split('/');
 		let getFileNameData = fileArray ? fileArray[fileArray.length - 1]: '';
 		let getFileName = getFileNameData.split('.')[0];
 		// file upload name end

 		const fileTransfer: FileTransferObject = this.transfer.create();
 		let currentDateTime = new Date();
 		const uploadUrl = this.uploadUrlPath;
 		let options: FileUploadOptions = {
 			fileKey: 'file',
 			fileName: this.User.id + currentDateTime.valueOf()+ getFileName + (fileFormatType ? '.'+fileFormatType : '.jpg'),
 			mimeType: "image/jpeg",
 			headers: {
 				fileName: this.User.id + currentDateTime.valueOf()+ getFileName + (fileFormatType ? '.'+fileFormatType : '.jpg'),
 				UserId: this.User.id
 			},
 		}
 		fileTransfer.upload(fileUpload,uploadUrl, options).then((data)=>{
 			// console.log(data, 'data');
 			let imgUrlFirebase = 'https://www.oneinsure.com/onegolive/Content/UploadedDataSaved/' + options.fileName;
 			this.uploadImageSendMessage(imgUrlFirebase, getFileName);
 		}).catch(error=>{
 			// console.log(error, 'error');
 		});
 	}

 	imageUpload(){
 		const options: CameraOptions = {

 			quality: 100,
 			destinationType: this.camera.DestinationType.FILE_URI,
 			encodingType: this.camera.EncodingType.JPEG,
 			mediaType: 2, // media type 2 allow allow media type
 			targetWidth: 1080, 
 			targetHeight: 1092,
 			saveToPhotoAlbum: false,
 			sourceType: 0,
 			correctOrientation: true,
 		}

 		this.camera.getPicture(options).then((data)=>{
 			if (data) {
 				this.uploadFile(data);
 			}
 		})
 	}


 	// uploadimage send message
 	uploadImageSendMessage(uploadedImgurl, fileName){		
 		if (uploadedImgurl) {
 			let messageObj = {
 				text : fileName,
 				imgUrl: uploadedImgurl
 			}
 			this.sendGroupMsg(messageObj);
 		}
 	}
 	// uploadimage send message end

 	// search bar 
 	// members to add 
 	searchUserList(event){
 		const val = event.target.value;
 		if (val && val.trim() != '') {
 			this.remaningUserList = this.searchremaningUserList.filter((item) => {
 				if (item && item.email) { 					
 					return (item.email.toLowerCase().indexOf(val.toLowerCase()) > -1);
 				}
 				else {

 					return this.remaningUserList;
 				}
 			})
 		}else {
 			this.remaningUserList = this.searchremaningUserList;
 		}
 	} 
 	// members to add end

 	// search group member list
 	searchGroupMemList(event){
 		const val = event.target.value;
 		if (val && val.trim() != '') {
 			this.groupMemberList = this.searchgroupMemberList.filter((item) => {
 				if (item && item.displayName) { 					
 					return (item.displayName.toLowerCase().indexOf(val.toLowerCase()) > -1);
 				}
 				else {
 					return this.groupMemberList;
 				}
 			})
 		}else {
 			this.groupMemberList = this.searchgroupMemberList;
 		}
 	}
 	// search group member list end
 	// search bar end


 	
 	doInfinite(event){
 		this.getGroupMessage().then(()=>{
 			event.complete();
 			event.state = 'enabled';
 		});
 	}


 	scrollToBottom(element): Promise<any>{
 		let promise = new Promise((resolve, reject)=>{
 			setTimeout(()=>{
 				element.scrollTop = element.scrollHeight;
 				resolve();
 			}, 1000);
 		});
 		return promise;
 	}

 	// on close remove member selected list
 	removeSelectedList(){
 		this.selectedMemberList = [];
 	}
 	// on close remove member selected list end
 }
