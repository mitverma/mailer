var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, NgZone } from '@angular/core';
import { IonicPage, NavController, NavParams, Events, AlertController } from 'ionic-angular';
import { MessageServiceProvider } from '../../providers/message-service/message-service';
import { AuthUser, RoomDetail } from '../../providers/entities/entities';
import { RoomserviceProvider } from '../../providers/roomservice/roomservice';
import { UserServiceProvider } from '../../providers/user-service/user-service';
import { Clipboard } from '@ionic-native/clipboard';
import { InAppBrowser } from '@ionic-native/in-app-browser';
import { Camera } from '@ionic-native/camera';
import { FileTransfer } from '@ionic-native/file-transfer';
import { OrderByPipe } from '../../pipes/filters/filters';
/**
 * Generated class for the RoomChatPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.`
 */
var RoomChatPage = /** @class */ (function () {
    function RoomChatPage(navCtrl, navParams, messageService, User, events, ngZone, roomDetail, roomService, userService, alertCtrl, clipboard, camera, inAppBrowser, transfer, orderBy) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.messageService = messageService;
        this.User = User;
        this.events = events;
        this.ngZone = ngZone;
        this.roomDetail = roomDetail;
        this.roomService = roomService;
        this.userService = userService;
        this.alertCtrl = alertCtrl;
        this.clipboard = clipboard;
        this.camera = camera;
        this.inAppBrowser = inAppBrowser;
        this.transfer = transfer;
        this.orderBy = orderBy;
        this.roomChatList = [];
        this.formMessage = {};
        this.roomInfo = {};
        this.groupMemberList = [];
        this.viewGroupList = false;
        this.remaningUserList = [];
        this.selectedMemberList = [];
        this.currentIndex = -1;
        this.viewMemberSection = true;
        this.viewAddMemberSection = false;
        this.fullImageView = false;
        this.viewCopyArea = false;
        this.searchremaningUserList = [];
        this.searchgroupMemberList = [];
        this.searchModel = '';
        this.messageLoadIndex = 20;
        this.loadforFirstTime = true;
        // image view data
        this.imageViewData = {
            imgUrl: '',
            text: '',
        };
        // image view data end
        this.formMessage = {
            text: ''
        };
        this.uploadUrlPath = 'https://www.oneinsure.com/onegolive/api/Profile/SaveUploadedData';
    }
    RoomChatPage.prototype.ionViewDidLoad = function () {
        var _this = this;
        if (this.navParams.data) {
            this.roomInfo = this.navParams.data;
        }
        var roomId = this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
        this.messageService.setUpGroupMessageListiner(roomId).then(function (res) {
            if (res && res.length) {
                _this.getGroupMessage().then(function () {
                    if (document.querySelector('.roomchat-content')) {
                        var element = document.querySelector('.roomchat-content').children[1];
                        if (element) {
                            element.scrollTop = element.scrollHeight;
                        }
                    }
                });
            }
        });
        this.events.subscribe('groupMessage:Added', function (groupMsg) {
            if (groupMsg) {
                _this.getGroupMessage();
            }
        });
    };
    // alert remove member to delete
    RoomChatPage.prototype.confirmRemoveMember = function (memberDetail) {
        var _this = this;
        var alertRemoveMem = this.alertCtrl.create({
            message: "Are you sure you want to remove this member from group",
            buttons: [
                {
                    text: 'Yes',
                    handler: function (data) {
                        _this.removeMember(memberDetail);
                    }
                },
                {
                    text: 'No',
                    handler: function (data) {
                    }
                }
            ]
        });
        alertRemoveMem.present();
    };
    // alert remove member to delete end
    RoomChatPage.prototype.getGroupMessage = function () {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            var roomId = _this.roomInfo.roomId ? _this.roomInfo.roomId : _this.roomDetail.roomId;
            _this.messageService.bindGroupMessages(roomId, _this.messageLoadIndex).then(function (res) {
                if (res) {
                    var chatMsgArray_1 = [];
                    res.forEach(function (chatMsg) {
                        chatMsg.createdAt = new Date(chatMsg.createdAt);
                        chatMsgArray_1.push(chatMsg);
                    });
                    _this.roomChatList = chatMsgArray_1;
                    setTimeout(function () {
                        _this.ngZone.run(function () {
                            _this.roomChatList = chatMsgArray_1;
                            resolve();
                            // if (document.querySelector('.roomchat-content') && this.loadforFirstTime) {
                            // 	let element = document.querySelector('.roomchat-content').children[1];
                            // 	if (element) {						
                            // 		element.scrollTop = element.scrollHeight;
                            // 		this.scrollToBottom(element).then(()=>{
                            // 			this.loadforFirstTime = false;
                            // 			resolve();
                            // 		})
                            // 	}
                            // }else{
                            // 	resolve();
                            // }
                        });
                        _this.messageLoadIndex += 20;
                    }, 500);
                }
            });
        });
        return promise;
    };
    RoomChatPage.prototype.sendGroupMsg = function (formMessage) {
        var _this = this;
        // text area clear height to defualt
        var textareaElement = document.getElementById('form-textarea');
        textareaElement.style.height = '40px';
        // text area clear height to defualt end
        var roomId = this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
        var roomNameTitle = this.roomInfo.name ? this.roomInfo.name : this.roomDetail.name;
        var imgUrl = formMessage.imgUrl ? formMessage.imgUrl : '';
        formMessage.imgUrl = imgUrl;
        this.messageService.sendGroupMessage(roomId, formMessage, roomNameTitle).then(function () {
            _this.formMessage.text = '';
            // this.formMessage = {};
            _this.getGroupMessage().then(function () {
                setTimeout(function () {
                    if (document.querySelector('.roomchat-content')) {
                        var element = document.querySelector('.roomchat-content').children[1];
                        if (element) {
                            element.scrollTop = element.scrollHeight;
                        }
                    }
                }, 500);
            });
        });
    };
    RoomChatPage.prototype.groupInfo = function () {
        var _this = this;
        this.viewGroupList = true;
        var roomId = this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
        this.roomService.getMemberInRoom(roomId).then(function (res) {
            if (res) {
                _this.groupMemberList = res;
                _this.orderBy.transform(_this.groupMemberList, ['+name']);
                _this.searchgroupMemberList = res;
                // get user list
                _this.getUserList();
                // get user list end
            }
        });
    };
    // remove member
    RoomChatPage.prototype.removeMember = function (memberInfo) {
        var _this = this;
        var roomId = this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
        var memberId = memberInfo ? memberInfo.id : '';
        this.roomService.deleteRoomMember(roomId, memberId).then(function (res) {
            // splice Array
            var index = _this.groupMemberList.indexOf(memberInfo);
            if (index > -1) {
                _this.groupMemberList.splice(index, 1);
                _this.ngZone.run(function (data) {
                    _this.groupMemberList = _this.groupMemberList;
                });
                // close group info list
                _this.viewGroupList = false;
                // close group info list end
            }
        });
    };
    // remove member end
    // get remaining user list not present in group
    RoomChatPage.prototype.getUserList = function () {
        var _this = this;
        this.userService.loadUsers().then(function (userlist) {
            _this.groupMemberList.forEach(function (groupMember) {
                userlist.forEach(function (list, index) {
                    if (list.id == groupMember.id) {
                        userlist.splice(index, 1);
                    }
                });
            });
            _this.remaningUserList = userlist;
            _this.orderBy.transform(_this.remaningUserList, ['+email']);
            _this.searchremaningUserList = userlist;
            _this.ngZone.run(function (data) {
                _this.remaningUserList = userlist;
                _this.searchremaningUserList = userlist;
            });
        });
    };
    // get remaining user list not present in group end
    // add members to group
    RoomChatPage.prototype.addMemberGroup = function () {
        var _this = this;
        var membersToAdd = [];
        membersToAdd = this.selectedMemberList && this.selectedMemberList.length ? this.selectedMemberList : [];
        var roomId = this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
        this.roomService.addMemberToGroup(membersToAdd, roomId).then(function (data) {
            // console.log(data, 'data');
            _this.selectedMemberList = [];
            if (data) {
                data.forEach(function (member) {
                    if (member) {
                        _this.groupMemberList.push(member);
                        _this.ngZone.run(function (data) {
                            _this.groupMemberList = _this.groupMemberList;
                        });
                        // close group info list
                        _this.viewGroupList = false;
                        // close group info list end
                        // on set view member group info list
                        _this.toggleViewList('viewMember');
                        // on set view member group info list end
                    }
                });
            }
        });
    };
    // add members to group end
    // select members to add to group
    RoomChatPage.prototype.createMemList = function (member) {
        if (this.selectedMemberList.length) {
            this.currentIndex = this.selectedMemberList.indexOf(member);
        }
        if (this.currentIndex !== -1) {
            this.selectedMemberList.splice(this.currentIndex, 1);
        }
        else {
            this.selectedMemberList.push(member);
        }
        this.currentIndex = -1;
    };
    // select members to add to group end
    // toggle function for remove view member and add members 
    RoomChatPage.prototype.toggleViewList = function (type) {
        this.searchModel = '';
        if (type == 'viewMember') {
            this.viewMemberSection = true;
            this.viewAddMemberSection = false;
            this.groupMemberList = this.searchgroupMemberList;
            this.orderBy.transform(this.groupMemberList, ['+email']);
        }
        if (type == 'viewAddMembers') {
            this.viewAddMemberSection = true;
            this.viewMemberSection = false;
            this.remaningUserList = this.searchremaningUserList;
            this.remaningUserList = this.remaningUserList.sort(function (a, b) {
                a.email = a.email.toLowerCase();
                b.email = b.email.toLowerCase();
                if (a.email < b.email) {
                    return -1;
                }
                if (a.email > b.email) {
                    return 1;
                }
                return 0;
            });
        }
    };
    // toggle function for remove view member and add members using end
    // full view image and close functions
    RoomChatPage.prototype.viewFullImage = function (imageViewDetails) {
        this.fullImageView = true;
        this.imageViewData.imgUrl = imageViewDetails.imgUrl;
        this.imageViewData.text = imageViewDetails.content;
        this.imageViewData.name = imageViewDetails.sender_username ? imageViewDetails.sender_username : imageViewDetails.sender_email;
        this.imageViewData.createdAt = imageViewDetails.createdAt;
    };
    RoomChatPage.prototype.closeFullImageView = function () {
        this.fullImageView = false;
        this.imageViewData = {};
    };
    // full view image and close functions end
    // copy text and clear text and long press
    RoomChatPage.prototype.longPress = function (text, index) {
        if (text) {
            this.viewCopyArea = true;
            this.copiedText = text;
            this.selectedIndex = index;
        }
    };
    RoomChatPage.prototype.copyText = function () {
        var copy = {
            text: this.copiedText,
            img: 'testing',
        };
        console.log(copy, 'copy');
        this.clipboard.copy(this.copiedText);
        this.viewCopyArea = false;
        this.selectedIndex = -1;
    };
    RoomChatPage.prototype.clearCopyText = function () {
        this.clipboard.clear();
        this.viewCopyArea = false;
        this.selectedIndex = -1;
    };
    // copy text and clear text and long press end
    // textarea key down 
    RoomChatPage.prototype.chatKeyDown = function (event) {
        if (event && event.target) {
            event.target.style.height = event.target.scrollHeight;
            event.target.style.cssText = 'height: 40px';
            event.target.style.cssText = 'height: ' + event.target.scrollHeight + 'px';
        }
    };
    // textarea key down end
    // view file in InAppBrowser
    RoomChatPage.prototype.viewFileInBrowser = function (file) {
        var fileTypeArray = file.split('.');
        var fileType = fileTypeArray[fileTypeArray.length - 1];
        if (fileType == 'pdf' || fileType == 'docx' || fileType == 'xlsx') {
            file = "https://docs.google.com/gview?embedded=true&url=" + encodeURIComponent(file);
        }
        var browser = this.inAppBrowser.create(file);
    };
    // view file in InAppBrowser end
    RoomChatPage.prototype.uploadFile = function (fileUpload) {
        var _this = this;
        var filetypeArray = fileUpload.split('.');
        var fileFormatType = filetypeArray ? filetypeArray[1] : 'jpg';
        fileFormatType = fileFormatType.toLocaleLowerCase();
        // file upload name
        var fileArray = fileUpload.split('/');
        var getFileNameData = fileArray ? fileArray[fileArray.length - 1] : '';
        var getFileName = getFileNameData.split('.')[0];
        // file upload name end
        var fileTransfer = this.transfer.create();
        var currentDateTime = new Date();
        var uploadUrl = this.uploadUrlPath;
        var options = {
            fileKey: 'file',
            fileName: this.User.id + currentDateTime.valueOf() + getFileName + (fileFormatType ? '.' + fileFormatType : '.jpg'),
            mimeType: "image/jpeg",
            headers: {
                fileName: this.User.id + currentDateTime.valueOf() + getFileName + (fileFormatType ? '.' + fileFormatType : '.jpg'),
                UserId: this.User.id
            },
        };
        fileTransfer.upload(fileUpload, uploadUrl, options).then(function (data) {
            // console.log(data, 'data');
            var imgUrlFirebase = 'https://www.oneinsure.com/onegolive/Content/UploadedDataSaved/' + options.fileName;
            _this.uploadImageSendMessage(imgUrlFirebase, getFileName);
        }).catch(function (error) {
            // console.log(error, 'error');
        });
    };
    RoomChatPage.prototype.imageUpload = function () {
        var _this = this;
        var options = {
            quality: 100,
            destinationType: this.camera.DestinationType.FILE_URI,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: 2,
            targetWidth: 1080,
            targetHeight: 1092,
            saveToPhotoAlbum: false,
            sourceType: 0,
            correctOrientation: true,
        };
        this.camera.getPicture(options).then(function (data) {
            if (data) {
                _this.uploadFile(data);
            }
        });
    };
    // uploadimage send message
    RoomChatPage.prototype.uploadImageSendMessage = function (uploadedImgurl, fileName) {
        if (uploadedImgurl) {
            var messageObj = {
                text: fileName,
                imgUrl: uploadedImgurl
            };
            this.sendGroupMsg(messageObj);
        }
    };
    // uploadimage send message end
    // search bar 
    // members to add 
    RoomChatPage.prototype.searchUserList = function (event) {
        var _this = this;
        var val = event.target.value;
        if (val && val.trim() != '') {
            this.remaningUserList = this.searchremaningUserList.filter(function (item) {
                if (item && item.email) {
                    return (item.email.toLowerCase().indexOf(val.toLowerCase()) > -1);
                }
                else {
                    return _this.remaningUserList;
                }
            });
        }
        else {
            this.remaningUserList = this.searchremaningUserList;
        }
    };
    // members to add end
    // search group member list
    RoomChatPage.prototype.searchGroupMemList = function (event) {
        var _this = this;
        var val = event.target.value;
        if (val && val.trim() != '') {
            this.groupMemberList = this.searchgroupMemberList.filter(function (item) {
                if (item && item.displayName) {
                    return (item.displayName.toLowerCase().indexOf(val.toLowerCase()) > -1);
                }
                else {
                    return _this.groupMemberList;
                }
            });
        }
        else {
            this.groupMemberList = this.searchgroupMemberList;
        }
    };
    // search group member list end
    // search bar end
    RoomChatPage.prototype.doInfinite = function (event) {
        this.getGroupMessage().then(function () {
            event.complete();
            event.state = 'enabled';
        });
    };
    RoomChatPage.prototype.scrollToBottom = function (element) {
        var promise = new Promise(function (resolve, reject) {
            setTimeout(function () {
                element.scrollTop = element.scrollHeight;
                resolve();
            }, 1000);
        });
        return promise;
    };
    RoomChatPage = __decorate([
        IonicPage(),
        Component({
            selector: 'page-room-chat',
            templateUrl: 'room-chat.html'
        }),
        __metadata("design:paramtypes", [NavController, NavParams, MessageServiceProvider, AuthUser, Events, NgZone, RoomDetail, RoomserviceProvider, UserServiceProvider, AlertController, Clipboard, Camera, InAppBrowser, FileTransfer, OrderByPipe])
    ], RoomChatPage);
    return RoomChatPage;
}());
export { RoomChatPage };
//# sourceMappingURL=room-chat.js.map