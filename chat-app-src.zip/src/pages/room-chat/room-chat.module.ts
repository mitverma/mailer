import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RoomChatPage } from './room-chat';
import { PipesModule } from '../../pipes/pipes.module';

@NgModule({
	declarations: [
	RoomChatPage,
	],
	imports: [
	IonicPageModule.forChild(RoomChatPage), PipesModule
	],
	entryComponents: [
	RoomChatPage,
	],
	exports: [
	RoomChatPage,
	]
})
export class RoomChatPageModule {}
