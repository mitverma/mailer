import { Component, NgZone } from '@angular/core';
import { IonicPage, NavController, NavParams, Events } from 'ionic-angular';
import * as firebase from 'firebase';
import { AuthUser, MembersAndRooms, CopiedData } from '../../providers/entities/entities';
import { MessageServiceProvider } from '../../providers/message-service/message-service'; 
import { DatePipe } from '@angular/common';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { Clipboard } from '@ionic-native/clipboard';
import { InAppBrowser } from '@ionic-native/in-app-browser';

@IonicPage()
@Component({
	selector: 'page-chat',
	templateUrl: 'chat.html', 
})
export class ChatPage {
	conversationPath: any;
	toUserData: any = {};
	formMessage:  any = {};
	chatList: any = [];
	fullImageView: boolean = false;
	imageViewData: any = {};
	copiedText: any;
	viewCopyArea: boolean = false;
	selectedIndex: any;
	viewGroupMessage : boolean = false;
	uploadUrlPath: any;
	messageLoadIndex: number = 20;
	loadforFirstTime: boolean = true;
	constructor(public navCtrl: NavController, public navParams: NavParams, public User: AuthUser, public messageService: MessageServiceProvider, public events: Events, public ngZone: NgZone, public file: File,
		public transfer: FileTransfer, public camera: Camera, public membersAndrooms: MembersAndRooms, public clipboard: Clipboard, public inAppBrowser: InAppBrowser,
		public copiedData: CopiedData) {

		// upload path url
		this.uploadUrlPath = 'https://www.oneinsure.com/onegolive/api/Profile/SaveUploadedData';
		// upload path url end

		this.formMessage = {
			text: '',
			imgUrl: ''
		}

		// this.conversationPath = firebase.database().ref().child('conversation-chat');
		this.conversationPath = firebase.database().ref().child('conversations');
		if (this.navParams.data) {			
			this.toUserData = this.navParams.data;
		}
		this.events.subscribe('userChat:Added', (chatLastData)=>{
			if (chatLastData && chatLastData.conversations_id) {
				this.toUserData.to_user_id = chatLastData.to_user_id;		
				// get active page name (for bind user message and blue tick)
				let activePageName =  this.navCtrl.getActive().name;
				// if page both user is on same chat page then call chat page
				if (activePageName == 'ChatPage') {
					this.getUserMessage();
				}
				// if page both user is on same chat page then call chat page end		
			}
		});


		// // paste obj which is copied to clipboard
		// this.clipboard.paste().then(()=>{
			// 	this.formMessage.imgUrl =  this.copiedData.imgUrl ? this.copiedData.imgUrl : '';
			// })
			// // paste obj which is copied to clipboard end
		}

		ionViewDidLoad() {
			// console.log('ionViewDidLoad ChatPage');
			// console.log(this.toUserData, 'to user data');
			this.getUserMessage();

			// javascript get clipboard event listener
			let textarea = document.querySelector('.textarea-message');
			if (textarea) {
				textarea.addEventListener('paste', (event)=>{
					if (event) {
						this.formMessage.imgUrl =  this.copiedData.imgUrl ? this.copiedData.imgUrl : '';
					}
				})
			}

			// javascript get clipboard event listener end
		}

		sendMessageToUser(messageDetail){

			// text area clear height to defualt
			let textareaElement = document.getElementById('form-textarea');
			textareaElement.style.height = '40px';
			// text area clear height to defualt end


			if (messageDetail && messageDetail.text) {
				let setMessageData = {
					text: messageDetail.text,
					from_username: this.User.email ? this.User.email: this.User.username,
					from_userId: this.User.id,
					to_user_id: this.toUserData.id,
					imgUrl: messageDetail.imgUrl ? messageDetail.imgUrl : '',
				}
				this.messageService.sendMessageToUser(setMessageData).then(()=>{
					this.formMessage.text = '';
					this.formMessage.imgUrl = '';
					this.getUserMessage().then(()=>{
						if (document.querySelector('.chat-content')) {
							let element = document.querySelector('.chat-content').children[1];
							if (element) {						
								element.scrollTop = element.scrollHeight;
							}
						}	
					}); // i used this bcoz limitTolast not working

					// console.log(this.membersAndrooms, 'log');


				});
			}
		}

		getUserMessage() : Promise<any>{
			let promise = new Promise((resolve, reject)=>{

				if (this.toUserData) {
					this.messageService.bindUserMessages(this.User.id, this.toUserData.id, this.messageLoadIndex).subscribe((messageList: any)=>{
						if (messageList && messageList.length) {
							// console.log(messageList, 'msg');
							this.chatList = messageList;
							let element = document.querySelector('.chat-content').children[1];
							setTimeout(()=>{							

								this.ngZone.run(()=>{
									this.chatList = messageList;
									resolve();
									// if (document.querySelector('.chat-content') && this.loadforFirstTime) {
										// 	let element = document.querySelector('.chat-content').children[1];
										// 	if (element) {						
											// 		let scrollHeight = element.scrollHeight;
											// 		console.log(scrollHeight, 'scroll height');
											// 		element.scrollTop = scrollHeight;
											// 		this.scrollToBottom(element).then(()=>{

												// 			this.loadforFirstTime = false;
												// 			resolve();
												// 		});
												// 	}
												// }else {
													// 	resolve();
													// }
												})									

							},500);
							this.messageLoadIndex+= 20;
						}
					});		
				}
			});
			return promise;
		}

		uploadFile(fileUpload){
			let filetypeArray = fileUpload.split('.');
			let fileFormatType = filetypeArray ?  filetypeArray[1] : 'jpg';
			fileFormatType = fileFormatType.toLocaleLowerCase();

			// file upload name
			let fileArray = fileUpload.split('/');
			let getFileNameData = fileArray ? fileArray[fileArray.length - 1]: '';
			let getFileName = getFileNameData.split('.')[0];
			// file upload name end

			const fileTransfer: FileTransferObject = this.transfer.create();
			let currentDateTime = new Date();
			const uploadUrl = this.uploadUrlPath;
			let options: FileUploadOptions = {
				fileKey: 'file',
				fileName: this.User.id + currentDateTime.valueOf()+ getFileName + (fileFormatType ? '.'+fileFormatType : '.jpg'),
				mimeType: "image/jpeg",
				headers: {
					fileName: this.User.id + currentDateTime.valueOf()+ getFileName + (fileFormatType ? '.'+fileFormatType : '.jpg'),
					UserId: this.User.id
				},
			}
			fileTransfer.upload(fileUpload,uploadUrl, options).then((data)=>{
				// console.log(data, 'data');
				let imgUrlFirebase = 'https://www.oneinsure.com/onegolive/Content/UploadedDataSaved/' + options.fileName;
				this.uploadImageSendMessage(imgUrlFirebase, getFileName);
			}).catch(error=>{
				// console.log(error, 'error');
			});
		}

		imageUpload(){
			const options: CameraOptions = {

				quality: 100,
				destinationType: this.camera.DestinationType.FILE_URI,
				encodingType: this.camera.EncodingType.JPEG,
				mediaType: 2, // media type 2 allow allow media type
				targetWidth: 1080, 
				targetHeight: 1092,
				saveToPhotoAlbum: false,
				sourceType: 0,
				correctOrientation: true,
			}

			this.camera.getPicture(options).then((data)=>{
				if (data) {
					this.uploadFile(data);
				}
			})
		}


		viewFullImage(imageViewDetails){
			this.fullImageView = true;
			this.imageViewData.imgUrl =  imageViewDetails.imgUrl;
			this.imageViewData.text =  imageViewDetails.text;

		}
		closeFullImageView(){
			this.fullImageView = false;
			this.imageViewData = {};
		}

		active(){
			// console.log('active long pressed');
		}

		// long press copy text and clear copy text
		longPress(chatObj, index){
			if (chatObj.text) {
				this.viewCopyArea = true;
				this.copiedText = chatObj.text;
				this.selectedIndex = index;

				// copied data
				this.copiedData.text = chatObj.text;
				this.copiedData.imgUrl = chatObj.imgUrl ? chatObj.imgUrl: '';
				Object.assign(this.copiedData, this.copiedData);
				// copied data end
			}
		}

		copyText(){
			this.clipboard.copy(this.copiedText);
			this.viewCopyArea = false;
			this.selectedIndex = -1;
		}

		clearCopyText(){
			this.clipboard.clear();
			this.viewCopyArea = false;
			this.selectedIndex = -1;
		}
		// long press copy text and clear copy text end

		// textarea key down 
		chatKeyDown(event){
			if (event && event.target) {
				event.target.style.height = event.target.scrollHeight;
				event.target.style.cssText = 'height: 40px';
				event.target.style.cssText = 'height: ' + event.target.scrollHeight + 'px';
			}
		}
		// textarea key down end


		uploadImageSendMessage(uploadedImgurl, fileName){		
			if (uploadedImgurl) {
				let messageObj = {
					text : fileName,
					imgUrl: uploadedImgurl
				}
				this.sendMessageToUser(messageObj);
			}
		}

		// view file in InAppBrowser
		viewFileInBrowser(file){
			let fileTypeArray = file.split('.');
			let fileType = fileTypeArray[fileTypeArray.length - 1];
			if (fileType == 'pdf' || fileType == 'docx' || fileType == 'xlsx') {
				file = "https://docs.google.com/gview?embedded=true&url=" + encodeURIComponent(file);
			}
			const browser = this.inAppBrowser.create(file);
		}
		// view file in InAppBrowser end

		doInfinite(event){
			// console.log(event, 'event');
			// alert('50 percent infinite scroll here? Nope, it\'s 100px default value');
			this.getUserMessage().then(()=>{
				event.complete();
				event.state = 'enabled';
			});
		}

		scrollToBottom(element): Promise<any>{
			let promise = new Promise((resolve, reject)=>{
				setTimeout(()=>{
					element.scrollTop = element.scrollHeight;
					resolve();
				}, 1000);
			});
			return promise;
		}

	}

