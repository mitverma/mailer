var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, NgZone } from '@angular/core';
import { IonicPage, NavController, NavParams, Events } from 'ionic-angular';
import * as firebase from 'firebase';
import { AuthUser, MembersAndRooms } from '../../providers/entities/entities';
import { MessageServiceProvider } from '../../providers/message-service/message-service';
import { FileTransfer } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';
import { Camera } from '@ionic-native/camera';
import { Clipboard } from '@ionic-native/clipboard';
import { InAppBrowser } from '@ionic-native/in-app-browser';
var ChatPage = /** @class */ (function () {
    function ChatPage(navCtrl, navParams, User, messageService, events, ngZone, file, transfer, camera, membersAndrooms, clipboard, inAppBrowser) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.User = User;
        this.messageService = messageService;
        this.events = events;
        this.ngZone = ngZone;
        this.file = file;
        this.transfer = transfer;
        this.camera = camera;
        this.membersAndrooms = membersAndrooms;
        this.clipboard = clipboard;
        this.inAppBrowser = inAppBrowser;
        this.toUserData = {};
        this.formMessage = {};
        this.chatList = [];
        this.fullImageView = false;
        this.imageViewData = {};
        this.viewCopyArea = false;
        this.viewGroupMessage = false;
        this.messageLoadIndex = 20;
        this.loadforFirstTime = true;
        // upload path url
        this.uploadUrlPath = 'https://www.oneinsure.com/onegolive/api/Profile/SaveUploadedData';
        // upload path url end
        this.formMessage = {
            text: '',
        };
        // this.conversationPath = firebase.database().ref().child('conversation-chat');
        this.conversationPath = firebase.database().ref().child('conversations');
        if (this.navParams.data) {
            this.toUserData = this.navParams.data;
        }
        this.events.subscribe('userChat:Added', function (chatLastData) {
            if (chatLastData && chatLastData.conversations_id) {
                _this.toUserData.to_user_id = chatLastData.to_user_id;
                // get active page name (for bind user message and blue tick)
                var activePageName = _this.navCtrl.getActive().name;
                // if page both user is on same chat page then call chat page
                if (activePageName == 'ChatPage') {
                    _this.getUserMessage();
                }
                // if page both user is on same chat page then call chat page end		
            }
        });
    }
    ChatPage.prototype.ionViewDidLoad = function () {
        // console.log('ionViewDidLoad ChatPage');
        // console.log(this.toUserData, 'to user data');
        this.getUserMessage();
    };
    ChatPage.prototype.sendMessageToUser = function (messageDetail) {
        var _this = this;
        // text area clear height to defualt
        var textareaElement = document.getElementById('form-textarea');
        textareaElement.style.height = '40px';
        // text area clear height to defualt end
        if (messageDetail && messageDetail.text) {
            var setMessageData = {
                text: messageDetail.text,
                from_username: this.User.email ? this.User.email : this.User.username,
                from_userId: this.User.id,
                to_user_id: this.toUserData.id,
                imgUrl: messageDetail.imgUrl ? messageDetail.imgUrl : '',
            };
            this.messageService.sendMessageToUser(setMessageData).then(function () {
                _this.formMessage.text = '';
                _this.getUserMessage().then(function () {
                    if (document.querySelector('.chat-content')) {
                        var element = document.querySelector('.chat-content').children[1];
                        if (element) {
                            element.scrollTop = element.scrollHeight;
                        }
                    }
                }); // i used this bcoz limitTolast not working
                // console.log(this.membersAndrooms, 'log');
            });
        }
    };
    ChatPage.prototype.getUserMessage = function () {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            if (_this.toUserData) {
                _this.messageService.bindUserMessages(_this.User.id, _this.toUserData.id, _this.messageLoadIndex).subscribe(function (messageList) {
                    if (messageList && messageList.length) {
                        // console.log(messageList, 'msg');
                        _this.chatList = messageList;
                        var element = document.querySelector('.chat-content').children[1];
                        setTimeout(function () {
                            _this.ngZone.run(function () {
                                _this.chatList = messageList;
                                resolve();
                                // if (document.querySelector('.chat-content') && this.loadforFirstTime) {
                                // 	let element = document.querySelector('.chat-content').children[1];
                                // 	if (element) {						
                                // 		let scrollHeight = element.scrollHeight;
                                // 		console.log(scrollHeight, 'scroll height');
                                // 		element.scrollTop = scrollHeight;
                                // 		this.scrollToBottom(element).then(()=>{
                                // 			this.loadforFirstTime = false;
                                // 			resolve();
                                // 		});
                                // 	}
                                // }else {
                                // 	resolve();
                                // }
                            });
                        }, 500);
                        _this.messageLoadIndex += 20;
                    }
                });
            }
        });
        return promise;
    };
    ChatPage.prototype.uploadFile = function (fileUpload) {
        var _this = this;
        var filetypeArray = fileUpload.split('.');
        var fileFormatType = filetypeArray ? filetypeArray[1] : 'jpg';
        fileFormatType = fileFormatType.toLocaleLowerCase();
        // file upload name
        var fileArray = fileUpload.split('/');
        var getFileNameData = fileArray ? fileArray[fileArray.length - 1] : '';
        var getFileName = getFileNameData.split('.')[0];
        // file upload name end
        var fileTransfer = this.transfer.create();
        var currentDateTime = new Date();
        var uploadUrl = this.uploadUrlPath;
        var options = {
            fileKey: 'file',
            fileName: this.User.id + currentDateTime.valueOf() + getFileName + (fileFormatType ? '.' + fileFormatType : '.jpg'),
            mimeType: "image/jpeg",
            headers: {
                fileName: this.User.id + currentDateTime.valueOf() + getFileName + (fileFormatType ? '.' + fileFormatType : '.jpg'),
                UserId: this.User.id
            },
        };
        fileTransfer.upload(fileUpload, uploadUrl, options).then(function (data) {
            // console.log(data, 'data');
            var imgUrlFirebase = 'https://www.oneinsure.com/onegolive/Content/UploadedDataSaved/' + options.fileName;
            _this.uploadImageSendMessage(imgUrlFirebase, getFileName);
        }).catch(function (error) {
            // console.log(error, 'error');
        });
    };
    ChatPage.prototype.imageUpload = function () {
        var _this = this;
        var options = {
            quality: 100,
            destinationType: this.camera.DestinationType.FILE_URI,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: 2,
            targetWidth: 1080,
            targetHeight: 1092,
            saveToPhotoAlbum: false,
            sourceType: 0,
            correctOrientation: true,
        };
        this.camera.getPicture(options).then(function (data) {
            if (data) {
                _this.uploadFile(data);
            }
        });
    };
    ChatPage.prototype.viewFullImage = function (imageViewDetails) {
        this.fullImageView = true;
        this.imageViewData.imgUrl = imageViewDetails.imgUrl;
        this.imageViewData.text = imageViewDetails.text;
    };
    ChatPage.prototype.closeFullImageView = function () {
        this.fullImageView = false;
        this.imageViewData = {};
    };
    ChatPage.prototype.active = function () {
        // console.log('active long pressed');
    };
    // long press copy text and clear copy text
    ChatPage.prototype.longPress = function (text, index) {
        if (text) {
            this.viewCopyArea = true;
            this.copiedObj = {
                copyText: text,
                imgUrl: ''
            };
            this.copiedString = JSON.stringify(this.copiedObj);
            this.selectedIndex = index;
        }
    };
    ChatPage.prototype.copyText = function () {
        this.clipboard.copy(this.copiedString);
        this.viewCopyArea = false;
        this.selectedIndex = -1;
    };
    ChatPage.prototype.pasteText = function () {
        this.
        ;
    };
    ChatPage.prototype.clearCopyText = function () {
        this.clipboard.clear();
        this.viewCopyArea = false;
        this.selectedIndex = -1;
    };
    // long press copy text and clear copy text end
    // textarea key down 
    ChatPage.prototype.chatKeyDown = function (event) {
        if (event && event.target) {
            event.target.style.height = event.target.scrollHeight;
            event.target.style.cssText = 'height: 40px';
            event.target.style.cssText = 'height: ' + event.target.scrollHeight + 'px';
        }
    };
    // textarea key down end
    ChatPage.prototype.uploadImageSendMessage = function (uploadedImgurl, fileName) {
        if (uploadedImgurl) {
            var messageObj = {
                text: fileName,
                imgUrl: uploadedImgurl
            };
            this.sendMessageToUser(messageObj);
        }
    };
    // view file in InAppBrowser
    ChatPage.prototype.viewFileInBrowser = function (file) {
        var fileTypeArray = file.split('.');
        var fileType = fileTypeArray[fileTypeArray.length - 1];
        if (fileType == 'pdf' || fileType == 'docx' || fileType == 'xlsx') {
            file = "https://docs.google.com/gview?embedded=true&url=" + encodeURIComponent(file);
        }
        var browser = this.inAppBrowser.create(file);
    };
    // view file in InAppBrowser end
    ChatPage.prototype.doInfinite = function (event) {
        // console.log(event, 'event');
        // alert('50 percent infinite scroll here? Nope, it\'s 100px default value');
        this.getUserMessage().then(function () {
            event.complete();
            event.state = 'enabled';
        });
    };
    ChatPage.prototype.scrollToBottom = function (element) {
        var promise = new Promise(function (resolve, reject) {
            setTimeout(function () {
                element.scrollTop = element.scrollHeight;
                resolve();
            }, 1000);
        });
        return promise;
    };
    ChatPage = __decorate([
        IonicPage(),
        Component({
            selector: 'page-chat',
            templateUrl: 'chat.html',
        }),
        __metadata("design:paramtypes", [NavController, NavParams, AuthUser, MessageServiceProvider, Events, NgZone, File,
            FileTransfer, Camera, MembersAndRooms, Clipboard, InAppBrowser])
    ], ChatPage);
    return ChatPage;
}());
export { ChatPage };
//# sourceMappingURL=chat.js.map