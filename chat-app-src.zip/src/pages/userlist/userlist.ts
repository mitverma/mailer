import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,AlertController  } from 'ionic-angular';

import { UserServiceProvider } from '../../providers/user-service/user-service';
import { AuthProvider } from '../../providers/auth/auth';
import { RoomserviceProvider } from '../../providers/roomservice/roomservice';
import { MessageServiceProvider } from '../../providers/message-service/message-service';
import { OrderByPipe } from '../../pipes/filters/filters';





/**
 * Generated class for the UserlistPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

 @IonicPage()
 @Component({
 	selector: 'page-userlist',
 	templateUrl: 'userlist.html',
 })
 export class UserlistPage {
 	userList: any; 	
 	currentIndex: number = -1;
 	selectedList: any;
 	searchUserList : any;
 	getUserListView: boolean = true;
 	searchModel: any;
 	constructor(public navCtrl: NavController, public navParams: NavParams, public userService: UserServiceProvider, public authService: AuthProvider, public roomService: RoomserviceProvider, public alertCtrl : AlertController, public messageService:MessageServiceProvider, public orderBy: OrderByPipe) {
 		this.userList = [];
 		this.searchUserList = [];
 		this.selectedList = [];
 	}

 	ionViewDidLoad() {
 		this.authService.ensureAuthenticate().then((user)=>{
 			this.userService.UserMessageListiner();
 			this.getUserList();
 		});
 	}

 	getUserList(){
 		this.userService.getUserList().subscribe((res)=>{
 			if (res && res.length) {
 				this.userList = res.filter((val)=>{
 					return val !== undefined && val.uid;
 				});
 				// this.orderBy.transform(this.userList, ['+username']);
 				this.userList = this.userList.sort((a,b)=>{
 					a.email = a.email.toLowerCase();
 					b.email = b.email.toLowerCase();
 					if (a.email < b.email) {
 						return -1;
 					}
 					if (a.email > b.email) {
 						return 1;
 					}
 					return 0;
 				});

 				this.searchUserList = this.userList;
 			}
 		})
 	}

 	createRoomList(userValue){
 		// console.log(userValue);
 		if (this.selectedList.length) {
 			this.currentIndex = this.selectedList.indexOf(userValue);
 		}
 		if (this.currentIndex !== -1) {
 			this.selectedList.splice(this.currentIndex, 1);
 		}else{ 			
 			this.selectedList.push(userValue);
 			// console.log(this.selectedList, 'selected list');
 		}
 		this.currentIndex = -1;
 	}

 	getItems(event: any){
 		const val = event.target.value;
 		if (val && val.trim() != '') {
 			this.userList = this.searchUserList.filter((item) => {
 				if (item && item.email) { 					
 					return (item.email.toLowerCase().indexOf(val.toLowerCase()) > -1);
 				}
 				else {
 					return this.userList;
 				}
 			})
 		}else {
 			this.userList = this.searchUserList;
 		}
 	}


 	createNewRoom(roomName){
 		let roomDetail = {
 			name: roomName,
 		}
 		this.roomService.createRoom(roomDetail, this.selectedList).then((user)=>{
 			this.navCtrl.setRoot('HomePage');
 		})
 	}

 	setGroupNameAlert(){
 		let alert = this.alertCtrl.create({
 			title: 'Create Group',
 			message: 'Name your group?',
 			inputs: [
 			{
 				name: 'groupname',
 				placeholder: 'Group Name',
 				id: 'group-name'
 			}
 			],
 			buttons: [
 			{
 				text: 'Cancel',
 				role: 'cancel',
 				handler: () => {

 				}
 			},
 			{
 				text: 'Create',
 				handler: data => {
 					// console.log(data, 'data');
 					if (data && data.groupname && data.groupname.trim() != '') { 						
 						let roomName = data.groupname;
 						this.createNewRoom(roomName);
 					}else {
 						let inputNode = document.getElementById('group-name');
 						document.getElementById('group-name').parentNode['classList'].add('error');
 						let spanError = document.getElementsByClassName('span-error');
 						if (spanError && spanError.length) {
 							
 						}else {
 							let element = document.createElement('span');
 							let elementText = document.createTextNode('Please enter group name');
 							element.classList.add('span-error');
 							element.appendChild(elementText);
 							inputNode.parentNode.appendChild(element);
 						} 						
 						
 						return false;
 					}
 				}
 			}
 			]
 		});
 		alert.present();
 	}

 	chatToUser(userData){
 		this.navCtrl.push('ChatPage',userData);
 	}

 	toggleViewList(viewListType){
 		if (viewListType == 'userList') {
			 this.getUserListView = true;
			 this.selectedList = [];
 		}else if(viewListType == 'createGroupList') {
 			this.getUserListView = false;
 		}
 		this.userList = this.searchUserList;
 		this.searchModel = '';
 	}

 }
