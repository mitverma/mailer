var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { UserServiceProvider } from '../../providers/user-service/user-service';
import { AuthProvider } from '../../providers/auth/auth';
import { RoomserviceProvider } from '../../providers/roomservice/roomservice';
import { MessageServiceProvider } from '../../providers/message-service/message-service';
import { OrderByPipe } from '../../pipes/filters/filters';
/**
 * Generated class for the UserlistPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
var UserlistPage = /** @class */ (function () {
    function UserlistPage(navCtrl, navParams, userService, authService, roomService, alertCtrl, messageService, orderBy) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.userService = userService;
        this.authService = authService;
        this.roomService = roomService;
        this.alertCtrl = alertCtrl;
        this.messageService = messageService;
        this.orderBy = orderBy;
        this.currentIndex = -1;
        this.getUserListView = true;
        this.userList = [];
        this.searchUserList = [];
        this.selectedList = [];
    }
    UserlistPage.prototype.ionViewDidLoad = function () {
        var _this = this;
        this.authService.ensureAuthenticate().then(function (user) {
            _this.userService.UserMessageListiner();
            _this.getUserList();
        });
    };
    UserlistPage.prototype.getUserList = function () {
        var _this = this;
        this.userService.getUserList().subscribe(function (res) {
            if (res && res.length) {
                _this.userList = res.filter(function (val) {
                    return val !== undefined && val.uid;
                });
                // this.orderBy.transform(this.userList, ['+username']);
                _this.userList = _this.userList.sort(function (a, b) {
                    a.email = a.email.toLowerCase();
                    b.email = b.email.toLowerCase();
                    if (a.email < b.email) {
                        return -1;
                    }
                    if (a.email > b.email) {
                        return 1;
                    }
                    return 0;
                });
                _this.searchUserList = _this.userList;
            }
        });
    };
    UserlistPage.prototype.createRoomList = function (userValue) {
        // console.log(userValue);
        if (this.selectedList.length) {
            this.currentIndex = this.selectedList.indexOf(userValue);
        }
        if (this.currentIndex !== -1) {
            this.selectedList.splice(this.currentIndex, 1);
        }
        else {
            this.selectedList.push(userValue);
            // console.log(this.selectedList, 'selected list');
        }
        this.currentIndex = -1;
    };
    UserlistPage.prototype.getItems = function (event) {
        var _this = this;
        var val = event.target.value;
        if (val && val.trim() != '') {
            this.userList = this.searchUserList.filter(function (item) {
                if (item && item.email) {
                    return (item.email.toLowerCase().indexOf(val.toLowerCase()) > -1);
                }
                else {
                    return _this.userList;
                }
            });
        }
        else {
            this.userList = this.searchUserList;
        }
    };
    UserlistPage.prototype.createNewRoom = function (roomName) {
        var _this = this;
        var roomDetail = {
            name: roomName,
        };
        this.roomService.createRoom(roomDetail, this.selectedList).then(function (user) {
            _this.navCtrl.setRoot('HomePage');
        });
    };
    UserlistPage.prototype.setGroupNameAlert = function () {
        var _this = this;
        var alert = this.alertCtrl.create({
            title: 'Create Group',
            message: 'Name your group?',
            inputs: [
                {
                    name: 'groupname',
                    placeholder: 'Group Name',
                    id: 'group-name'
                }
            ],
            buttons: [
                {
                    text: 'Cancel',
                    role: 'cancel',
                    handler: function () {
                    }
                },
                {
                    text: 'Create',
                    handler: function (data) {
                        // console.log(data, 'data');
                        if (data && data.groupname && data.groupname.trim() != '') {
                            var roomName = data.groupname;
                            _this.createNewRoom(roomName);
                        }
                        else {
                            var inputNode = document.getElementById('group-name');
                            document.getElementById('group-name').parentNode['classList'].add('error');
                            var spanError = document.getElementsByClassName('span-error');
                            if (spanError && spanError.length) {
                            }
                            else {
                                var element = document.createElement('span');
                                var elementText = document.createTextNode('Please enter group name');
                                element.classList.add('span-error');
                                element.appendChild(elementText);
                                inputNode.parentNode.appendChild(element);
                            }
                            return false;
                        }
                    }
                }
            ]
        });
        alert.present();
    };
    UserlistPage.prototype.chatToUser = function (userData) {
        this.navCtrl.push('ChatPage', userData);
    };
    UserlistPage.prototype.toggleViewList = function (viewListType) {
        if (viewListType == 'userList') {
            this.getUserListView = true;
        }
        else if (viewListType == 'createGroupList') {
            this.getUserListView = false;
        }
        this.userList = this.searchUserList;
        this.searchModel = '';
    };
    UserlistPage = __decorate([
        IonicPage(),
        Component({
            selector: 'page-userlist',
            templateUrl: 'userlist.html',
        }),
        __metadata("design:paramtypes", [NavController, NavParams, UserServiceProvider, AuthProvider, RoomserviceProvider, AlertController, MessageServiceProvider, OrderByPipe])
    ], UserlistPage);
    return UserlistPage;
}());
export { UserlistPage };
//# sourceMappingURL=userlist.js.map