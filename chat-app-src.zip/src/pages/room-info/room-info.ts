import { Component} from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { AuthUser } from '../../providers/entities/entities';
import { RoomDetail } from  '../../providers/entities/entities'
import { RoomserviceProvider } from  '../../providers/roomservice/roomservice'
import { ActionSheetController } from 'ionic-angular';
import { DatePipe } from '@angular/common';
/**
 * Generated class for the RoomInfoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

 @IonicPage()
 @Component({
 	selector: 'page-room-info',
 	templateUrl: 'room-info.html',
 })
 export class RoomInfoPage {
 	groupDetail: any = {};
 	membersList = [];
 	roomInfo: any = {};

 	constructor(public navCtrl: NavController, public navParams: NavParams, public User: AuthUser, public roomDetail: RoomDetail, public roomService: RoomserviceProvider, public actionSheetCtrl: ActionSheetController, public datePipe: DatePipe, public toastCtrl: ToastController) {
 		this.groupDetail = {
 			name: '',
 			createdAt: ''
 		}
 	}

 	ionViewDidLoad() {
 		if (this.navParams && this.navParams.data) {
 			this.roomInfo = this.navParams.data;

 			this.groupDetail.name = this.roomInfo.name;
 			this.groupDetail.createdAt = this.datePipe.transform(this.roomInfo.createdAt, 'dd-MMM-yyyy hh:mm a');

 			this.groupInfo();

 			// get group info
 			this.getGroupDetails();
 			// get group info end
 		}
 		// console.log('ionViewDidLoad RoomInfoPage');
 	}

 	groupInfo(){
 		let roomId =  this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
 		this.roomService.getMemberInRoom(roomId).then((res)=>{
 			if (res) {
 				this.membersList = res;
 				// if user is member set roominfo role to member 
 				let currentUserRole = this.membersList.filter(list=>{
 					if (list.id == this.User.id) {
 						return list;
 					}
 				});

 				if (currentUserRole[0].role == 'member') {
 					this.roomInfo.role = 'member';
 				}
 				// if user is member set roominfo role to member end
 			}
 		});
 	};

 	getGroupDetails(){
 		let roomId =  this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
 		this.roomService.getRoomDetails(roomId).then((roomData)=>{
 			if (roomData) {
 				// this.groupDetail = roomData;
 				this.groupDetail.createdAt = roomData.createdAt ? roomData.createdAt : this.groupDetail.createdAt;
 				this.groupDetail.createdAt = this.datePipe.transform(this.groupDetail.createdAt, 'dd-MMM-yyyy hh:mm a');
 			}
 		})
 	}

 	assignRole(userDetail){
 		let ownerList = this.membersList.filter((list)=>{
 			return list.id !== this.User.id && list.role == 'owner';
 		});
 		//console.log(ownerList,'data');
 		if (userDetail) {
 			let roomId =  this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
 			let viewBtnText = userDetail.role == 'owner' ? 'Dismiss as owner' : 'Make as owner';
 			let viewBtnValue = userDetail.role == 'owner' ? 'owner' : 'member';
 			const actionSheet = this.actionSheetCtrl.create({
 				buttons: [
 				{
 					text: viewBtnText,
 					role: 'destructive',
 					handler: () => {
 						if (viewBtnValue == 'owner') {
 							if (ownerList.length) {
 								this.roomService.updateRole(roomId, userDetail.id,'member').then(res=>{
 									this.groupInfo();
 								});
 							}else{
 								// make other owner and make your self has member
 								this.makeOtherOwner();
 								// make other owner and make your self has member end
 							}
 							
 						}else {
 							this.roomService.updateRole(roomId, userDetail.id,'owner').then(res=>{
 								this.groupInfo();
 							});
 						}
 					}
 				},{
 					text: 'Cancel',
 					role: 'cancel',
 					handler: () => {
 					}
 				}
 				]
 			}); 			
 			actionSheet.present();
 		}
 	}

 	// when logged in member is last owner 
 	makeOtherOwner(){
 		// member list filter and exclude own 
 		let memberListExceptOwner: any = [];
 		memberListExceptOwner = this.membersList.filter((list)=>{
 			return list.id !== this.User.id;
 		});
 		if (memberListExceptOwner.length) {
 			let roomId =  this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
 			this.assignRole(memberListExceptOwner[0]);
 			this.roomService.updateRole(roomId, memberListExceptOwner[0].id,'owner').then((res)=>{
 				this.roomService.updateRole(roomId, this.User.id, 'member').then((res)=>{
 					this.groupInfo();
 					this.roomInfo.role = 'member';
 				})
 			})
 		}
 		// member list filter and exclude own 
 	}
 	// when logged in member is last owner end


 	// update group name

 	updateGroupInfo(){
 		let roomId =  this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
 		if (this.groupDetail && this.groupDetail.name.trim() !='' && this.groupDetail.name.trim() != this.roomInfo.name.trim()) {
 			this.groupDetail.name.trim();
 			this.roomService.updateGroupName(roomId, this.groupDetail.name).then(data=>{
 				console.log(data, 'data update');
 				this.roomInfo.displayName = this.groupDetail.name;
 				this.roomInfo.name = this.groupDetail.name;
 				let message = 'Group name changed successfully';
 				this.toastMessage(message);
 			})	
 		}
 		if (this.groupDetail && this.groupDetail.name.trim() == '') {
 			let message = "Group name cannot be empty";
 			this.toastMessage(message);
 		}
 	}
 	// update group name end
 	toastMessage(message){
 		const  toast = this.toastCtrl.create({
 			message: message,
 			duration: 3000
 		});
 		toast.present();
 	}

 }

