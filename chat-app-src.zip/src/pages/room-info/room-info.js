var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { AuthUser } from '../../providers/entities/entities';
import { RoomDetail } from '../../providers/entities/entities';
import { RoomserviceProvider } from '../../providers/roomservice/roomservice';
import { ActionSheetController } from 'ionic-angular';
import { DatePipe } from '@angular/common';
/**
 * Generated class for the RoomInfoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
var RoomInfoPage = /** @class */ (function () {
    function RoomInfoPage(navCtrl, navParams, User, roomDetail, roomService, actionSheetCtrl, datePipe, toastCtrl) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.User = User;
        this.roomDetail = roomDetail;
        this.roomService = roomService;
        this.actionSheetCtrl = actionSheetCtrl;
        this.datePipe = datePipe;
        this.toastCtrl = toastCtrl;
        this.groupDetail = {};
        this.membersList = [];
        this.roomInfo = {};
        this.groupDetail = {
            name: '',
            createdAt: ''
        };
    }
    RoomInfoPage.prototype.ionViewDidLoad = function () {
        if (this.navParams && this.navParams.data) {
            this.roomInfo = this.navParams.data;
            this.groupDetail.name = this.roomInfo.name;
            this.groupDetail.createdAt = this.datePipe.transform(this.roomInfo.createdAt, 'dd-MMM-yyyy hh:mm a');
            this.groupInfo();
            // get group info
            this.getGroupDetails();
            // get group info end
        }
        // console.log('ionViewDidLoad RoomInfoPage');
    };
    RoomInfoPage.prototype.groupInfo = function () {
        var _this = this;
        var roomId = this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
        this.roomService.getMemberInRoom(roomId).then(function (res) {
            if (res) {
                _this.membersList = res;
                // if user is member set roominfo role to member 
                var currentUserRole = _this.membersList.filter(function (list) {
                    if (list.id == _this.User.id) {
                        return list;
                    }
                });
                if (currentUserRole[0].role == 'member') {
                    _this.roomInfo.role = 'member';
                }
                // if user is member set roominfo role to member end
            }
        });
    };
    ;
    RoomInfoPage.prototype.getGroupDetails = function () {
        var _this = this;
        var roomId = this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
        this.roomService.getRoomDetails(roomId).then(function (roomData) {
            if (roomData) {
                // this.groupDetail = roomData;
                _this.groupDetail.createdAt = roomData.createdAt ? roomData.createdAt : _this.groupDetail.createdAt;
                _this.groupDetail.createdAt = _this.datePipe.transform(_this.groupDetail.createdAt, 'dd-MMM-yyyy hh:mm a');
            }
        });
    };
    RoomInfoPage.prototype.assignRole = function (userDetail) {
        var _this = this;
        var ownerList = this.membersList.filter(function (list) {
            return list.id !== _this.User.id && list.role == 'owner';
        });
        //console.log(ownerList,'data');
        if (userDetail) {
            var roomId_1 = this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
            var viewBtnText = userDetail.role == 'owner' ? 'Dismiss as owner' : 'Make as owner';
            var viewBtnValue_1 = userDetail.role == 'owner' ? 'owner' : 'member';
            var actionSheet = this.actionSheetCtrl.create({
                buttons: [
                    {
                        text: viewBtnText,
                        role: 'destructive',
                        handler: function () {
                            if (viewBtnValue_1 == 'owner') {
                                if (ownerList.length) {
                                    _this.roomService.updateRole(roomId_1, userDetail.id, 'member').then(function (res) {
                                        _this.groupInfo();
                                    });
                                }
                                else {
                                    // make other owner and make your self has member
                                    _this.makeOtherOwner();
                                    // make other owner and make your self has member end
                                }
                            }
                            else {
                                _this.roomService.updateRole(roomId_1, userDetail.id, 'owner').then(function (res) {
                                    _this.groupInfo();
                                });
                            }
                        }
                    }, {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: function () {
                        }
                    }
                ]
            });
            actionSheet.present();
        }
    };
    // when logged in member is last owner 
    RoomInfoPage.prototype.makeOtherOwner = function () {
        var _this = this;
        // member list filter and exclude own 
        var memberListExceptOwner = [];
        memberListExceptOwner = this.membersList.filter(function (list) {
            return list.id !== _this.User.id;
        });
        if (memberListExceptOwner.length) {
            var roomId_2 = this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
            this.assignRole(memberListExceptOwner[0]);
            this.roomService.updateRole(roomId_2, memberListExceptOwner[0].id, 'owner').then(function (res) {
                _this.roomService.updateRole(roomId_2, _this.User.id, 'member').then(function (res) {
                    _this.groupInfo();
                    _this.roomInfo.role = 'member';
                });
            });
        }
        // member list filter and exclude own 
    };
    // when logged in member is last owner end
    // update group name
    RoomInfoPage.prototype.updateGroupInfo = function () {
        var _this = this;
        var roomId = this.roomInfo.roomId ? this.roomInfo.roomId : this.roomDetail.roomId;
        if (this.groupDetail && this.groupDetail.name.trim() != '' && this.groupDetail.name.trim() != this.roomInfo.name.trim()) {
            this.groupDetail.name.trim();
            this.roomService.updateGroupName(roomId, this.groupDetail.name).then(function (data) {
                console.log(data, 'data update');
                _this.roomInfo.displayName = _this.groupDetail.name;
                _this.roomInfo.name = _this.groupDetail.name;
                var message = 'Group name changed successfully';
                _this.toastMessage(message);
            });
        }
        if (this.groupDetail && this.groupDetail.name.trim() == '') {
            var message = "Group name cannot be empty";
            this.toastMessage(message);
        }
    };
    // update group name end
    RoomInfoPage.prototype.toastMessage = function (message) {
        var toast = this.toastCtrl.create({
            message: message,
            duration: 3000
        });
        toast.present();
    };
    RoomInfoPage = __decorate([
        IonicPage(),
        Component({
            selector: 'page-room-info',
            templateUrl: 'room-info.html',
        }),
        __metadata("design:paramtypes", [NavController, NavParams, AuthUser, RoomDetail, RoomserviceProvider, ActionSheetController, DatePipe, ToastController])
    ], RoomInfoPage);
    return RoomInfoPage;
}());
export { RoomInfoPage };
//# sourceMappingURL=room-info.js.map