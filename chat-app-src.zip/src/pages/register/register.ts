import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,ToastController} from 'ionic-angular';

import { AuthProvider } from '../../providers/auth/auth'
import { UserServiceProvider } from '../../providers/user-service/user-service'
import { FcmserviceProvider } from '../../providers/fcmservice/fcmservice';


@IonicPage()
@Component({
	selector: 'page-register',
	templateUrl: 'register.html',
})
export class RegisterPage {
	userDetail: object = {};
	loginUserDetail: any = {}; 
	viewRegister: any;
	constructor(public navCtrl: NavController, public navParams: NavParams, public authService: AuthProvider, public userService: UserServiceProvider, public toastCtrl: ToastController, public fcmService: FcmserviceProvider) {
		this.userDetail = {
			name: '',
			email: '',
			password:''
		}

		this.loginUserDetail = {
			email: '',
			password: ''
		}
	}

	ionViewDidLoad() {
		console.log('ionViewDidLoad RegisterPage');
		this.fcmService.requestPermission();
	}

	register(formDetail){
		if (formDetail && formDetail.valid) {
			this.authService.signup(this.userDetail).then(user=>{
				if (user) {
					// set to user list
					this.userService.setToUserList(user);
					// set to user list end
					this.navCtrl.setRoot('HomePage');
				}
			}).catch(error=>{
				console.log(error.message, 'error login');
				console.log(this.userDetail, 'user detail');
				this.toaster(error.message);
			})
		}
	}

	toggleView(viewtype){
		if (viewtype == 'register') {
			this.viewRegister = true;
		}else if(viewtype == 'login') {
			this.viewRegister = false;
		}
	}

	toaster(message){
		const  toast = this.toastCtrl.create({
			message: message,
			duration: 3000
		});
		toast.present();
	}


	loginUser(formDetail){
		if (formDetail && formDetail.valid) {
			this.authService.login(this.loginUserDetail.email, this.loginUserDetail.password).then((user)=>{
				if (user) {
					this.userService.trackPresence();
					this.navCtrl.setRoot('HomePage');
				}
			}).catch(error=>{
				console.log(error);
				this.toaster(error.message);
			});
		}
	}

	forgotPassword(emailId){
		if (emailId && emailId != '') {
			this.authService.setPassword(emailId).then((data)=>{
				console.log(data, 'data');
			}).catch(error=>{
				if (error) {
					this.toaster(error.message);
				}
			})
		}else{
			let errorMsg = "Email-id is required to reset Password.";
			this.toaster(errorMsg);
		}
	}
}
