import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HomePage } from './home';
import { OrderByPipe } from '../../pipes/filters/filters';

@NgModule({
	declarations: [
	HomePage,
	OrderByPipe
	],
	imports: [
	IonicPageModule.forChild(HomePage),
	],
	entryComponents: [
	HomePage
	],
	exports: [
	HomePage,
	OrderByPipe	
	]
})
export class HomePageModule {}
