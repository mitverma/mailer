var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RoomserviceProvider } from '../../providers/roomservice/roomservice';
import { UserServiceProvider } from '../../providers/user-service/user-service';
import { MessageServiceProvider } from '../../providers/message-service/message-service';
import { AuthProvider } from '../../providers/auth/auth';
import { OrderByPipe } from '../../pipes/filters/filters';
import { AuthUser, RoomDetail, MembersAndRooms } from '../../providers/entities/entities';
/**
 * Generated class for the HomePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
var HomePage = /** @class */ (function () {
    function HomePage(navCtrl, navParams, roomService, authService, userService, orderBy, roomDetail, User, membersAndrooms, messageService) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.roomService = roomService;
        this.authService = authService;
        this.userService = userService;
        this.orderBy = orderBy;
        this.roomDetail = roomDetail;
        this.User = User;
        this.membersAndrooms = membersAndrooms;
        this.messageService = messageService;
        this.chatList = [];
        this.currentActiveList = [];
        this.authService.ensureAuthenticate().then(function (user) {
            _this.loadGroupsAndUsers();
            // user message listener
            _this.userService.UserMessageListiner();
            // user message listener end
            // group message listener
            _this.messageService.groupMessageAdded();
            // group message listener end
            // group added listener
            _this.roomService.setupGroupAddedListener();
            // group added listener end
            // for home page for own user messasge listener
            _this.userService.ownUserMessageListener();
            // for home page for own user messasge listener end
            // group removed listener
            _this.roomService.setupGroupRemovedListener();
            // group removed listener end
            _this.userService.userChatsToListUser();
            // this.userService.userDataChanged();
            _this.todayDateValue = new Date().valueOf();
            _this.yesterdayDateValue = new Date().setDate(new Date().getDate() - 1).valueOf();
        });
    }
    HomePage.prototype.ionViewDidLoad = function () {
        // console.log('ionViewDidLoad HomePage');
    };
    // load group and users 
    HomePage.prototype.loadGroupsAndUsers = function () {
        var _this = this;
        this.roomService.loadGroupsLastConv().then(function (roomList) {
            if (roomList && roomList.length) {
                _this.currentActiveList = roomList;
            }
            _this.userService.loadUserList().then(function (userList) {
                var userFinalList = [];
                if (userList && userList.length) {
                    // console.log(userList, 'user list');
                    _this.userService.loadUsersListAddEventListener().then(function (convList) {
                        if (convList) {
                            userList.forEach(function (list) {
                                convList.forEach(function (conv) {
                                    if ((list.id == conv.from_userId && conv.to_user_id == _this.User.id) || (list.id == conv.to_user_id && conv.from_userId == _this.User.id)) {
                                        list.last_message_content = conv.text;
                                        list.displayDate = conv.timestamp;
                                        list.createdAt = conv.timestamp;
                                        _this.currentActiveList.push(list);
                                        // add to member rooms
                                        _this.membersAndrooms.membersRoom.push(list);
                                    }
                                });
                            });
                            // console.log(this.currentActiveList, 'current active list');
                            _this.currentActiveList = _this.orderBy.transform(_this.currentActiveList, ['-createdAt']);
                            // assign members and rooms data to entity
                            // Object.assign(this.membersAndrooms.membersRoom, this.currentActiveList);
                            // assign members and rooms data to entity end
                            // remove duplicate from array
                            var memberValues_1 = [];
                            var keys_1 = [];
                            _this.membersAndrooms.membersRoom.forEach(function (list) {
                                var key = list.id || list.roomId;
                                if (keys_1.indexOf(key) == -1) {
                                    keys_1.push(key);
                                    memberValues_1.push(list);
                                }
                            });
                            _this.membersAndrooms.membersRoom = memberValues_1;
                            _this.membersAndrooms.membersRoom = _this.orderBy.transform(_this.membersAndrooms.membersRoom, ['-createdAt']);
                            // remove duplicate from array end
                            console.log(_this.membersAndrooms.membersRoom, 'member room');
                        }
                    });
                }
            });
        });
    };
    // load group and users end
    HomePage.prototype.chatInGroup = function (groupDetail, redirectTo) {
        var setRoomDetail = {
            createdAt: groupDetail.createdAt,
            lastMessage: groupDetail.last_message_content,
            roomId: groupDetail.roomId,
            name: groupDetail.name,
            lastMessageUser: groupDetail.last_message_user,
            role: groupDetail.role
        };
        Object.assign(this.roomDetail, setRoomDetail);
        if (redirectTo == 'groupChat') {
            this.navCtrl.push('RoomChatPage', groupDetail);
        }
        if (redirectTo == 'groupInfo') {
            this.navCtrl.push('RoomInfoPage', groupDetail);
        }
    };
    HomePage.prototype.chatToUser = function (userData) {
        this.navCtrl.push('ChatPage', userData);
    };
    HomePage.prototype.viewUserList = function () {
        this.navCtrl.push('UserlistPage');
    };
    HomePage = __decorate([
        IonicPage(),
        Component({
            selector: 'page-home',
            templateUrl: 'home.html',
            providers: [OrderByPipe]
        }),
        __metadata("design:paramtypes", [NavController, NavParams, RoomserviceProvider, AuthProvider, UserServiceProvider, OrderByPipe, RoomDetail, AuthUser, MembersAndRooms, MessageServiceProvider])
    ], HomePage);
    return HomePage;
}());
export { HomePage };
//# sourceMappingURL=home.js.map