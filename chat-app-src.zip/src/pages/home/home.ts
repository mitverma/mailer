import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Events } from 'ionic-angular';
import { RoomserviceProvider } from '../../providers/roomservice/roomservice'
import { UserServiceProvider } from '../../providers/user-service/user-service'
import { MessageServiceProvider } from '../../providers/message-service/message-service'
import { AuthProvider } from '../../providers/auth/auth'
import { OrderByPipe } from '../../pipes/filters/filters';
import { AuthUser,RoomDetail, MembersAndRooms } from '../../providers/entities/entities';

/**
 * Generated class for the HomePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

 @IonicPage()
 @Component({
 	selector: 'page-home',
 	templateUrl: 'home.html',
 	providers: [OrderByPipe]
 })
 export class HomePage {
 	chatList: any = [];
 	currentActiveList: any = [];
 	todayDateValue : any;
 	yesterdayDateValue: any;
 	constructor(public navCtrl: NavController, public navParams: NavParams, public roomService: RoomserviceProvider, public authService: AuthProvider, public userService: UserServiceProvider, public orderBy: OrderByPipe, public roomDetail: RoomDetail, public User: AuthUser,public membersAndrooms: MembersAndRooms, public messageService: MessageServiceProvider) {
 		this.authService.ensureAuthenticate().then(user=>{
 			this.loadGroupsAndUsers();
 			// user message listener
 			this.userService.UserMessageListiner();
 			// user message listener end

 			// group message listener
 			this.messageService.groupMessageAdded();
 			// group message listener end

 			// group added listener
 			this.roomService.setupGroupAddedListener();
 			// group added listener end

 			// for home page for own user messasge listener
 			this.userService.ownUserMessageListener();
 			// for home page for own user messasge listener end

 			// group removed listener
 			this.roomService.setupGroupRemovedListener();
 			// group removed listener end


 			this.userService.userChatsToListUser();

 			// this.userService.userDataChanged();


 			this.todayDateValue = new Date().valueOf();
 			this.yesterdayDateValue = new Date().setDate(new Date().getDate() - 1).valueOf();
 		})
 	}

 	ionViewDidLoad() {
 		// console.log('ionViewDidLoad HomePage');
 		
 	}

 	// load group and users 

 	loadGroupsAndUsers(){
 		this.roomService.loadGroupsLastConv().then(roomList=>{
 			if (roomList && roomList.length) {
 				this.currentActiveList = roomList;
 			}
 			this.userService.loadUserList().then(userList=>{
 				let userFinalList : any = [];
 				if (userList && userList.length) {
 					// console.log(userList, 'user list');
 					this.userService.loadUsersListAddEventListener().then(convList=>{
 						if (convList) {
 							userList.forEach((list)=>{
 								convList.forEach((conv)=>{ 									
 									if ((list.id == conv.from_userId && conv.to_user_id== this.User.id) || (list.id == conv.to_user_id && conv.from_userId == this.User.id)) {
 										list.last_message_content = conv.text;
 										list.displayDate = conv.timestamp;
 										list.createdAt = conv.timestamp;
 										this.currentActiveList.push(list);
 										// add to member rooms
 										this.membersAndrooms.membersRoom.push(list);
 									}
 								})
 							}); 							

 							// console.log(this.currentActiveList, 'current active list');
 							this.currentActiveList = this.orderBy.transform(this.currentActiveList, ['-createdAt']);
 							// assign members and rooms data to entity
 							// Object.assign(this.membersAndrooms.membersRoom, this.currentActiveList);
 							// assign members and rooms data to entity end

 							// remove duplicate from array
 							let memberValues = [];
 							let keys = [];
 							this.membersAndrooms.membersRoom.forEach(list=>{
 								let key = list.id || list.roomId;
 								if (keys.indexOf(key) == -1) {
 									keys.push(key);
 									memberValues.push(list);
 								}
 							});
 							this.membersAndrooms.membersRoom = memberValues;
 							this.membersAndrooms.membersRoom =  this.orderBy.transform(this.membersAndrooms.membersRoom, ['-createdAt']);
 							// remove duplicate from array end
 							console.log(this.membersAndrooms.membersRoom, 'member room');
 						}
 					}); 					
 				}
 			})
 		});
 	}

 	// load group and users end

 	chatInGroup(groupDetail, redirectTo){
 		let setRoomDetail =  {
 			createdAt: groupDetail.createdAt,
 			lastMessage: groupDetail.last_message_content,
 			roomId: groupDetail.roomId,
 			name: groupDetail.name,
 			lastMessageUser: groupDetail.last_message_user,
 			role: groupDetail.role
 		}
 		Object.assign(this.roomDetail, setRoomDetail);
 		if (redirectTo == 'groupChat') { 			
 			this.navCtrl.push('RoomChatPage', groupDetail);
 		}
 		if(redirectTo == 'groupInfo'){
 			this.navCtrl.push('RoomInfoPage', groupDetail);
 		}
 	}

 	chatToUser(userData){
 		this.navCtrl.push('ChatPage',userData);
 	}

 	viewUserList(){
 		this.navCtrl.push('UserlistPage');
 	}

 }

