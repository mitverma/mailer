import { NgModule } from '@angular/core';
import { FiltersPipe, SplitByType } from './filters/filters';
@NgModule({
	declarations: [ SplitByType, FiltersPipe],
	imports: [],
	exports: [ SplitByType, FiltersPipe]
})
export class PipesModule {}
