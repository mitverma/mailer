if( 'function' === typeof importScripts) 
{
	importScripts('https://www.gstatic.com/firebasejs/5.2.0/firebase.js');
	importScripts('https://www.gstatic.com/firebasejs/5.2.0/firebase-app.js');
	importScripts('https://www.gstatic.com/firebasejs/5.2.0/firebase-messaging.js');
	//importScripts('js/init_firebase.js');

	var config = {
		apiKey: "AIzaSyBRjdIf9S7z1yPGWzCaOt-Mc-GRoBNQn7k",
		authDomain: "salesapp-61b90.firebaseapp.com",
		databaseURL: "https://salesapp-61b90.firebaseio.com",
		projectId: "salesapp-61b90",
		storageBucket: "salesapp-61b90.firebaseapp.com",
		messagingSenderId: "1950497765"
	};
	firebase.initializeApp(config);

	const messaging = firebase.messaging();
	console.log(messaging);
	messaging.setBackgroundMessageHandler(function(payload) {
		console.log('[firebase-messaging-sw.js] Received background message ', payload);
		alert(payload)
		var notificationTitle = payload.notification.title;
		var notificationOptions = {
			body: payload.notification.body,
			click_action: payload.notification.click_action
		};
		console.log(payload);
		return window.registration.showNotification(notificationTitle,notificationOptions);
	});
	
	self.addEventListener('notificationclick', function(event) {
		alert('sdfasd');
		event.notification.close();

		event.waitUntil(clients.openWindow('https://console.firebase.google.com'));
	});
	

}
