var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as firebase from 'firebase';
import { AuthUser, MembersAndRooms, RoomDetail, DeviceInformation } from '../../providers/entities/entities';
import { DevicestorageProvider } from '../../providers/devicestorage/devicestorage';
/*
  Generated class for the AuthProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
  */
var AuthProvider = /** @class */ (function () {
    function AuthProvider(http, User, deviceStorage, roomDetail, membersAndrooms, deviceInfo) {
        this.http = http;
        this.User = User;
        this.deviceStorage = deviceStorage;
        this.roomDetail = roomDetail;
        this.membersAndrooms = membersAndrooms;
        this.deviceInfo = deviceInfo;
        console.log('Hello AuthProvider Provider');
        this.userListPath = firebase.database().ref().child('users');
    }
    Object.defineProperty(AuthProvider.prototype, "getUser", {
        get: function () {
            return this.User;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AuthProvider.prototype, "setUser", {
        set: function (value) {
            this.User = value;
        },
        enumerable: true,
        configurable: true
    });
    AuthProvider.prototype.signup = function (userData) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            return firebase.auth().createUserWithEmailAndPassword(userData.email, userData.password).then(function (value) {
                if (value) {
                    // get device info
                    _this.deviceStorage.getDeviceInfo().then(function (res) {
                        _this.deviceInfo = res;
                    });
                    // get device info end
                    console.log(value, 'value');
                    userData.uid = value.user.uid;
                    userData.deviceToken = _this.deviceInfo ? _this.deviceInfo.deviceToken : '',
                        // this.setUser = this.User; 
                        // return userData;
                        resolve(userData);
                }
            }).catch(function (error) {
                console.log('Something went wrong:', error.message);
                // return error;
                reject(error);
            });
        });
        return promise;
    };
    ;
    AuthProvider.prototype.login = function (email, password) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            return firebase.auth().signInWithEmailAndPassword(email, password).then(function (value) {
                if (value) {
                    console.log(value, value.user.uid);
                    // firebase.database().ref().child('userList').orderByChild("uid").equalTo(value.user.uid).once('value', (snapShot)=>{
                    firebase.database().ref().child('users').orderByChild("uid").equalTo(value.user.uid).once('value', function (snapShot) {
                        var userValue = snapShot.val();
                        // console.log(userValue, 'user value', Object.keys(userValue),);
                        if (userValue) {
                            // get device info
                            _this.deviceStorage.getDeviceInfo().then(function (res) {
                                _this.deviceInfo = res;
                            });
                            // get device info end
                            var userArrayDetail = Object.keys(userValue).map(function (keys) { return userValue[keys]; });
                            var userDetail_1 = {
                                uid: userArrayDetail[0] ? userArrayDetail[0].uid : value.user.uid,
                                displayName: userArrayDetail[0] ? userArrayDetail[0].displayName : userArrayDetail[0].username,
                                email: userArrayDetail[0] ? userArrayDetail[0].email : value.user.uid,
                                id: Object.keys(userValue) ? Object.keys(userValue)[0] : Object.keys(snapShot.val())[0],
                                deviceToken: _this.deviceInfo ? _this.deviceInfo.deviceToken : '',
                                username: userArrayDetail[0].username,
                                status: true,
                            };
                            Object.assign(_this.User, userDetail_1);
                            // get random color
                            var randomColor = _this.getRandomColor();
                            console.log(randomColor, 'color');
                            // get random color end
                            // update device token in firebase
                            _this.userListPath.child(userDetail_1.id).update({ deviceToken: userDetail_1.deviceToken, color: randomColor }).then(function (res) {
                                console.log(res, 'res');
                            });
                            // update device token in firebase end
                            // device storage
                            return _this.deviceStorage.setValue(_this.User.auth_token, _this.User).then(function (user) {
                                resolve(userDetail_1);
                                return user ? user : _this.User;
                            }).catch(function (error) {
                                return null;
                            });
                            // device storage end
                        }
                        else {
                            var error = {
                                message: 'Please register to continue',
                            };
                            reject(error);
                        }
                    });
                }
            })
                .catch(function (error) {
                console.log('Something went wrong:', error.message);
                // return error;
                reject(error);
            });
        });
        return promise;
    };
    ;
    AuthProvider.prototype.logout = function () {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            _this.userListPath.child(_this.User.id).update({ deviceToken: '' });
            return firebase.auth().signOut().then(function (data) {
                Object.assign(_this.User, new AuthUser());
                Object.assign(_this.roomDetail, new RoomDetail());
                Object.assign(_this.membersAndrooms, new MembersAndRooms());
                // Object.assign(this.deviceInfo, new DeviceInformation());
                _this.deviceStorage.removeValue('APP_USER');
                resolve();
            }).catch(function (error) {
                console.log(error);
                resolve(error);
            });
        });
        return promise;
        // firebase.auth().signOut();
    };
    AuthProvider.prototype.setPassword = function (email) {
        var promise = new Promise(function (resolve, reject) {
            return firebase.auth().sendPasswordResetEmail(email).then(function (data) {
                console.log(data, 'data');
            }).catch(function (error) {
                reject(error);
            });
        });
        return promise;
    };
    ;
    AuthProvider.prototype.ensureAuthenticate = function () {
        var _this = this;
        return this.deviceStorage.getValue(this.User.auth_token).then(function (user) {
            return user ? Object.assign(_this.User, user) : _this.User;
        }).catch(function () {
            return null;
        });
    };
    AuthProvider.prototype.authenticateUser = function () {
        var _this = this;
        firebase.auth().onAuthStateChanged(function (user) {
            if (user.uid != _this.User.uid) {
                // this.updateUserList();
            }
        });
    };
    // create random color
    AuthProvider.prototype.getRandomColor = function () {
        var letters = '0123456789ABCDEF';
        var color = '#';
        for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    };
    AuthProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [HttpClient, AuthUser, DevicestorageProvider, RoomDetail, MembersAndRooms, DeviceInformation])
    ], AuthProvider);
    return AuthProvider;
}());
export { AuthProvider };
//# sourceMappingURL=auth.js.map