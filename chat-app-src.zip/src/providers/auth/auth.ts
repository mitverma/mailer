import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import * as firebase from 'firebase';
import { AuthUser, MembersAndRooms, RoomDetail, DeviceInformation } from '../../providers/entities/entities';
import { DevicestorageProvider } from '../../providers/devicestorage/devicestorage';
import { FcmserviceProvider } from '../../providers/fcmservice/fcmservice';

/*
  Generated class for the AuthProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
  */
  @Injectable()
  export class AuthProvider {
    conversationPath: any;
    userListPath: any;
    constructor(public http: HttpClient, public User: AuthUser, public deviceStorage: DevicestorageProvider, public roomDetail: RoomDetail, public membersAndrooms: MembersAndRooms, public deviceInfo: DeviceInformation, public fcmService: FcmserviceProvider) {
      console.log('Hello AuthProvider Provider');    
      this.userListPath = firebase.database().ref().child('users');
    }

    get getUser(): AuthUser {
      return this.User;
    }

    set setUser(value: AuthUser) { 
      this.User = value;
    }

    signup(userData): Promise<any>{
      let promise = new Promise((resolve, reject)=>{
        return firebase.auth().createUserWithEmailAndPassword(userData.email, userData.password).then((value)=>{
          if (value) {


            // get device info
            this.deviceStorage.getDeviceInfo().then(res=>{
              this.deviceInfo = res;
            })
            // get device info end
            
            console.log(value, 'value');
            userData.uid = value.user.uid;
            userData.deviceToken = this.fcmService.getTokenFromDb(),
            // this.setUser = this.User; 
            // return userData;
            resolve(userData);
          }
        }).catch(error=>{
          console.log('Something went wrong:',error.message);
          // return error;
          reject(error);
        })
      });
      return promise;      
    };

    login(email: string, password: string) : Promise<any> {
      let promise = new Promise((resolve, reject)=>{
        return firebase.auth().signInWithEmailAndPassword(email, password).then(value => {
          if (value) {
            console.log(value, value.user.uid);
            // firebase.database().ref().child('userList').orderByChild("uid").equalTo(value.user.uid).once('value', (snapShot)=>{
              firebase.database().ref().child('users').orderByChild("uid").equalTo(value.user.uid).once('value', (snapShot)=>{
                let userValue = snapShot.val();
                // console.log(userValue, 'user value', Object.keys(userValue),);
                if (userValue) {

                  // get device info
                  this.deviceStorage.getDeviceInfo().then(res=>{
                    this.deviceInfo = res;
                  })
                  // get device info end

                  let userArrayDetail = Object.keys(userValue).map(keys => userValue[keys]);
                  let userDetail = {
                    uid : userArrayDetail[0] ? userArrayDetail[0].uid : value.user.uid,
                    displayName :  userArrayDetail[0] ? userArrayDetail[0].displayName : userArrayDetail[0].username,
                    email :  userArrayDetail[0] ?  userArrayDetail[0].email: value.user.uid,
                    id: Object.keys(userValue) ? Object.keys(userValue)[0] : Object.keys(snapShot.val())[0],
                    deviceToken :  this.fcmService.getTokenFromDb(),
                    username: userArrayDetail[0].username,
                    status :  true,
                  };
                  Object.assign(this.User, userDetail);


                  // get random color
                  let randomColor = this.getRandomColor();
                  console.log(randomColor, 'color');
                  // get random color end

                  // update device token in firebase
                  this.userListPath.child(userDetail.id).update({deviceToken: userDetail.deviceToken, color: randomColor}).then(res=>{
                    console.log(res, 'res');
                  });
                  // update device token in firebase end

                  // device storage
                  return this.deviceStorage.setValue(this.User.auth_token, this.User).then((user) => {
                    resolve(userDetail);
                    return user ? user : this.User;
                  }).catch((error) => {
                    return null
                  }); 
                  // device storage end
                }else {
                  let error = {
                    message: 'Please register to continue',
                  }
                  reject(error);
                }
              })
            }
          })
        .catch(error => {
          console.log('Something went wrong:',error.message);
          // return error;
          reject(error);
        });
      });
      return promise;      
    };

    logout(): Promise<any>{
      let promise = new Promise((resolve, reject)=>{
        this.userListPath.child(this.User.id).update({deviceToken: ''});
        return firebase.auth().signOut().then((data)=>{
          Object.assign(this.User, new AuthUser());
          Object.assign(this.roomDetail, new RoomDetail());
          Object.assign(this.membersAndrooms, new MembersAndRooms());
          // Object.assign(this.deviceInfo, new DeviceInformation());
          this.deviceStorage.removeValue('APP_USER');
          this.fcmService.deleteToken();
          this.fcmService.setTokenSentToServer(false);
          this.fcmService.setTokenToDB(null);
          resolve();
        }).catch(error=>{
          console.log(error);
          resolve(error);
        });       
      });
      return promise;
      // firebase.auth().signOut();
    }

    setPassword(email): Promise<any>{
      let promise = new Promise((resolve, reject)=>{
        return firebase.auth().sendPasswordResetEmail(email).then(data=>{
          console.log(data, 'data');
        }).catch(error=>{
          reject(error);
        });
      })
      return promise;
    };

    ensureAuthenticate(){
      return this.deviceStorage.getValue(this.User.auth_token).then((user) => {
        return user ? Object.assign(this.User, user) : this.User;
      }).catch(() => {
        return null;
      });
    }

    authenticateUser(){
      firebase.auth().onAuthStateChanged((user: any)=>{
        if (user.uid != this.User.uid) {
          // this.updateUserList();
        }
      })  
    }


    // create random color
    getRandomColor() {
      var letters = '0123456789ABCDEF';
      var color = '#';
      for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
      }
      return color;
    }
    // create random color end

  }
