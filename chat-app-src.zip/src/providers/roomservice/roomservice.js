var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { HttpClient } from '@angular/common/http';
import { Injectable, NgZone } from '@angular/core';
import * as firebase from 'firebase';
import { AuthUser, RoomDetail, MembersAndRooms } from '../../providers/entities/entities';
import { MessageServiceProvider } from '../message-service/message-service';
import * as Enumerable from "linq";
import { UserServiceProvider } from '../user-service/user-service';
import { OrderByPipe } from '../../pipes/filters/filters';
var RoomserviceProvider = /** @class */ (function () {
    function RoomserviceProvider(http, User, messageService, userService, roomDetail, membersAndrooms, ngZone, orderBy) {
        this.http = http;
        this.User = User;
        this.messageService = messageService;
        this.userService = userService;
        this.roomDetail = roomDetail;
        this.membersAndrooms = membersAndrooms;
        this.ngZone = ngZone;
        this.orderBy = orderBy;
        console.log('Hello RoomserviceProvider Provider');
        // this.roomPath =  firebase.database().ref().child('room-wala');
        // this.userListPath = firebase.database().ref().child('userList');
        // this.roomMessagePath = firebase.database().ref().child('roomwala-msg');
        this.roomPath = firebase.database().ref().child('room');
        this.userListPath = firebase.database().ref().child('users');
        this.roomMessagePath = firebase.database().ref().child('room-messages');
    }
    // listener for group
    RoomserviceProvider.prototype.setupGroupAddedListener = function () {
        var _this = this;
        var groupList = [];
        var promise = new Promise(function (resolve, reject) {
            return _this.userListPath.child(_this.User.id).on('child_added', function (snapShot) {
                var conversation = _this.mappedUserGroupData(snapShot);
                if (conversation) {
                    var newRoom_1 = true;
                    if (_this.membersAndrooms && _this.membersAndrooms.membersRoom) {
                        _this.membersAndrooms.membersRoom.forEach(function (list) {
                            if (list.roomId == conversation.roomId) {
                                newRoom_1 = false;
                            }
                        });
                        if (newRoom_1) {
                            conversation.last_message_content = 'Added you to group';
                            _this.membersAndrooms.membersRoom.push(conversation);
                        }
                    }
                    groupList.push(conversation);
                    resolve(groupList);
                }
                ;
                _this.ngZone.run(function (data) {
                    _this.membersAndrooms.membersRoom = _this.membersAndrooms.membersRoom;
                });
                _this.orderBy.transform(_this.membersAndrooms.membersRoom, ['-createdAt']);
            });
        });
        return promise;
    };
    // listener for group end
    RoomserviceProvider.prototype.createRoom = function (roomDetail, roomMemberList) {
        var _this = this;
        var userData = {
            email: this.User.email,
            id: this.User.id,
            name: this.User.displayName,
            status: true,
            uid: this.User.uid,
        };
        roomMemberList.push(userData);
        var modifiedMemberList = [];
        var idKey = this.roomPath.push().key;
        var roomInfo = {
            private: false,
            name: roomDetail.name,
            role: 'owner',
            uid: this.User.id,
            createdAt: firebase.database.ServerValue.TIMESTAMP,
            last_message: '',
            last_message_time: firebase.database.ServerValue.TIMESTAMP,
            imgUrl: '',
            color: this.getRandomColor()
        };
        return this.roomPath.child(idKey).set(roomInfo).then(function () {
            roomMemberList.forEach(function (members) {
                var memberApplicant = {
                    displayName: roomDetail.name,
                    // displayName: members.email ? members.email : members.displayName,
                    role: 'member',
                    uid: members.id,
                    createdAt: firebase.database.ServerValue.TIMESTAMP
                };
                if (members.id == _this.User.id) {
                    memberApplicant.role = 'owner';
                }
                ;
                modifiedMemberList.push(memberApplicant);
                modifiedMemberList.forEach(function (newMember) {
                    _this.userListPath.child(newMember.uid).child(idKey).set(newMember).then(function () {
                        _this.roomPath.child(idKey).child(newMember.uid).set(newMember).then(function () {
                            console.log('in');
                        });
                    });
                });
            });
            _this.messageService.get(idKey).then(function () {
                var defaultmessge = {
                    text: 'Group created',
                    imgUrl: '',
                };
                _this.messageService.sendGroupMessage(idKey, defaultmessge, '');
            });
        });
    };
    RoomserviceProvider.prototype.deleteRoom = function (roomId) {
        // this.getMemberRole.then((res)=>{
        var _this = this;
        // })
        var query = this.userListPath.orderByKey().once('value');
        query.then(function (snapshot) {
            snapshot.forEach(function (childSnapShot) {
                var userId = childSnapShot.key;
                _this.userListPath.child(userId).child(roomId).remove().then(function (data) {
                    _this.roomPath.child(roomId).set(null).then(function (res) {
                        console.log(res, 'res room id is deleted');
                    });
                });
            });
        });
    };
    RoomserviceProvider.prototype.deleteRoomMember = function (roomId, memberId) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            _this.getMemberRole(roomId).then(function (memberRole) {
                if (memberRole) {
                    var query = _this.roomPath.child(roomId).child(memberId);
                    _this.userListPath.child(memberId).child(roomId).off();
                    query.remove().then(function (data) {
                        _this.userListPath.child(memberId).child(roomId).remove().then(function (data) {
                            console.log('Delete User from Room::', data);
                            resolve(data);
                        });
                    });
                }
            });
        });
        return promise;
    };
    RoomserviceProvider.prototype.getMemberRole = function (roomId) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            var query = _this.roomPath.child(roomId).child(_this.User.id).orderByChild('uid').once('value');
            return query.then(function (snapShot) {
                var returnVal;
                var data = snapShot.child('role').val();
                if (data == 'owner') {
                    returnVal = true;
                    // return data;
                }
                else {
                    // return data;
                }
                resolve(returnVal);
            });
        });
        return promise;
    };
    RoomserviceProvider.prototype.loadGroups = function () {
        var roomList = [];
        var query = this.userListPath.orderByKey().equalTo(this.User.id).once('value');
        var newQuery = this.userListPath.orderByKey().equalTo(this.User.id);
        newQuery.once('value', function (snap) {
            return console.log(snap.val(), 'value');
        });
        return Promise.all([query]).then(function (childSnapshot) {
            console.log(childSnapshot, 'childSnapshot');
        });
    };
    RoomserviceProvider.prototype.mappedUserGroupData = function (childSnapshot) {
        var key = childSnapshot.key;
        var childData = childSnapshot.val();
        if (childData && childSnapshot.hasChildren()) {
            var roomData = {
                roomId: key,
                name: childData.displayName,
                displayName: childData.displayName,
                role: childData.role ? childData.role : "unknown",
                last_message_content: childData.last_message ? childData.last_message : '',
                type: 'group',
                createdAt: childData.createdAt ? childData.createdAt : (new Date('1900-01-01')).valueOf(),
                displayDate: childData.createdAt,
                last_message_user: childData.last_message_user ? childData.last_message_user : '',
                color: childData.color ? childData.color : this.getRandomColor()
            };
        }
        return roomData;
    };
    // loadgroup with last conversation
    RoomserviceProvider.prototype.loadGroupsLastConv = function () {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            var roomList = [];
            if (_this.User && _this.User.id) {
                var query = _this.userListPath.orderByKey().equalTo(_this.User.id).once('value');
                return query.then(function (childSnapShot) {
                    childSnapShot.forEach(function (childSnapShot) {
                        childSnapShot.forEach(function (childSnapShot) {
                            var childData = _this.mappedUserGroupData(childSnapShot);
                            var roomMessageQuery = _this.roomMessagePath.child(childSnapShot.key).limitToLast(1).once('value');
                            roomMessageQuery.then(function (childSSMessage) {
                                var message = Enumerable.from(childSSMessage.val()).select(function (x) { return x.value; }).firstOrDefault();
                                if (message) {
                                    childData.last_message_content = message.content;
                                    childData.last_message_user = message.sender_email;
                                    childData.createdAt = message.createdAt;
                                    roomList.push(childData);
                                }
                                if (roomList && roomList.length) {
                                    resolve(roomList);
                                }
                                else if (roomList.length == 0) {
                                    resolve();
                                }
                            });
                        });
                    });
                });
            }
        });
        return promise;
    };
    // loadgroup with last conversation end
    // get members in room
    RoomserviceProvider.prototype.getMemberInRoom = function (roomId) {
        var _this = this;
        var groupMemberList = [];
        var count = 0;
        var promise = new Promise(function (resolve, reject) {
            var query = _this.roomPath.child(roomId).once('value');
            return _this.userService.loadUsers().then(function (userData) {
                if (userData) {
                    return query.then(function (snapShot) {
                        var roomDetails = snapShot.val();
                        roomDetails = Object.keys(roomDetails).map(function (key) {
                            if (roomDetails[key] && roomDetails[key].role) {
                                return roomDetails[key];
                            }
                        });
                        roomDetails = roomDetails.filter(function (list) {
                            return list != undefined;
                        });
                        userData.forEach(function (userlist) {
                            roomDetails.forEach(function (roomList) {
                                if (userlist.id == roomList.uid) {
                                    userlist.role = roomList.role;
                                    userlist.roomList = [];
                                    groupMemberList.push(userlist);
                                }
                                ;
                            });
                        });
                        resolve(groupMemberList);
                        console.log(groupMemberList, 'user data');
                    });
                }
            });
        });
        return promise;
    };
    // get members in room end
    // update a role in group 
    RoomserviceProvider.prototype.updateRole = function (roomId, groupUserId, role) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            return _this.getMemberRole(roomId).then(function (memberRole) {
                if (memberRole) {
                    var query = _this.roomPath.child(roomId).child(groupUserId).update({ role: role }).then(function (data) {
                        _this.userListPath.child(groupUserId).child(roomId).update({ role: role }).then(function (data) {
                            resolve(data);
                        });
                    });
                }
            });
        });
        return promise;
    };
    // update a role in group  end
    // current room detail
    RoomserviceProvider.prototype.getRoomDetails = function (roomId) {
        var _this = this;
        var roomData = {};
        var promise = new Promise(function (resolve, reject) {
            var query = _this.roomPath.child(roomId).orderByKey().once('value');
            return query.then(function (snapShot) {
                var key = snapShot.key;
                var childData = snapShot.val();
                if (childData) {
                    roomData = {
                        roomid: key,
                        name: childData.name,
                        createdAt: childData.createdAt,
                        role: childData.role,
                    };
                    resolve(roomData);
                }
            });
        });
        return promise;
    };
    // current room detail end
    // update group name 
    RoomserviceProvider.prototype.updateGroupName = function (roomId, title) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            if (roomId && title) {
                _this.roomPath.child(roomId).update({ name: title });
                var query = _this.roomPath.child(roomId).once('value');
                return query.then(function (snap) {
                    var snapValue = snap.val();
                    snapValue = Object.keys(snapValue).map(function (key) {
                        console.log(snapValue[key]);
                        return snapValue[key];
                    });
                    snapValue = snapValue.filter(function (list) {
                        return list && list.uid;
                    });
                    console.log(snapValue);
                    snapValue.forEach(function (list) {
                        var query = _this.roomPath.child(roomId).child(list.uid).update({ displayName: title }).then(function (data) {
                            _this.userListPath.child(list.uid).child(roomId).update({ displayName: title }).then(function (data) {
                                resolve(data);
                            });
                        });
                    });
                });
            }
        });
        return promise;
        // previous code
        // if (roomId && title) {
        // 	let query = this.roomPath.child(roomId).update({name: title});
        // 	return query;
        // }
        // previous code end
    };
    ;
    // update group name end
    RoomserviceProvider.prototype.addMemberToGroup = function (membersToAdd, roomId) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            var addedGroupMemList = [];
            membersToAdd.forEach(function (member) {
                var userQuery = _this.userListPath.child(member.id).child(roomId);
                var memberApplicant = {
                    nickname: member.email ? member.email : member.name,
                    displayName: _this.roomDetail ? _this.roomDetail.name : '',
                    role: 'member',
                    uid: member.id,
                    createdAt: firebase.database.ServerValue.TIMESTAMP,
                };
                userQuery.on('value', function (snapData) {
                    if (snapData.val() == null) {
                        userQuery.set(memberApplicant);
                    }
                });
                var roomQuery = _this.roomPath.child(roomId).child(member.id);
                roomQuery.on('value', function (snapData1) {
                    if (snapData1.val() == null) {
                        roomQuery.set(memberApplicant);
                        if (_this.User.id !== member.id) {
                            member.role = 'member';
                            addedGroupMemList.push(member);
                            if (addedGroupMemList && addedGroupMemList.length >= membersToAdd.length) {
                                resolve(addedGroupMemList);
                            }
                        }
                    }
                });
            });
        });
        return promise;
    };
    // group removed listener
    RoomserviceProvider.prototype.setupGroupRemovedListener = function () {
        var _this = this;
        this.userListPath.child(this.User.id).on('child_removed', function (snapShot) {
            console.log(snapShot.val(), 'snap val');
            var conversation = _this.mappedUserGroupData(snapShot);
            if (conversation) {
                console.log(snapShot, 'conversation');
                if (_this.membersAndrooms.membersRoom && _this.membersAndrooms.membersRoom) {
                    // this.membersAndrooms.membersRoom.forEach((list, index)=>{
                    // 	if (list.roomId == conversation.roomId) {
                    // 		this.membersAndrooms.membersRoom.splice(index, 1);
                    // 	}
                    // });
                    _this.membersAndrooms.membersRoom = _this.membersAndrooms.membersRoom.filter(function (list) {
                        return list.roomId != conversation.roomId;
                    });
                    _this.ngZone.run(function (data) {
                        _this.membersAndrooms.membersRoom = _this.membersAndrooms.membersRoom;
                    });
                    console.log(_this.membersAndrooms.membersRoom, 'member room');
                    _this.orderBy.transform(_this.membersAndrooms.membersRoom, ['-createdAt']);
                }
            }
        });
    };
    // group removed listener end
    // create random color
    RoomserviceProvider.prototype.getRandomColor = function () {
        var letters = '0123456789ABCDEF';
        var color = '#';
        for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    };
    RoomserviceProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [HttpClient, AuthUser, MessageServiceProvider, UserServiceProvider, RoomDetail, MembersAndRooms, NgZone, OrderByPipe])
    ], RoomserviceProvider);
    return RoomserviceProvider;
}());
export { RoomserviceProvider };
//# sourceMappingURL=roomservice.js.map