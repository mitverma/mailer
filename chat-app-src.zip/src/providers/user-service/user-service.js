var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Events } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { Injectable, NgZone } from '@angular/core';
import * as firebase from 'firebase';
import { AuthUser, MembersAndRooms, DeviceInformation } from '../../providers/entities/entities';
import { Observable } from 'rxjs';
import { DevicestorageProvider } from '../../providers/devicestorage/devicestorage';
import { MessageServiceProvider } from '../../providers/message-service/message-service';
import { OrderByPipe } from '../../pipes/filters/filters';
var UserServiceProvider = /** @class */ (function () {
    function UserServiceProvider(http, User, deviceStorage, messageService, events, membersAndrooms, orderBy, ngZone, deviceInfo) {
        this.http = http;
        this.User = User;
        this.deviceStorage = deviceStorage;
        this.messageService = messageService;
        this.events = events;
        this.membersAndrooms = membersAndrooms;
        this.orderBy = orderBy;
        this.ngZone = ngZone;
        this.deviceInfo = deviceInfo;
        console.log('Hello UserServiceProvider Provider');
        // this.dbReference = firebase.database().ref();
        // this.userListPath = firebase.database().ref().child('userList');
        // this.conversationPath = firebase.database().ref().child('conversation-chat');
        this.dbReference = firebase.database().ref();
        this.userListPath = firebase.database().ref().child('users');
        this.conversationPath = firebase.database().ref().child('conversations');
    }
    UserServiceProvider.prototype.setToUserList = function (setUser) {
        var _this = this;
        this.deviceStorage.getDeviceInfo().then(function (res) {
            if (res) {
                _this.deviceInfo = res;
            }
        });
        var setUserDetail = {
            uid: setUser.uid,
            displayName: setUser.name,
            email: setUser.email,
            deviceToken: this.deviceInfo ? this.deviceInfo.deviceToken : '',
            status: true,
            username: setUser.name,
            id: '',
        };
        var idKey = this.userListPath.push().key;
        this.userListPath.child(idKey).set(setUserDetail);
        setUserDetail.id = idKey;
        setUserDetail.deviceToken = this.deviceInfo ? this.deviceInfo.deviceToken : '';
        // assig auth user
        Object.assign(this.User, setUserDetail);
        // device storage
        return this.deviceStorage.setValue(this.User.auth_token, this.User).then(function (user) {
            return user ? user : _this.User;
        }).catch(function () {
            return null;
        });
        // device storage end
        // assig auth user end
    };
    UserServiceProvider.prototype.updateUserList = function () {
    };
    UserServiceProvider.prototype.getUserList = function () {
        var _this = this;
        var list = [];
        return new Observable(function (observer) {
            _this.dbReference.on('value', function (snapshot) {
                var getList = snapshot.val();
                // list =  Object.keys(getList.userList).map((key)=>{
                list = Object.keys(getList.users).map(function (key) {
                    if ((_this.User && _this.User.uid) !== (getList.users[key] && getList.users[key].uid)) {
                        getList.users[key].id = key;
                        return getList.users[key];
                    }
                });
                return list;
            });
            observer.next(list);
            observer.complete();
        });
    };
    UserServiceProvider.prototype.UsersUpdateventListener = function () {
        this.userListPath.on('child_added', function (Snapshot) {
            console.log(Snapshot.val(), 'Snapshot');
            // onUpdate(userdata);
        });
    };
    UserServiceProvider.prototype.UserMessageListiner = function () {
        var _this = this;
        var getList;
        // this.conversationPath.on('child_added', (snapshot)=>{
        // this.conversationPath.orderByChild('from_userId').limitToLast(1).on('child_added', (snapshot)=>{
        this.conversationPath.orderByChild('to_user_id').equalTo(this.User.id).limitToLast(1).on('child_added', function (snapshot) {
            if (snapshot) {
                // console.log(snapshot.val(), 'snapshot');
                var lastUpdatedChat_1 = snapshot.val();
                if (lastUpdatedChat_1) {
                    _this.events.publish('userChat:Added', lastUpdatedChat_1);
                    var newEntryObj_1 = true;
                    if (_this.membersAndrooms && _this.membersAndrooms.membersRoom) {
                        _this.membersAndrooms.membersRoom.forEach(function (list) {
                            // if (newEntryObj) {
                            // 	if (list.id == lastUpdatedChat.to_user_id || list.id == lastUpdatedChat.from_userId) {
                            // 		list.last_message_content = lastUpdatedChat.text;
                            // 		list.createdAt = lastUpdatedChat.timestamp;
                            // 		newEntryObj = false;
                            // 		this.ngZone.run(()=>{
                            // 			this.membersAndrooms.membersRoom = this.membersAndrooms.membersRoom;
                            // 		})
                            // 	}
                            // }
                            if (list.id == lastUpdatedChat_1.from_userId) {
                                list.last_message_content = lastUpdatedChat_1.text;
                                list.createdAt = lastUpdatedChat_1.timestamp;
                                newEntryObj_1 = false;
                                _this.ngZone.run(function () {
                                    _this.membersAndrooms.membersRoom = _this.membersAndrooms.membersRoom;
                                });
                            }
                        });
                        if (newEntryObj_1) {
                            var newMember = {
                                color: undefined,
                                connected: undefined,
                                createdAt: lastUpdatedChat_1.timestamp,
                                displayDate: lastUpdatedChat_1.timestamp,
                                displayName: lastUpdatedChat_1.displayName ? lastUpdatedChat_1.displayName : lastUpdatedChat_1.from_username,
                                email: lastUpdatedChat_1.email ? lastUpdatedChat_1.email : lastUpdatedChat_1.from_username,
                                id: lastUpdatedChat_1.from_userId,
                                last_message_content: lastUpdatedChat_1.text,
                                last_message_user: "",
                                lastseen: "",
                                name: lastUpdatedChat_1.from_username,
                                role: "",
                                roomList: [],
                                type: "user",
                                uid: '',
                            };
                            _this.membersAndrooms.membersRoom.push(newMember);
                        }
                    }
                    _this.ngZone.run(function () {
                        _this.membersAndrooms.membersRoom = _this.membersAndrooms.membersRoom;
                    });
                    _this.orderBy.transform(_this.membersAndrooms.membersRoom, ['-createdAt']);
                }
            }
        }, function (error) {
            console.log(error);
        });
        // return new Observable(observer => {
        // 	this.conversationPath.on('child_added', (snapshot)=>{
        // 		getList = snapshot.val();
        // 		return getList;
        // 	})
        // 	observer.next(getList);
        // 	observer.complete();
        // });
    };
    UserServiceProvider.prototype.UsersAddEventListener = function () {
        var _this = this;
        var userList = [];
        var promise = new Promise(function (resolve, reject) {
            return _this.userListPath.on('child_added', function (snapShot) {
                if (snapShot) {
                    var userData = _this.mappedUserData(snapShot, {});
                    if (userData) {
                        userList.push(userData);
                        resolve(userList);
                    }
                }
            });
        });
        return promise;
    };
    UserServiceProvider.prototype.mappedUserData = function (childSnapshot, roomList) {
        var key = childSnapshot.key;
        var childData = childSnapshot.val();
        var userData = {
            id: '',
            name: '',
            email: '',
            displayName: '',
            uid: '',
            last_message_content: '',
            type: 'user',
            role: '',
            roomList: roomList,
            createdAt: (new Date('1900 01 01')).valueOf(),
            displayDate: "",
            last_message_user: '',
            color: "",
            connected: "",
            lastseen: "",
        };
        if (childData) {
            userData = {
                id: key,
                name: childData.name ? childData.name : childData.email,
                email: childData.email,
                displayName: childData.displayName,
                uid: childData.uid,
                last_message_content: '',
                type: 'user',
                role: '',
                roomList: roomList,
                createdAt: (new Date('1900 01 01')).valueOf(),
                displayDate: "",
                last_message_user: childData.last_message_user ? childData.last_message_user : '',
                color: childData.color ? childData.color : this.getRandomColor(),
                connected: childData.connected,
                lastseen: '',
            };
        }
        return userData;
    };
    ;
    // get user list
    UserServiceProvider.prototype.loadUserList = function () {
        var _this = this;
        var userList = [];
        var promise = new Promise(function (resolve, reject) {
            if (_this.User && _this.User.id) {
                var query = _this.userListPath.orderByChild('status').equalTo(true).once('value');
                return query.then(function (snapShot) {
                    if (snapShot) {
                        snapShot.forEach(function (childSnapShot) {
                            var userData = _this.mappedUserData(childSnapShot, []);
                            if (userData) {
                                userList.push(userData);
                                // return userList;
                            }
                            resolve(userList);
                        });
                    }
                });
            }
        });
        return promise;
    };
    // get user list end
    UserServiceProvider.prototype.loadUsersListAddEventListener = function () {
        var _this = this;
        var conversationList = [];
        var promise = new Promise(function (resolve, reject) {
            var query = _this.conversationPath.orderByChild('from_userId').equalTo(_this.User.id).limitToLast(1);
            return query.on('child_added', function (snapShot) {
                if (snapShot) {
                    var conversation = snapShot.val();
                    conversationList.push(conversation);
                }
                resolve(conversationList);
            });
        });
        return promise;
    };
    // load Users
    UserServiceProvider.prototype.loadUsers = function () {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            var roomList = [];
            var usersList = [];
            var query = _this.userListPath.orderByChild('status').equalTo(true).once('value');
            return query.then(function (snapShot) {
                if (snapShot) {
                    snapShot.forEach(function (childSnapShot) {
                        var key = childSnapShot.key;
                        childSnapShot.forEach(function (roomData) {
                            var roomKey = roomData.key;
                            var roomDetailObj = {
                                roomId: roomKey
                            };
                            roomList.push(roomDetailObj);
                        });
                        var userData = _this.mappedUserData(childSnapShot, roomList);
                        if (userData) {
                            usersList.push(userData);
                            resolve(usersList);
                        }
                    });
                }
            });
        });
        return promise;
    };
    ;
    // load Users end
    // get connectivity list
    UserServiceProvider.prototype.trackPresence = function () {
        var connectedRef = this.dbReference.child('/.info/connected');
        var myConnectionsRef = this.dbReference.child('/users/' + this.User.id + '/connected');
        var lastOnlineRef = this.dbReference.child('/users/' + this.User.id + '/lastseen');
        connectedRef.on('value', function (isOnline) {
            if (isOnline.val() === true) {
                myConnectionsRef.set(true);
                myConnectionsRef.onDisconnect().remove();
                lastOnlineRef.onDisconnect().set(firebase.database.ServerValue.TIMESTAMP);
            }
            else {
                myConnectionsRef.set(false);
            }
            console.info('Presence::', isOnline);
        });
    };
    ;
    // get connectivity list end
    // get members detail
    UserServiceProvider.prototype.getMemberDetails = function () {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            var query = _this.userListPath.child(_this.User.id).orderByChild('uid').once('value');
            return query.then(function (data) {
                var userDetail = data.val();
                resolve(userDetail);
            }).catch(function (error) {
                console.log(error, 'error');
                reject(error);
            });
        });
        return promise;
    };
    // get members detail end
    // update profile details
    UserServiceProvider.prototype.updateProfile = function (userProfileName) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            _this.userListPath.child(_this.User.id).update({ displayName: userProfileName }).then(function (data) {
                console.log(data, 'data');
                resolve();
            }).catch(function (error) {
                console.log(error, 'error');
                reject(error);
            });
        });
        return promise;
    };
    // update profile details end
    // listen own message and update on home screen page and list
    UserServiceProvider.prototype.ownUserMessageListener = function () {
        var _this = this;
        // this.conversationPath.orderByChild('from_userId').equalTo(this.User.id).limitToLast(1).on('child_added', (snapshot)=>{
        this.conversationPath.orderByChild('from_userId')
            .equalTo(this.User.id).limitToLast(1).on('child_added', function (snapshot) {
            if (snapshot) {
                var conversation_1 = snapshot.val();
                if (conversation_1) {
                    var newValue_1 = true;
                    if (_this.membersAndrooms && _this.membersAndrooms.membersRoom) {
                        _this.membersAndrooms.membersRoom.forEach(function (list) {
                            if (list.id == conversation_1.to_user_id || list.id == conversation_1.from_userId) {
                                list.last_message_content = conversation_1.text;
                                list.createdAt = conversation_1.timestamp;
                                list.displayDate = conversation_1.timestamp;
                                newValue_1 = false;
                            }
                        });
                        _this.orderBy.transform(_this.membersAndrooms.membersRoom, ['-createdAt']);
                    }
                    if (newValue_1) {
                        var enterObj_1 = false;
                        var userData_1 = {};
                        _this.loadUsers().then(function (usersList) {
                            usersList.forEach(function (list) {
                                if (list.id == conversation_1.to_user_id || list.id == conversation_1.from_userId) {
                                    userData_1 = {
                                        id: list.id,
                                        name: list.name ? list.name : list.email,
                                        email: list.email,
                                        displayName: list.displayName,
                                        uid: list.uid,
                                        last_message_content: conversation_1.text,
                                        type: 'user',
                                        role: '',
                                        roomList: [],
                                        createdAt: conversation_1.timestamp,
                                        displayDate: "",
                                        last_message_user: list.last_message_user ? list.last_message_user : '',
                                        color: list.color ? list.color : _this.getRandomColor(),
                                        connected: list.connected,
                                        lastseen: '',
                                    };
                                    enterObj_1 = true;
                                }
                            });
                            if (enterObj_1) {
                                _this.membersAndrooms.membersRoom.push(userData_1);
                                var memberValues_1 = [];
                                var keys_1 = [];
                                _this.membersAndrooms.membersRoom.forEach(function (list) {
                                    var key = list.id || list.roomId;
                                    if (keys_1.indexOf(key) == -1) {
                                        keys_1.push(key);
                                        memberValues_1.push(list);
                                    }
                                });
                                _this.membersAndrooms.membersRoom = memberValues_1;
                                _this.membersAndrooms.membersRoom = _this.orderBy.transform(_this.membersAndrooms.membersRoom, ['-createdAt']);
                                _this.ngZone.run(function () {
                                    _this.membersAndrooms.membersRoom = _this.membersAndrooms.membersRoom;
                                });
                            }
                        });
                    }
                }
            }
        });
    };
    // listen own message and update on home screen page and list end
    UserServiceProvider.prototype.userChatsToListUser = function () {
        var _this = this;
        var list = [];
        this.conversationPath.orderByChild('from_userId').equalTo(this.User.id).on('value', function (snap) {
            snap.forEach(function (snap) {
                if (snap.val()) {
                    list.push(snap.val());
                }
            });
            list = _this.orderBy.transform(list, ['-createdAt']);
            // remove duplicate from array
            var listMessages = [];
            var keys = [];
            list.forEach(function (list) {
                var key = list.to_user_id;
                if (keys.indexOf(key) == -1) {
                    keys.push(key);
                    listMessages.push(list);
                }
            });
            // console.log(listMessages, 'list Message');
            var userEntryData = {};
            var entryNew = false;
            _this.loadUserList().then(function (usersList) {
                var key = usersList;
                listMessages.forEach(function (listUsers) {
                    usersList.forEach(function (users) {
                        if (listUsers.to_user_id == users.id) {
                            userEntryData = {
                                id: users.id,
                                name: users.name ? users.name : users.email,
                                email: users.email,
                                displayName: users.displayName,
                                uid: users.uid,
                                last_message_content: listUsers.text,
                                type: 'user',
                                role: '',
                                roomList: [],
                                createdAt: listUsers.timestamp,
                                displayDate: "",
                                last_message_user: listUsers.last_message_user ? listUsers.last_message_user : '',
                                color: list.color ? list.color : _this.getRandomColor(),
                                connected: list.connected,
                                lastseen: '',
                            };
                            entryNew = true;
                            _this.membersAndrooms.membersRoom.push(userEntryData);
                        }
                    });
                });
                if (entryNew) {
                    // console.log(this.membersAndrooms.membersRoom, 'member room');
                    var memberValues_2 = [];
                    var keys_2 = [];
                    _this.membersAndrooms.membersRoom.forEach(function (list) {
                        var key = list.id || list.roomId;
                        if (keys_2.indexOf(key) == -1) {
                            keys_2.push(key);
                            memberValues_2.push(list);
                        }
                    });
                    _this.membersAndrooms.membersRoom = memberValues_2;
                    _this.membersAndrooms.membersRoom = _this.orderBy.transform(_this.membersAndrooms.membersRoom, ['-createdAt']);
                    _this.ngZone.run(function () {
                        _this.membersAndrooms.membersRoom = _this.membersAndrooms.membersRoom;
                    });
                }
            });
            // remove duplicate from array end
        });
    };
    // create random color
    UserServiceProvider.prototype.getRandomColor = function () {
        var letters = '0123456789ABCDEF';
        var color = '#';
        for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    };
    UserServiceProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [HttpClient, AuthUser, DevicestorageProvider, MessageServiceProvider, Events, MembersAndRooms, OrderByPipe, NgZone, DeviceInformation])
    ], UserServiceProvider);
    return UserServiceProvider;
}());
export { UserServiceProvider };
//# sourceMappingURL=user-service.js.map