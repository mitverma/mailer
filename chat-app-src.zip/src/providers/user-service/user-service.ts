import { Events } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { Injectable, NgZone } from '@angular/core';
import * as firebase from 'firebase';
import { AuthUser, MembersAndRooms, DeviceInformation } from '../../providers/entities/entities';
import { Observable } from 'rxjs';
import { DevicestorageProvider } from '../../providers/devicestorage/devicestorage';
import { MessageServiceProvider } from '../../providers/message-service/message-service';
import { OrderByPipe } from '../../pipes/filters/filters';


@Injectable()
export class UserServiceProvider {

	userListPath: any;
	dbReference: any;
	conversationPath:any;
	constructor(public http: HttpClient, public User: AuthUser, public deviceStorage: DevicestorageProvider, public messageService: MessageServiceProvider, public events: Events, public membersAndrooms: MembersAndRooms, public orderBy: OrderByPipe, public ngZone: NgZone, public deviceInfo: DeviceInformation,) {
		console.log('Hello UserServiceProvider Provider');
		// this.dbReference = firebase.database().ref();
		// this.userListPath = firebase.database().ref().child('userList');
		// this.conversationPath = firebase.database().ref().child('conversation-chat');
		this.dbReference = firebase.database().ref();
		this.userListPath = firebase.database().ref().child('users');
		this.conversationPath = firebase.database().ref().child('conversations');
	}


	setToUserList(setUser){

		this.deviceStorage.getDeviceInfo().then(res=>{
			if (res) {
				this.deviceInfo = res;
			}
		});

		let setUserDetail = {
			uid : setUser.uid,
			displayName :  setUser.name,
			email :  setUser.email,
			deviceToken :  this.deviceInfo ?  this.deviceInfo.deviceToken : '',
			status :  true,
			username: setUser.name,
			id: '',
		}
		let idKey = this.userListPath.push().key;
		this.userListPath.child(idKey).set(setUserDetail);

		setUserDetail.id = idKey;
		setUserDetail.deviceToken =  this.deviceInfo ? this.deviceInfo.deviceToken : '';

		// assig auth user

		Object.assign(this.User, setUserDetail);
		// device storage
		return this.deviceStorage.setValue(this.User.auth_token, this.User).then((user) => {
			return user ? user : this.User;
		}).catch(() => {
			return null;
		}); 
		// device storage end

		// assig auth user end

	}

	updateUserList(){

	}

	getUserList() : Observable<any[]>{
		let list: any = [];
		return new Observable(observer => {
			this.dbReference.on('value', (snapshot)=>{
				let getList = snapshot.val();
				// list =  Object.keys(getList.userList).map((key)=>{
					list =  Object.keys(getList.users).map((key)=>{
						if ((this.User && this.User.uid) !== (getList.users[key] && getList.users[key].uid)) {
							getList.users[key].id = key;
							return getList.users[key];
						}
					});
					return list;
				})
			observer.next(list);
			observer.complete();
		});
	}
	UsersUpdateventListener(){
		this.userListPath.on('child_added',function(Snapshot) {
			console.log(Snapshot.val(), 'Snapshot');
			// onUpdate(userdata);
		});  
	}

	UserMessageListiner(){
		let getList: any;
		// this.conversationPath.on('child_added', (snapshot)=>{
			// this.conversationPath.orderByChild('from_userId').limitToLast(1).on('child_added', (snapshot)=>{
				this.conversationPath.orderByChild('to_user_id').equalTo(this.User.id).limitToLast(1).on('child_added', (snapshot)=>{
					if (snapshot) {
						// console.log(snapshot.val(), 'snapshot');
						let  lastUpdatedChat = snapshot.val();				
						if (lastUpdatedChat) {
							this.events.publish('userChat:Added', lastUpdatedChat);
							let newEntryObj = true;
							if (this.membersAndrooms && this.membersAndrooms.membersRoom) {
								this.membersAndrooms.membersRoom.forEach((list)=>{
									// if (newEntryObj) {
										// 	if (list.id == lastUpdatedChat.to_user_id || list.id == lastUpdatedChat.from_userId) {
											// 		list.last_message_content = lastUpdatedChat.text;
											// 		list.createdAt = lastUpdatedChat.timestamp;
											// 		newEntryObj = false;
											// 		this.ngZone.run(()=>{
												// 			this.membersAndrooms.membersRoom = this.membersAndrooms.membersRoom;
												// 		})
												// 	}
												// }
												if (list.id == lastUpdatedChat.from_userId) {
													list.last_message_content = lastUpdatedChat.text;
													list.createdAt = lastUpdatedChat.timestamp;
													newEntryObj = false;
													this.ngZone.run(()=>{
														this.membersAndrooms.membersRoom = this.membersAndrooms.membersRoom;
													})
												}

											});
								if (newEntryObj) {
									let newMember = {
										color: undefined,
										connected: undefined,
										createdAt: lastUpdatedChat.timestamp,
										displayDate: lastUpdatedChat.timestamp,
										displayName: lastUpdatedChat.displayName ? lastUpdatedChat.displayName: lastUpdatedChat.from_username,
										email: lastUpdatedChat.email ? lastUpdatedChat.email: lastUpdatedChat.from_username,
										id: lastUpdatedChat.from_userId,
										last_message_content: lastUpdatedChat.text,
										last_message_user: "",
										lastseen: "",
										name: lastUpdatedChat.from_username,
										role: "",
										roomList: [],
										type: "user",
										uid: '',
									}

									this.membersAndrooms.membersRoom.push(newMember);
								}						
							}
							this.ngZone.run(()=>{
								this.membersAndrooms.membersRoom = this.membersAndrooms.membersRoom;
							})
							this.orderBy.transform(this.membersAndrooms.membersRoom, ['-createdAt']);
						}
					}
				}, error=>{
					console.log(error);
				})

				// return new Observable(observer => {
					// 	this.conversationPath.on('child_added', (snapshot)=>{
						// 		getList = snapshot.val();
						// 		return getList;
						// 	})
						// 	observer.next(getList);
						// 	observer.complete();
						// });

					}

					UsersAddEventListener(): Promise<any>{
						let userList: any = [];
						let promise = new Promise((resolve, reject)=>{
							return this.userListPath.on('child_added', (snapShot)=>{
								if (snapShot) {
									let userData = this.mappedUserData(snapShot, {});
									if (userData) {
										userList.push(userData);
										resolve(userList);
									}
								}
							})
						})
						return promise;
					}

					mappedUserData(childSnapshot,roomList){ 
						let  key=childSnapshot.key;
						let  childData=childSnapshot.val();
						let  userData={
							id:'',
							name:'',
							email:'',
							displayName:'',
							uid:'',
							last_message_content:'',
							type:'user',
							role:'',
							roomList: roomList,
							createdAt:(new Date('1900 01 01')).valueOf(),
							displayDate:"",
							last_message_user:'',
							color:"",
							connected:"",
							lastseen:"",
						};
						if (childData) {
							userData = {
								id:key,
								name:childData.name ? childData.name : childData.email,
								email:childData.email,
								displayName:childData.displayName,
								uid:childData.uid,
								last_message_content:'',
								type:'user',
								role:'',
								roomList: roomList,
								createdAt:(new Date('1900 01 01')).valueOf(),
								displayDate:"",
								last_message_user: childData.last_message_user ?childData.last_message_user: '',
								color:childData.color ? childData.color : this.getRandomColor(),
								connected:childData.connected,
								lastseen: '',
							};
						}
						return userData;
					};

					// get user list
					loadUserList(): Promise<any>{
						let userList: any = [];
						let promise = new Promise((resolve, reject)=>{
							if (this.User && this.User.id) {
								let query =  this.userListPath.orderByChild('status').equalTo(true).once('value');
								return query.then((snapShot)=>{
									if (snapShot) {
										snapShot.forEach((childSnapShot)=>{
											let userData = this.mappedUserData(childSnapShot, []);
											if (userData) {
												userList.push(userData);
												// return userList;
											}
											resolve(userList);
										})
									}
								})
							}
						});
						return promise;
					}
					// get user list end

					loadUsersListAddEventListener(): Promise<any>{
						let conversationList: any = [];
						let promise = new Promise((resolve, reject)=>{
							let query = this.conversationPath.orderByChild('from_userId').equalTo(this.User.id).limitToLast(1);
							return query.on('child_added', (snapShot)=>{
								if (snapShot) {
									let conversation = snapShot.val();
									conversationList.push(conversation);
								}
								resolve(conversationList);
							})
						})

						return promise;
					}

					// load Users
					loadUsers(): Promise<any> {
						let promise = new Promise((resolve, reject)=>{
							let roomList = [];
							let usersList = [];
							let query = this.userListPath.orderByChild('status').equalTo(true).once('value');
							return query.then((snapShot)=>{
								if (snapShot) {
									snapShot.forEach((childSnapShot)=>{
										let key = childSnapShot.key;
										childSnapShot.forEach((roomData)=>{
											let roomKey = roomData.key;
											let roomDetailObj = {
												roomId: roomKey
											}
											roomList.push(roomDetailObj);
										});
										let userData = this.mappedUserData(childSnapShot, roomList);
										if (userData) {
											usersList.push(userData);
											resolve(usersList);
										}
									});
								}
							})
						})
						return promise;				
					};
					// load Users end


					// get connectivity list
					trackPresence() {
						let connectedRef = this.dbReference.child('/.info/connected');
						let myConnectionsRef = this.dbReference.child('/users/' + this.User.id + '/connected');
						let lastOnlineRef  = this.dbReference.child('/users/' + this.User.id + '/lastseen');
						connectedRef.on('value', function (isOnline) {
							if (isOnline.val() === true) {
								myConnectionsRef.set(true);  
								myConnectionsRef.onDisconnect().remove();
								lastOnlineRef.onDisconnect().set(firebase.database.ServerValue.TIMESTAMP);
							}
							else{
								myConnectionsRef.set(false); 
							}
							console.info('Presence::',isOnline);
						});
					};
					// get connectivity list end

					// get members detail
					getMemberDetails():Promise<any>{
						let promise = new Promise((resolve, reject)=>{
							let query = this.userListPath.child(this.User.id).orderByChild('uid').once('value');
							return query.then((data)=>{
								let userDetail = data.val();
								resolve(userDetail);
							}).catch(error=>{
								console.log(error, 'error');
								reject(error);
							});
						});
						return promise;
					}
					// get members detail end

					// update profile details
					updateProfile(userProfileName): Promise<any>{
						let promise = new Promise((resolve, reject)=>{
							this.userListPath.child(this.User.id).update({displayName: userProfileName}).then((data)=>{
								console.log(data, 'data');
								resolve();
							}).catch(error=>{
								console.log(error, 'error');
								reject(error);
							})
						});
						return promise;
					}
					// update profile details end

					// listen own message and update on home screen page and list
					ownUserMessageListener(){
						// this.conversationPath.orderByChild('from_userId').equalTo(this.User.id).limitToLast(1).on('child_added', (snapshot)=>{
							this.conversationPath.orderByChild('from_userId')
							.equalTo(this.User.id).limitToLast(1).on('child_added', (snapshot)=>{
								if (snapshot) {
									let conversation = snapshot.val();								
									if (conversation) {
										let newValue = true;
										if (this.membersAndrooms && this.membersAndrooms.membersRoom) {
											this.membersAndrooms.membersRoom.forEach(list=>{
												if (list.id == conversation.to_user_id || list.id == conversation.from_userId) {
													list.last_message_content = conversation.text;
													list.createdAt = conversation.timestamp;
													list.displayDate = conversation.timestamp;
													newValue = false;
												}										
											});
											this.orderBy.transform(this.membersAndrooms.membersRoom, ['-createdAt']);
										}

										if (newValue) {
											let enterObj = false;
											let userData= {};
											this.loadUsers().then(usersList=>{
												usersList.forEach(list=>{
													if (list.id == conversation.to_user_id || list.id == conversation.from_userId) {
														userData = {
															id: list.id,
															name:list.name ? list.name : list.email,
															email:list.email,
															displayName:list.displayName,
															uid:list.uid,
															last_message_content: conversation.text,
															type:'user',
															role:'',
															roomList: [],
															createdAt: conversation.timestamp,
															displayDate:"",
															last_message_user: list.last_message_user ?list.last_message_user: '',
															color:list.color ?  list.color: this.getRandomColor(),
															connected:list.connected,
															lastseen: '',
														};
														enterObj = true;
													}
												});
												if (enterObj) {
													this.membersAndrooms.membersRoom.push(userData);
													let memberValues = [];
													let keys = [];
													this.membersAndrooms.membersRoom.forEach(list=>{
														let key = list.id || list.roomId;
														if (keys.indexOf(key) == -1) {
															keys.push(key);
															memberValues.push(list);
														}
													});
													this.membersAndrooms.membersRoom = memberValues;
													this.membersAndrooms.membersRoom =  this.orderBy.transform(this.membersAndrooms.membersRoom, ['-createdAt']);
													this.ngZone.run(()=>{
														this.membersAndrooms.membersRoom = this.membersAndrooms.membersRoom;
													})
												}
											});
										}
									}
								}
							});
						}
						// listen own message and update on home screen page and list end

						userChatsToListUser(){
							var list : any = [];
							this.conversationPath.orderByChild('from_userId').equalTo(this.User.id).on('value', (snap)=>{
								snap.forEach(snap=>{
									if (snap.val()) {
										list.push(snap.val())
									}
								})
								list = this.orderBy.transform(list, ['-createdAt']);

								// remove duplicate from array
								let listMessages = [];
								let keys = [];
								list.forEach(list=>{
									let key = list.to_user_id;
									if (keys.indexOf(key) == -1) {
										keys.push(key);
										listMessages.push(list);
									}
								});
								// console.log(listMessages, 'list Message');
								let userEntryData = {};
								let entryNew = false;
								this.loadUserList().then(usersList=>{
									let key = usersList
									listMessages.forEach(listUsers=>{
										usersList.forEach(users=>{
											if (listUsers.to_user_id == users.id) {
												userEntryData = {
													id: users.id,
													name:users.name ? users.name : users.email,
													email:users.email,
													displayName:users.displayName,
													uid:users.uid,
													last_message_content: listUsers.text,
													type:'user',
													role:'',
													roomList: [],
													createdAt: listUsers.timestamp,
													displayDate:"",
													last_message_user: listUsers.last_message_user ?listUsers.last_message_user: '',
													color:list.color ? list.color: this.getRandomColor(),
													connected:list.connected,
													lastseen: '',
												};
												entryNew = true;
												this.membersAndrooms.membersRoom.push(userEntryData);
											}
										})
									});
									if (entryNew) {
										// console.log(this.membersAndrooms.membersRoom, 'member room');
										let memberValues = [];
										let keys = [];
										this.membersAndrooms.membersRoom.forEach(list=>{
											let key = list.id || list.roomId;
											if (keys.indexOf(key) == -1) {
												keys.push(key);
												memberValues.push(list);
											}
										});
										this.membersAndrooms.membersRoom = memberValues;
										this.membersAndrooms.membersRoom =  this.orderBy.transform(this.membersAndrooms.membersRoom, ['-createdAt']);
										this.ngZone.run(()=>{
											this.membersAndrooms.membersRoom = this.membersAndrooms.membersRoom;
										});
									}
								})
								// remove duplicate from array end
							})
						}

						// create random color
						getRandomColor() {
							var letters = '0123456789ABCDEF';
							var color = '#';
							for (var i = 0; i < 6; i++) {
								color += letters[Math.floor(Math.random() * 16)];
							}
							return color;
						}
						// create random color end
					}
