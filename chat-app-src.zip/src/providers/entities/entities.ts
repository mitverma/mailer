import { Injectable } from '@angular/core';
import * as firebase from 'firebase';
@Injectable()
export class AuthUser {
	id: string;
	uid: string;
	email: string;
	deviceToken: string;
	status: boolean;
	auth_token: string;
	displayName: string;
	username: string;
	constructor() {
		console.log('AuthUser Called::');
		this.id = '';
		this.uid = '';
		this.email =  '';
		this.deviceToken =  '';
		this.status =  true;
		this.auth_token =  'APP_USER';
		this.displayName = '';
		this.username = '';
	}

}

@Injectable()
export class RoomDetail {
	roomId: string;
	name: string;
	lastMessage: string;
	createdAt: string;
	lastMessageUser: string;
	role: string;
	constructor(){
		this.roomId = '';
		this.name = '';
		this.lastMessage = '';
		this.createdAt = '';
		this.lastMessageUser = '';
		this.role = '';
	}
}

@Injectable()
export class MembersAndRooms {
	membersRoom : any;
	constructor(){
		this.membersRoom = [];
	}
}

@Injectable()
export class DeviceInformation  {
	deviceToken: string;
	Platform: string;
	Version: string;
	Uuid: string;
	Model: string;
	Serial: string;
	constructor() {
		this.deviceToken = '';
		this.Platform = '';
		this.Version = '';
		this.Uuid = '';
		this.Model = '';
		this.Serial = '';
	}
}

@Injectable()
export class CopiedData {
	text: string;
	imgUrl: string;
	constructor(){
		this.text = '';
		this.imgUrl = '';
	}
}


