import { Events} from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { Injectable, NgZone, ViewChild } from '@angular/core';
import * as firebase from 'firebase';
import { Observable } from 'rxjs';
import { AuthUser,RoomDetail,MembersAndRooms,DeviceInformation } from '../../providers/entities/entities';
import { OrderByPipe } from '../../pipes/filters/filters';
/*
  Generated class for the MessageServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
  */
  @Injectable()
  export class MessageServiceProvider {
    conversationPath: any;
    roomMessagePath: any;
    roomPath: any;
    dbRef: any;
    constructor(public http: HttpClient,public User: AuthUser, public events: Events, public roomDetail: RoomDetail, public membersAndrooms: MembersAndRooms, public orderBy: OrderByPipe, public ngZone: NgZone, public deviceInfo: DeviceInformation) {
      console.log('Hello MessageServiceProvider Provider');
      // this.dbRef = firebase.database().ref();
      // this.roomPath = firebase.database().ref().child('room-wala');
      // this.roomMessagePath = firebase.database().ref().child('roomwala-msg')
      // this.conversationPath = firebase.database().ref().child('conversation-chat');

      this.dbRef = firebase.database().ref();
      this.roomPath = firebase.database().ref().child('room');
      this.roomMessagePath = firebase.database().ref().child('room-messages')
      this.conversationPath = firebase.database().ref().child('conversations');
    }

    getRoomMessage(){

    }


    get(roomId){
      if (roomId) {
        let message: any;
        let groupMessageQuery = this.dbRef.child('roomwala-msg').child(roomId).orderByChild('createdAt');
        let query = groupMessageQuery.limitToLast(20).once('value');
        return Promise.all([query]).then((snapShot)=>{
          snapShot[0].forEach((childSnapshot)=>{
            var key = childSnapshot.key;
            var childData = childSnapshot.val();
            if(childData)
              var messageObj = {
                id:key,
                sender_userid:childData.sender_userid,
                sender_username:childData.sender_username,
                createdAt:childData.createdAt,
                content:childData.content,
              }
              message.push(messageObj);
            });
          return message;
        });
      }
    };


    // group message
    sendGroupMessage(roomid, message, title): Promise<any>{
      let promise = new Promise((resolve, reject)=>{
        let chatMessage = {
          from: this.User.id,
          sender_username: this.User.displayName ? this.User.displayName: this.User.email,
          sender_email: this.User.email,
          sender_userid: this.User.id,
          content: message.text,
          createdAt: firebase.database.ServerValue.TIMESTAMP,
          read:false,
          imgUrl: message.imgUrl,
        };
        let query = this.roomMessagePath.child(roomid);
        let messageIdKey = query.push().key;
        return query.child(messageIdKey).set(chatMessage).then((res)=>{
          // console.log(res, 'res'); 
          resolve();

          // set last message of group
          this.updateGroupLastMessage(roomid, chatMessage);
          // set last message of group end

          // send data to Notification from here

          let messageNotification = {
            text:chatMessage.content,  
            notificationTitle: title,
            params:
            {
              'roomId': roomid,
            },
            click_action: 'RoomChatPage'
          };
          // call Notification
          this.sendNotification(roomid, messageNotification);
          // call Notification end
          // send data to Notification from here end

        });

      });
      return promise;
      
    }
    // group message end

    sendMessageToUser(messageData){
      // console.log(messageData, 'mess');
      let setMsg = {
        conversations_id  : messageData.from_userId + '@@' + messageData.to_user_id,
        timestamp  : firebase.database.ServerValue.TIMESTAMP,
        notificationTitle : messageData.from_username,
        text: messageData.text,
        from_userId: messageData.from_userId,
        from_username: messageData.from_username,
        to_user_id: messageData.to_user_id,
        imgUrl: messageData.imgUrl,
        readStatus: 'no',
      };

      // if  userid is > then to_userid
      if (messageData.from_userId > messageData.to_user_id) {
        setMsg.conversations_id = messageData.to_user_id + '@@' + messageData.from_userId;
      }
      // if  userid is > then to_userid end

      let newmessageidKey = this.conversationPath.push().key;
      return this.conversationPath.child(newmessageidKey).set(setMsg).then(val=>{
        let notificationData = {
          conversations_id: setMsg.conversations_id,
          from_userId: setMsg.from_userId,
          from_username: setMsg.from_username,
          notificationTitle: setMsg.notificationTitle,
          params: {
            to_uid: this.User.id,
          },
          profilePic: null,
          text: setMsg.text,
          timestamp: setMsg.timestamp,
          to_user_id: setMsg.to_user_id,
          click_action: 'ChatPage',
          fdisplayName: '',
        }

        this.sendNotification(setMsg.to_user_id, notificationData);

        return val;
      });
    }

    bindUserMessages(userId,toUserId,lastPageId) : Observable<any[]>{
      let messageList : any = [];
      if (userId && toUserId) {
        var index = lastPageId<=0 ? 20 : lastPageId;

        if (userId > toUserId) {
          [userId, toUserId] = [toUserId, userId];
        }

        let query = this.conversationPath.orderByChild('conversations_id').equalTo(userId+'@@'+toUserId);

        let getUserQuery = query.limitToLast(index).once('value');
        return new Observable(observer => {
          Promise.all([getUserQuery]).then(snapShot=>{
            snapShot[0].forEach((childSnapshot)=>{
              var key = childSnapshot.key;
              var childData = childSnapshot.val();
              if(childData)
                var messageObj = {
                  id:key,
                  to_user_id:childData.to_user_id,
                  from_userId: childData.from_userId,
                  text:childData.text,
                  timestamp: childData.timestamp,
                  conversations_id:childData.conversations_id,
                  imgUrl: childData.imgUrl? childData.imgUrl : '',
                  readStatus: childData.readStatus,
                }
                messageList.push(messageObj);

                // update read status 
                if (childData.readStatus) {
                  if (childData.to_user_id == this.User.id) {
                    this.conversationPath.child(key).update({readStatus: 'yes'});
                  }
                }
                // update read status  end

                // console.log(messageList, 'message list');
                observer.next(messageList);
                observer.complete();
              });
          });
        });
      }
    };

    bindUserMessagesAddedEvent(userId,toUserId,lastPageId){
      let messageList: any = {};
      if (userId && toUserId) {
        let query = this.conversationPath.orderByChild('conversations_id').equalTo(userId+'@@'+toUserId);
        // query.on('child_added', (snapShot)=>{
          query.limitToList(1).on('child_added', (snapShot)=>{
            let key = snapShot.key;
            let childData = snapShot.val();
            if(childData){
              let messageObj = {
                id:key,
                to_user_id:childData.to_user_id,
                text:childData.text,
                timestamp:childData.timestamp,
                conversations_id:childData.conversations_id,
              }
              messageList = messageObj;
              // console.log(messageList, 'assignes values', messageObj, 'message obj');
            }
          })
        }
      };


      // group

      bindGroupMessages(roomId, lastPageId): Promise<any>{
        let groupMessageList: any = [];
        let promise =  new Promise((resolve, reject)=>{
          if (roomId) {
            let query:any;
            // if (lastPageId == '0') {
              //   query = this.roomMessagePath.child(roomId).orderByKey().limitToLast(lastPageId).once('value');
              // }else {
                //   query = this.roomMessagePath.child(roomId).orderByKey().limitToLast(lastPageId).endAt().once('value');
                // }
                query = this.roomMessagePath.child(roomId).orderByKey().limitToLast(lastPageId).once('value');
                return query.then(Snapshot=>{
                  Snapshot.forEach((childSnapshot)=>{
                    let childGroupMsg = this.onChildGroupMessageLoaded(childSnapshot);
                    if (childGroupMsg) {
                      groupMessageList.push(childGroupMsg);
                      // console.log(groupMessageList, 'group msg list');
                      resolve(groupMessageList);
                    }
                  });
                })
              } 
            });
        return promise;
      }

      onChildGroupMessageLoaded(Snapshot){
        var key = Snapshot.key;
        var childData = Snapshot.val();
        if(childData)
          var messageObj={
            id:key,
            sender_userid:childData.sender_userid,
            sender_username:childData.sender_username,
            sender_email:childData.sender_email,
            createdAt:childData.createdAt,
            content:childData.content,
            imgUrl: childData.imgUrl ? childData.imgUrl: '',
          }
          // message.push(messageObj);
          return messageObj;
        };

        // group message listener
        setUpGroupMessageListiner(roomIdVal):Promise<any>{
          let messageList = [];
          let promise = new Promise((resolve, reject)=>{
            let roomId = roomIdVal ? roomIdVal : this.roomDetail.roomId;
            let query = this.roomMessagePath.child(roomId).orderByKey();
            return query.on('child_added', (snapShot)=>{
              if (snapShot) {
                let newMsg = this.onChildGroupMessageAdded(snapShot);
                if (newMsg) {
                  messageList.push(newMsg);
                  resolve(newMsg);
                  this.events.publish('groupMessage:Added', newMsg);
                }
              }
            })
          });
          return promise;
        }


        onChildGroupMessageAdded(Snapshot){
          var key = Snapshot.key;
          var childData = Snapshot.val();
          if(childData)
            var messageObj=
          {
            id:key,
            sender_email: childData.sender_email,
            sender_userid:childData.sender_userid,
            sender_username:childData.sender_username,
            createdAt:childData.createdAt,
            content:childData.content,
          }
          return (messageObj);
        };

        // group message listener end

        // set last message to group
        updateGroupLastMessage(roomId, data){
          let updateGroupData = {
            last_message: data.content,
            last_message_time: data.createdAt,
            last_message_user: this.User.email
          }
          this.roomPath.child(roomId).update(updateGroupData);
        }
        // set last message to group end

        groupMessageAdded(){
          this.roomPath.on('child_changed', (snap)=>{
            let conversation = this.mappedGroupData(snap);
            if (conversation) {
              if (this.membersAndrooms && this.membersAndrooms.membersRoom) {
                this.membersAndrooms.membersRoom.forEach((list)=>{
                  if (list.roomId == conversation.roomId) {
                    list.last_message_content = conversation.last_message_content;
                    list.last_message_user = conversation.last_message_user;
                    list.createdAt = conversation.createdAt;
                    list.name = conversation.name;
                    list.displayName = conversation.displayName;
                  }                  
                });
                this.ngZone.run((data)=>{                  
                  this.orderBy.transform(this.membersAndrooms.membersRoom, ['-createdAt']);
                });
              }
            }
          })
        }

        mappedGroupData(childSnapshot){
          var key = childSnapshot.key;
          var childData = childSnapshot.val();
          if(childSnapshot.child(this.User.id).val() && (childSnapshot.child(this.User.id).val()["role"]=='member' || childSnapshot.child(this.User.id).val()["role"]=='owner'))
          {
            var roomData={
              roomId:key,
              name:childData.name,
              displayName:childData.name,
              role:childSnapshot.child(this.User.id).val()?childSnapshot.child(this.User.id).val()["role"]:"unknown",
              last_message_content:childData.last_message?childData.last_message:'',
              type:'group',
              createdAt:childData.last_message_time ? childData.last_message_time : (new Date('1900-01-01')).valueOf(),
              last_message_user:childData.last_message_user?childData.last_message_user:'',
              color:childData.color
            };
          }
          return roomData;    
        };


        // send notification
        sendNotification(to_userid, message) {
          let notificationTitle = 'Oneinsure sales app !!';

          let notificationOptions = {
            title: message.notificationTitle,
            body: message.text,
            icon: 'https://crm.oneinsure.com/assets/bi/images/oneinsure-logo-main-small.png',
            badge: 'https://crm.oneinsure.com/assets/bi/images/oneinsure-logo-main-small.png',
            from_userid: this.User.id,
            params:message.params,
            userName: this.User.displayName,
            // devicetoken: this.deviceInfo ? this.deviceInfo.deviceToken : this.User.deviceToken,
            devicetoken: this.deviceInfo ? this.deviceInfo.deviceToken : this.User.deviceToken,
            click_action: message.click_action,
            fdisplayName: '',
          };

          let notificationDatabase = firebase.database().ref('/notifications/' + to_userid);
          let notificationId = notificationDatabase.push().key;
          notificationDatabase.child(notificationId).set(notificationOptions);
        }
        // send notification end

      }
