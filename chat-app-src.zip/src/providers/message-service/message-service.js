var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Events } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { Injectable, NgZone } from '@angular/core';
import * as firebase from 'firebase';
import { Observable } from 'rxjs';
import { AuthUser, RoomDetail, MembersAndRooms, DeviceInformation } from '../../providers/entities/entities';
import { OrderByPipe } from '../../pipes/filters/filters';
/*
  Generated class for the MessageServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
  */
var MessageServiceProvider = /** @class */ (function () {
    function MessageServiceProvider(http, User, events, roomDetail, membersAndrooms, orderBy, ngZone, deviceInfo) {
        this.http = http;
        this.User = User;
        this.events = events;
        this.roomDetail = roomDetail;
        this.membersAndrooms = membersAndrooms;
        this.orderBy = orderBy;
        this.ngZone = ngZone;
        this.deviceInfo = deviceInfo;
        console.log('Hello MessageServiceProvider Provider');
        // this.dbRef = firebase.database().ref();
        // this.roomPath = firebase.database().ref().child('room-wala');
        // this.roomMessagePath = firebase.database().ref().child('roomwala-msg')
        // this.conversationPath = firebase.database().ref().child('conversation-chat');
        this.dbRef = firebase.database().ref();
        this.roomPath = firebase.database().ref().child('room');
        this.roomMessagePath = firebase.database().ref().child('room-messages');
        this.conversationPath = firebase.database().ref().child('conversations');
    }
    MessageServiceProvider.prototype.getRoomMessage = function () {
    };
    MessageServiceProvider.prototype.get = function (roomId) {
        if (roomId) {
            var message_1;
            var groupMessageQuery = this.dbRef.child('roomwala-msg').child(roomId).orderByChild('createdAt');
            var query = groupMessageQuery.limitToLast(20).once('value');
            return Promise.all([query]).then(function (snapShot) {
                snapShot[0].forEach(function (childSnapshot) {
                    var key = childSnapshot.key;
                    var childData = childSnapshot.val();
                    if (childData)
                        var messageObj = {
                            id: key,
                            sender_userid: childData.sender_userid,
                            sender_username: childData.sender_username,
                            createdAt: childData.createdAt,
                            content: childData.content,
                        };
                    message_1.push(messageObj);
                });
                return message_1;
            });
        }
    };
    ;
    // group message
    MessageServiceProvider.prototype.sendGroupMessage = function (roomid, message, title) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            var chatMessage = {
                from: _this.User.id,
                sender_username: _this.User.displayName ? _this.User.displayName : _this.User.email,
                sender_email: _this.User.email,
                sender_userid: _this.User.id,
                content: message.text,
                createdAt: firebase.database.ServerValue.TIMESTAMP,
                read: false,
                imgUrl: message.imgUrl,
            };
            var query = _this.roomMessagePath.child(roomid);
            var messageIdKey = query.push().key;
            return query.child(messageIdKey).set(chatMessage).then(function (res) {
                // console.log(res, 'res'); 
                resolve();
                // set last message of group
                _this.updateGroupLastMessage(roomid, chatMessage);
                // set last message of group end
                // send data to Notification from here
                var messageNotification = {
                    text: chatMessage.content,
                    notificationTitle: title,
                    params: {
                        'roomId': roomid,
                    },
                    click_action: 'RoomChatPage'
                };
                // call Notification
                _this.sendNotification(roomid, messageNotification);
                // call Notification end
                // send data to Notification from here end
            });
        });
        return promise;
    };
    // group message end
    MessageServiceProvider.prototype.sendMessageToUser = function (messageData) {
        var _this = this;
        // console.log(messageData, 'mess');
        var setMsg = {
            conversations_id: messageData.from_userId + '@@' + messageData.to_user_id,
            timestamp: firebase.database.ServerValue.TIMESTAMP,
            notificationTitle: messageData.from_username,
            text: messageData.text,
            from_userId: messageData.from_userId,
            from_username: messageData.from_username,
            to_user_id: messageData.to_user_id,
            imgUrl: messageData.imgUrl,
            readStatus: 'no',
        };
        // if  userid is > then to_userid
        if (messageData.from_userId > messageData.to_user_id) {
            setMsg.conversations_id = messageData.to_user_id + '@@' + messageData.from_userId;
        }
        // if  userid is > then to_userid end
        var newmessageidKey = this.conversationPath.push().key;
        return this.conversationPath.child(newmessageidKey).set(setMsg).then(function (val) {
            var notificationData = {
                conversations_id: setMsg.conversations_id,
                from_userId: setMsg.from_userId,
                from_username: setMsg.from_username,
                notificationTitle: setMsg.notificationTitle,
                params: {
                    to_uid: _this.User.id,
                },
                profilePic: null,
                text: setMsg.text,
                timestamp: setMsg.timestamp,
                to_user_id: setMsg.to_user_id,
                click_action: 'ChatPage',
            };
            _this.sendNotification(setMsg.to_user_id, notificationData);
            return val;
        });
    };
    MessageServiceProvider.prototype.bindUserMessages = function (userId, toUserId, lastPageId) {
        var _this = this;
        var _a;
        var messageList = [];
        if (userId && toUserId) {
            var index = lastPageId <= 0 ? 20 : lastPageId;
            if (userId > toUserId) {
                _a = [toUserId, userId], userId = _a[0], toUserId = _a[1];
            }
            var query = this.conversationPath.orderByChild('conversations_id').equalTo(userId + '@@' + toUserId);
            var getUserQuery_1 = query.limitToLast(index).once('value');
            return new Observable(function (observer) {
                Promise.all([getUserQuery_1]).then(function (snapShot) {
                    snapShot[0].forEach(function (childSnapshot) {
                        var key = childSnapshot.key;
                        var childData = childSnapshot.val();
                        if (childData)
                            var messageObj = {
                                id: key,
                                to_user_id: childData.to_user_id,
                                from_userId: childData.from_userId,
                                text: childData.text,
                                timestamp: childData.timestamp,
                                conversations_id: childData.conversations_id,
                                imgUrl: childData.imgUrl ? childData.imgUrl : '',
                                readStatus: childData.readStatus,
                            };
                        messageList.push(messageObj);
                        // update read status 
                        if (childData.readStatus) {
                            if (childData.to_user_id == _this.User.id) {
                                _this.conversationPath.child(key).update({ readStatus: 'yes' });
                            }
                        }
                        // update read status  end
                        // console.log(messageList, 'message list');
                        observer.next(messageList);
                        observer.complete();
                    });
                });
            });
        }
    };
    ;
    MessageServiceProvider.prototype.bindUserMessagesAddedEvent = function (userId, toUserId, lastPageId) {
        var messageList = {};
        if (userId && toUserId) {
            var query = this.conversationPath.orderByChild('conversations_id').equalTo(userId + '@@' + toUserId);
            // query.on('child_added', (snapShot)=>{
            query.limitToList(1).on('child_added', function (snapShot) {
                var key = snapShot.key;
                var childData = snapShot.val();
                if (childData) {
                    var messageObj = {
                        id: key,
                        to_user_id: childData.to_user_id,
                        text: childData.text,
                        timestamp: childData.timestamp,
                        conversations_id: childData.conversations_id,
                    };
                    messageList = messageObj;
                    // console.log(messageList, 'assignes values', messageObj, 'message obj');
                }
            });
        }
    };
    ;
    // group
    MessageServiceProvider.prototype.bindGroupMessages = function (roomId, lastPageId) {
        var _this = this;
        var groupMessageList = [];
        var promise = new Promise(function (resolve, reject) {
            if (roomId) {
                var query = void 0;
                // if (lastPageId == '0') {
                //   query = this.roomMessagePath.child(roomId).orderByKey().limitToLast(lastPageId).once('value');
                // }else {
                //   query = this.roomMessagePath.child(roomId).orderByKey().limitToLast(lastPageId).endAt().once('value');
                // }
                query = _this.roomMessagePath.child(roomId).orderByKey().limitToLast(lastPageId).once('value');
                return query.then(function (Snapshot) {
                    Snapshot.forEach(function (childSnapshot) {
                        var childGroupMsg = _this.onChildGroupMessageLoaded(childSnapshot);
                        if (childGroupMsg) {
                            groupMessageList.push(childGroupMsg);
                            // console.log(groupMessageList, 'group msg list');
                            resolve(groupMessageList);
                        }
                    });
                });
            }
        });
        return promise;
    };
    MessageServiceProvider.prototype.onChildGroupMessageLoaded = function (Snapshot) {
        var key = Snapshot.key;
        var childData = Snapshot.val();
        if (childData)
            var messageObj = {
                id: key,
                sender_userid: childData.sender_userid,
                sender_username: childData.sender_username,
                sender_email: childData.sender_email,
                createdAt: childData.createdAt,
                content: childData.content,
                imgUrl: childData.imgUrl ? childData.imgUrl : '',
            };
        // message.push(messageObj);
        return messageObj;
    };
    ;
    // group message listener
    MessageServiceProvider.prototype.setUpGroupMessageListiner = function (roomIdVal) {
        var _this = this;
        var messageList = [];
        var promise = new Promise(function (resolve, reject) {
            var roomId = roomIdVal ? roomIdVal : _this.roomDetail.roomId;
            var query = _this.roomMessagePath.child(roomId).orderByKey();
            return query.on('child_added', function (snapShot) {
                if (snapShot) {
                    var newMsg = _this.onChildGroupMessageAdded(snapShot);
                    if (newMsg) {
                        messageList.push(newMsg);
                        resolve(newMsg);
                        _this.events.publish('groupMessage:Added', newMsg);
                    }
                }
            });
        });
        return promise;
    };
    MessageServiceProvider.prototype.onChildGroupMessageAdded = function (Snapshot) {
        var key = Snapshot.key;
        var childData = Snapshot.val();
        if (childData)
            var messageObj = {
                id: key,
                sender_email: childData.sender_email,
                sender_userid: childData.sender_userid,
                sender_username: childData.sender_username,
                createdAt: childData.createdAt,
                content: childData.content,
            };
        return (messageObj);
    };
    ;
    // group message listener end
    // set last message to group
    MessageServiceProvider.prototype.updateGroupLastMessage = function (roomId, data) {
        var updateGroupData = {
            last_message: data.content,
            last_message_time: data.createdAt,
            last_message_user: this.User.email
        };
        this.roomPath.child(roomId).update(updateGroupData);
    };
    // set last message to group end
    MessageServiceProvider.prototype.groupMessageAdded = function () {
        var _this = this;
        this.roomPath.on('child_changed', function (snap) {
            var conversation = _this.mappedGroupData(snap);
            if (conversation) {
                if (_this.membersAndrooms && _this.membersAndrooms.membersRoom) {
                    _this.membersAndrooms.membersRoom.forEach(function (list) {
                        if (list.roomId == conversation.roomId) {
                            list.last_message_content = conversation.last_message_content;
                            list.last_message_user = conversation.last_message_user;
                            list.createdAt = conversation.createdAt;
                            list.name = conversation.name;
                            list.displayName = conversation.displayName;
                        }
                    });
                    _this.ngZone.run(function (data) {
                        _this.orderBy.transform(_this.membersAndrooms.membersRoom, ['-createdAt']);
                    });
                }
            }
        });
    };
    MessageServiceProvider.prototype.mappedGroupData = function (childSnapshot) {
        var key = childSnapshot.key;
        var childData = childSnapshot.val();
        if (childSnapshot.child(this.User.id).val() && (childSnapshot.child(this.User.id).val()["role"] == 'member' || childSnapshot.child(this.User.id).val()["role"] == 'owner')) {
            var roomData = {
                roomId: key,
                name: childData.name,
                displayName: childData.name,
                role: childSnapshot.child(this.User.id).val() ? childSnapshot.child(this.User.id).val()["role"] : "unknown",
                last_message_content: childData.last_message ? childData.last_message : '',
                type: 'group',
                createdAt: childData.last_message_time ? childData.last_message_time : (new Date('1900-01-01')).valueOf(),
                last_message_user: childData.last_message_user ? childData.last_message_user : '',
                color: childData.color
            };
        }
        return roomData;
    };
    ;
    // send notification
    MessageServiceProvider.prototype.sendNotification = function (to_userid, message) {
        var notificationTitle = 'Oneinsure sales app !!';
        var notificationOptions = {
            title: message.notificationTitle,
            body: message.text,
            icon: 'https://crm.oneinsure.com/assets/bi/images/oneinsure-logo-main-small.png',
            badge: 'https://crm.oneinsure.com/assets/bi/images/oneinsure-logo-main-small.png',
            from_userid: this.User.id,
            params: message.params,
            userName: this.User.displayName,
            devicetoken: this.deviceInfo ? this.deviceInfo.deviceToken : this.User.deviceToken,
            click_action: message.click_action,
        };
        var notificationDatabase = firebase.database().ref('/notifications/' + to_userid);
        var notificationId = notificationDatabase.push().key;
        notificationDatabase.child(notificationId).set(notificationOptions);
    };
    MessageServiceProvider = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [HttpClient, AuthUser, Events, RoomDetail, MembersAndRooms, OrderByPipe, NgZone, DeviceInformation])
    ], MessageServiceProvider);
    return MessageServiceProvider;
}());
export { MessageServiceProvider };
//# sourceMappingURL=message-service.js.map