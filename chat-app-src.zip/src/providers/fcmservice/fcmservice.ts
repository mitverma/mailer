import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as firebase from 'firebase';
/*
  Generated class for the FcmserviceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
  */
  @Injectable()
  export class FcmserviceProvider {
    messaging : any = firebase.messaging();
    constructor(public http: HttpClient) {
      console.log('Hello FcmserviceProvider Provider');
      this.initToken();
    }

    // initialize token
    initToken(){
      var that = this;
      this.messaging.getToken().then((currentToken)=> {
        if (currentToken) {
          console.log("Device Token::",currentToken);
          this.sendTokenToServer(currentToken);

        } else {
          console.log('No Instance ID token available. Request permission to generate one.');
          // this.permissionRequiredUI();
          that.setTokenSentToServer(false);
        }
      }).catch(function(err) {
        console.log('An error occurred while retrieving token. ', err);
        that.setTokenSentToServer(false);
      });
    };  
    // initialize token end

    // send token to server
    sendTokenToServer(currentToken){
      if (!this.isTokenSentToServer()) {
        console.log('Sending token to server...');
        this.setTokenSentToServer(true);
        this.setTokenToDB(currentToken);
      } else {
        console.log('Token already sent to server so won\'t send it again unless it changes');
      }
    }
    // send token to serve end  

    // request permission
    requestPermission(){
      console.log('Requesting permission...');
      this.messaging.requestPermission().then(()=> {
        console.log('requestPermission::');
        this.initToken();
      }).catch(function(err) {
        console.log('Unable to get permission to notify.', err);
      });
    }
    // request permission end

    // delete token
    deleteToken(){
      this.messaging.getToken().then(function(currentToken) {
        this.messaging.deleteToken(currentToken).then(function() {
          console.log('Token deleted.');
          this.setTokenSentToServer(false);
          this.initToken();
        }).catch(function(err) {
          console.log('Unable to delete token. ', err);
        });
      }).catch(function(err) {
        console.log('Error retrieving Instance ID token. ', err);
      });
    }
    // delete token end
    // is token sent to serve
    isTokenSentToServer(){
      if (localStorage.getItem('sentToServer') == '1') {
        return true;
      }
      return false;
    }
    // is token sent to serve end

    // set token sent to serve
    setTokenSentToServer(sent: any) {
      if (sent) {
        localStorage.setItem('sentToServer', '1');
      } else {
        localStorage.setItem('sentToServer', '0');
      }
    };
    // set token sent to serve end

    // set token DB
    setTokenToDB(devicetoken) {
      localStorage.setItem('devicetoken', devicetoken);
    };
    // set token DB end
    // get token from db
    getTokenFromDb() {
      var deviceTokenO  = localStorage.getItem('devicetoken');
      return deviceTokenO;
    }
    // get token from db end

  }
