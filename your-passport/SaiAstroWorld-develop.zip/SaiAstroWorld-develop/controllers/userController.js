const mongoose = require('mongoose');
const userCollection = require("../model/user");
const blogCollection = require("../model/blog");
const reportCollection = require("../model/reports");
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const salt = 10;
var jwt_key = "secret";
var querystring = require('querystring');
var https = require('https');
var nodemailer = require('nodemailer'); 
const VoiceResponse = require('twilio').twiml.VoiceResponse;
 const twilioApp = require('../helpers/twillioConfig');
 const twillioCall =require('../helpers/twillioCalls');
const __ = require('../helpers/globalFunctions');
var Orders = require('../model/user_creation_count');
var validator = require('aadhaar-validator');
const indianCollection =require("../model/indiaPrices");
const usCollection = require("../model/usPrices");
const taiwanCollection = require("../model/taiwanPrices");
const languageCollection = require("../model/languages");
const request = require('request');
let accountSid="ACbc3495679c2e90ac0c6dfbf866f16d2f";
let authToken="081d3f4b51925d9fa9b0916707171b47";
const client = require('twilio')(accountSid, authToken);


var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'astroworldproject@gmail.com',
        pass: 'Astroworld@123'
       }
   });

    
   function sendEmail(mailOptions) {
    transporter.sendMail(mailOptions, function(error, info){
      if (error) {
        console.log("in error: ",error);
      } else {
        console.log('Email sent: ' + info.response);
      }
    });
  
   }

   function sendSMS(message,contactNo,code){
     let d='+91'
   if(code || code !==''|| code !==undefined){
      d=code;
   }
   let c= d+contactNo;
    const welcomeMessage = message;

    twilioApp(c, welcomeMessage);
  //  __.out(res,200,"Successfully received data",null);
  }

  function updateLanguage(ID,arr){
    if(ID == 1){
      languageCollection.findOneAndUpdate({ID:1},{ $addToSet: { languages: arr } },function(err,data){
        if(err){
          console.log("ERR: ",err);
        }else{
          console.log("DATA: ",data);
        }
      })
    }else{
      languageCollection.findOneAndUpdate({ID:2},{ $addToSet: { expertise: arr } },function(err,data){
        if(err){
          console.log("ERR: ",err);
        }else{
          console.log("DATA: ",data);
        }
      })
    }
   
  }
  

class User{
   async registerUser(req,res){
       
        try{
          let requiredResult = await __.checkRequiredFields(req, ['name', 'email','countryCode','contactNo','userType','password']);
        if (requiredResult.status === false) {
          __.out(res, 400,requiredResult.missingFields+'field mandatory', requiredResult.missingFields);
       }
       else{
        let user=req.body;
        userCollection.findOne({contactNo: req.body.contactNo, $or:[{userType:user.userType},{userType:3},{email:req.body.email}]},async function(err, data){
           
            if(err){
                console.log("came in else/...: ",err);
                __.out(res,300,"Something went wrong!",err);
               // res.status(300).json({status:300,data:data, message:"Something went wrong!"});
               
            }else if(data){
              __.out(res,300,"This user is already Registred, Either with same contact No OR with Email Id",data);
               // res.status(300).json({status:300,data:{},message:"This user alrady Registred."});
            }
            else{
             
              try{
                bcrypt.genSalt(10, function(err, salt) {
                  bcrypt.hash(user.password, salt, async function(err, hash) {
                  if(err){
                    __.out(res,300,"Couldn't save record.. please contact to admin",err);

                   // res.status(300).json({status:300,data:err, message:"Coldn't save record.. please contact to admin"});
                  }else{
                    var order_id;
                    let order = {
                      contactNo:user.contactNo,
                      userType:user.userType
                    }
                    await Orders.create(order)
                    .then(data => {
                        order_id = data.order_id;
                    }).catch(err => {
                      return __.out(res,500,"Error when creating user Id, try later",err);
                    });
                    console.log("order_id: ",order_id);
                    var sixdigitsrandom = Math.floor(100000 + Math.random() * 900000);
                    let userToSave={
                      name:user.name,
                      email:user.email,
                      countryCode:user.countryCode,
                      contactNo : user.contactNo,
                      userType:user.userType,
                      password:hash,
                      otp:sixdigitsrandom,
                      userId: "u0"+order_id
                    }
                    if(user.userType=="2"||user.userType==2){
                     
                     userToSave={
                        name:user.name,
                        email:user.email,
                        countryCode:user.countryCode,
                        contactNo : user.contactNo,
                        userType:user.userType,
                        passwordAstrologer:hash,
                        otp:sixdigitsrandom,
                        userId:"a0"+order_id
                      }
                    }
                   
                    try{
                      let userSave = new userCollection(userToSave);
                      let userSaved = await userSave.save();
                      let msg='congratulations Mr/Ms.'+ user.name + ' You are successfully registered with AstroWorld family with your Contact Number '+
                              user.contactNo + ' to Verify your subscription please refer '+ sixdigitsrandom +' as OTP.'
                      //send SMS
                      sendSMS(msg,user.contactNo,user.countryCode);
                      //send an email
                    var mailOptions = {
                      from: 'astroworldsai@gmail.com',
                      to: user.email,
                      subject: 'verification Otp from Astroworld',
                      html: 'congratulations Mr/Ms.'+ user.name + ' You are successfully registered with AstroWorld family with your Contact Number '+
                              user.contactNo + ' to Verify your subscription please refer '+ sixdigitsrandom +' as OTP.' 
                    };
                    sendEmail(mailOptions);
                    __.out(res,200,"User Successfully registered.",{otp:sixdigitsrandom, userId:userToSave.order_id});

                    //res.status(201).json({status:200,data:{otp:sixdigitsrandom}, message:"User Successfully registered."});
                    }catch(e){
                      console.log("INHERE:")
                      __.out(res,500,"Somenthing went wrong! please contact admin or try again later.",e);

                     //res.status(500).json({status:500,data:err, error: e,message:"Somenthing went wrong! please cotact admin or try again later."});

                    }
                   
                  }
                })
              })
              }catch(e){
                console.log("INHERE111:")
               // res.status(500).json({status:500,data:err, message:"Somenthing went wrong! please cotact admin or try again later."});
               __.out(res,500,"Something went wrong! please cotact admin or try again later.",e);

              }
             
            }
         });
        }

        }catch(e){
          console.log("In catch",e);
          __.out(res, 500, "Something went wrong",e);
        }
        
    
       
     }

     async sendEmail(req,res){
        let mailId = req.body.email;
        var mailOptions = {
            from: 'astroworldsai@gmail.com',
            to: mailId,
            subject: 'Sending Email using Node.js',
            html: '<p>Your html here</p>'
          };

          transporter.sendMail(mailOptions, function(error, info){
            if (error) {
              console.log("in error: ",error);
            } else {
              console.log('Email sent: ' + info.response);
            }
          });
        


     }
     async sendSMS(req,res){
       console.log("req.body",req.body);
      let c= '+91 '+req.body.contactNo;
       const welcomeMessage = 'Welcome to Astroworld!we are testing SMS , Sender -Dipali pawshe';

       twilioApp(c, welcomeMessage);
       __.out(res,200,"Successfully received data",null);
     }

   async calling(req,res){
    console.log("req.body",req.body);
   // let requiredResult = await __.checkRequiredFields(req, ['contactNo','astrologerId']);
    let requiredResult = await __.checkRequiredFields(req, ['contactNo','astrologerId','userId','balance']);
        if (requiredResult.status === false) {
          __.out(res, 400, requiredResult.missingFields+'field mandatory',requiredResult.missingFields);
        }
        else{
         
          userCollection.findOne({userId:req.body.astrologerId},async function(err, astologer){
            if(err || astologer==null){
              __.out(res, 300, "something went wrong when finding astrologer, please try again later..",err);
            }else{
                  let c= req.body.contactNo;
                  let cc = "+91";
                  if(astologer.countryCode){
                    cc=astologer.countryCode;
                  }
                  var salesNumber = cc+astologer.contactNo;
                
                  console.log("{request.headers.host: ",req.headers.host);
                  try{
                    twillioCall(req,res,c,salesNumber,astologer.userId,req.body.userId,req.body.balance);
                   // twillioCall(req,res,c,salesNumber,astologer.userId);
                    //__.out(res,200,"Successfully received data",null);
                  }catch(e){
                    console.log("in e",e);
                    //__.out(res,300,"Error doing call",e);
                  }
            }
          })
        }
   
  
   
   }

   async connect(req,res){
     console.log("In connect here me");
     var salesNumber = req.params.no;
      var twimlResponse = new VoiceResponse();
    const dial = twimlResponse.dial();
    dial.number(salesNumber);
    res.send(twimlResponse.toString());
   }
     async verifyOtp(req,res){
       let userdata = req.body;
      try{
        let requiredResult = await __.checkRequiredFields(req, ['contactNo','userType','otp']);
        if (requiredResult.status === false) {
          __.out(res, 400,requiredResult.missingFields+'field mandatory', requiredResult.missingFields);
       }else{
        let userData=await userCollection.findOne({contactNo:userdata.contactNo});
        if(!userData){
          __.out(res,300,"Something went wrong!,Couldn't find data with this contact number",userData);

         //res.status(300).json({data:userData, message:"Something went wrong!"});
        }else{
          console.log("found user");
          if(userData.otp == userdata.otp){
             userData.isVerified = true;
             let update = userData.save();
            __.out(res,200,"user verified successfully..",update);

          }else{
          __.out(res,300,"invalid otp or userId please check again",null);

          }
        }
       }
      }catch(e){
          console.log("In catch",e);
          __.out(res, 500, "Something went wrong");
      }
      
     }

     async login(req,res){
       try{
         console.log("Calling login");
        let requiredResult = await __.checkRequiredFields(req, ['contactNo','userType','password']);
        if (requiredResult.status === false) {
          __.out(res, 400, requiredResult.missingFields+'field mandatory',requiredResult.missingFields);
        }
        else{
          let userdata = req.body;
          let existingUser = await userCollection.findOne({contactNo:userdata.contactNo, $or:[{userType:userdata.userType},{userType:3}]});
         
          if(existingUser){

            var currPass = existingUser.password?existingUser.password:'';
            if(userdata.userType==2||userdata.userType=="2"){
              currPass = existingUser.passwordAstrologer;
            }
            console.log("Curr Pass: ",currPass);
          // bcrypt.compare(userdata.password, existingUser.password, async function(err, result) {
            bcrypt.compare(userdata.password, currPass, async function(err, result) {
               if(err){
                 console.log("Eror ",err);
                    __.out(res, 300, "Something went wrong with password, Please try again",err);

                  // res.send({status:300,data:null,message:"password not matching.."});
                 }else{
                   console.log("result here is: ",result); 
                   if(result==false){
                    console.log("INIF MEMMMEMEM ",result); 
                    __.out(res, 300, "password does not match",result);
                    
                    // res.status(300).send({data:null,message:"Auth Failed."});
                   }else{
                    const token= jwt.sign({
                       email:existingUser.email,
                       _id:existingUser._id,
                       userType:existingUser.userType,
                       contactNo:existingUser.contactNo,
                       name:existingUser.name,
                       userId:existingUser.userId,
                       activeStatus:existingUser.activeStatus,
                       countryCode:existingUser.countryCode
                     },
                     jwt_key,
                     {
                       expiresIn:"2h"
                     }
                     );
                     if(userdata.userType==1){
                       console.log("usertoke")
                       await userCollection.update({_id:existingUser._id},{$set:{userToken:token,currentUser:1}});
                      //  existingUser.userToken=token;
                      //  await existingUser.save();
                     }else{
                       console.log("astrouser")
                       //existingUser.astroToken=token;
                      await userCollection.update({_id:existingUser._id},{$set:{astroToken:token,currentUser:2}});
                       //await existingUser.save();
                     }
                     let user ={
                       _id:existingUser._id, name:existingUser.name, email:existingUser.email,
                       contactNo:existingUser.contactNo,userType:existingUser.userType,
                       userId:existingUser.userId?existingUser.userId:null,
                       firebaseUserId:existingUser.firebaseUserId,countryCode:existingUser.countryCode
                     }
                     let profileUpdated=false;
                    if(existingUser.profileUpdated && existingUser.profileUpdated ==true){
                      profileUpdated=true;
                    }
                  if(existingUser.userType==2 || existingUser.userType=='2'){
                    user.astrologistDetails=existingUser.astrologistDetails;
                    __.out(res, 200, "User login Successful..",{token:token,userData:user,profileUpdated:profileUpdated});
                  }else{
                    __.out(res, 200, "User login Successful..",{token:token,userData:user});
                  }


                    // res.status(200).json({status:200,data:{token:token,userData:user},message:"Auth Succeeded.."});
                   }
                 }
            });
          }else{
            __.out(res, 300, "couldn't find user with these creadentials",null);

           // res.status(300).send({data:null,message:"couldn't find user with these creadentials"});
          }
        }
       }catch(e){
        console.log("In catch",e);
        __.out(res, 500, "Something went wrong",null);
       }
       
      
     }
     

     async forgotPassword(req,res){
       try{
        let requiredResult = await __.checkRequiredFields(req, ['contactNo']);
        if (requiredResult.status === false) {
          __.out(res, 400,requiredResult.missingFields+'field mandatory', requiredResult.missingFields);
       }else{
        let phone = req.body.contactNo;
        userCollection.findOne({contactNo:phone},async function(err,user){
          if(err || user==null){
            __.out(res, 300,"User with this contact number not found please sign up..", err);

           // res.status(401).json({data:err, message:"User with this contact number not found please sign up.."});
          }else{
            console.log("contact id rwqerwer:",user);
            var sixdigitsrandom = Math.floor(100000 + Math.random() * 900000);
            user.otp=sixdigitsrandom;
            await user.save()
            //send an email
            var mailOptions = {
              from: 'astroworldsai@gmail.com',
              to: user.email,
              subject: 'verification Otp from Astroworld',
              html: 'Hello Mr/Ms.'+ user.name + ' your contact Number is '+
                      user.contactNo + ' to Verify your subscription please refer '+ sixdigitsrandom +' as OTP.' 
            };
            sendEmail(mailOptions);
           
            var data={otp:sixdigitsrandom,contactNo:user.contactNo,userType:user.userType};
            let msg= 'Hello Mr/Ms.'+ user.name + ' your contact Number is '+
            user.contactNo + ' to Verify your subscription please refer '+ sixdigitsrandom +' as OTP.';
           //send SMS
            sendSMS(msg,user.contactNo,user.countryCode);
            __.out(res,200,"verification code sent successfully.",data)
           // res.status(200).json({data:{otp:sixdigitsrandom}, message:"verification code sent successfully."});
          }
        })
       }
      
       }catch(e){
         console.log("In catch",e);
          __.out(res, 500, "Something went wrong",e);
 
       }
      
     }

     async resetPassword(req,res){

      try{
          let requiredResult = await __.checkRequiredFields(req, ['contactNo','userType','password']);
          if (requiredResult.status === false) {
            __.out(res, 400, requiredResult.missingFields+'field mandatory',requiredResult.missingFields);
         }else{
          let User = req.body;
          userCollection.findOne({contactNo: req.body.contactNo, $or:[{userType:User.userType},{userType:3}]},
           function(err,user){
             if(err || user==null){
               //res.status(401).json({data:err, message:"User with this contact number not found please sign up.."});
               __.out(res, 300,"User with this contact number not found please sign up..", err);
   
             }
             else{
              if(User.userType==2 || User.userType=="2"){
                bcrypt.hash(User.password, salt, async function(err, hash) {
                  if(err){
                   // res.json({status:401,data:err, message:"Colden't update new pwd.. please contact to admin"});
                    __.out(res, 300,"Couldn't update password, please contact admin", err);
    
                  }else{
                    userCollection.update({_id:user._id},{$set:{passwordAstrologer:hash}},function(err2,update){
                      if(err2){
                       //res.status(401).json({data:err, message:"Colden't update new pwd.. please contact to admin"});
                       __.out(res, 300,"Couldn't update password", err2);
    
                      }else{
                       // res.status(200).json({data:update, message:"Password changed SUccessfully."});
                       __.out(res, 200,"Password changed Successfully.", update);
    
                      }
                    });
                  }
                })
              }else{
                bcrypt.hash(User.password, salt, async function(err, hash) {
                  if(err){
                   // res.json({status:401,data:err, message:"Colden't update new pwd.. please contact to admin"});
                    __.out(res, 300,"Couldn't update password, please contact admin", err);
    
                  }else{
                    userCollection.update({_id:user._id},{$set:{password:hash}},function(err2,update){
                      if(err2){
                       //res.status(401).json({data:err, message:"Colden't update new pwd.. please contact to admin"});
                       __.out(res, 300,"Couldn't update password", err2);
    
                      }else{
                       // res.status(200).json({data:update, message:"Password changed SUccessfully."});
                       __.out(res, 200,"Password changed SUccessfully.", update);
    
                      }
                    });
                  }
                })
              }
             
             }
           })
         }
      }catch(e){
         console.log("In catch",e);
          __.out(res, 500, "Something went wrong",e);
 
       }
      
     }

     async updateUser(req,res){
       try{
         console.log("here...");
        console.log(req.files);
        console.log("Req.body: ",req.body);
        var requestBody = req.body;
        if(Array.isArray(req.files) && req.files.length){
          if(req.body.userType && req.body.userType==1){
            __.out(res, 201, "User Update is under construction");
          }else{
            let requiredResult = await __.checkRequiredFields(req, ['contactNo','userType','gender','experience','city','country','dob','language','skill','address','state','pinCode','email','name']);
            if (requiredResult.status === false) {
              __.out(res, 400, requiredResult.missingFields+'field mandatory',requiredResult.missingFields);
           }else{
              let user = await userCollection.findOne({contactNo:requestBody.contactNo});
              if(!user || user==null){
                __.out(res, 300, "User not Found",null);

               // __.out(res, 400, "User not Found");
              }else{
                let update={};
                // update.callCharges = requestBody.callCharges;
                // update.ReportCharges = requestBody.ReportCharges;
                // update.chatCharges = requestBody.chatCharges;
                update.gender = requestBody.gender;
                update.experience = requestBody.experience;
                update.city = requestBody.city;
                update.country = requestBody.country;
                update.dob = new Date(requestBody.dob);
                update.language = requestBody.language;
                update.skills= requestBody.skill;
                update.address={
                  primary :requestBody.address,
                  state:requestBody.state,
                  pinCode:requestBody.pinCode
                };
                if(requestBody.adharCardNumber){
                  let validate = validator.isValidNumber(requestBody.adharCardNumber);
                  if(!validate || validate==false){
                    console.log("Validated is : ",validate);
                    return __.out(res, 300, "Please enter valid Adhar Number",null);
                  }else{
                    update.adharCardNumber = requestBody.adharCardNumber;
                  }
                }
  
                if(requestBody.workingWithOtherPortal && requestBody.workingWithOtherPortal == 'true'){
                    update.workingWithOtherPortal =true;
                }else{
                    update.workingWithOtherPortal = false;
                }
  
                if(requestBody.shortBio){
                   update.shortBio = requestBody.shortBio;
                }
                if(requestBody.longBio){
                  update.longBio = requestBody.longBio;
                }

                for(let i=0;i<=req.files.length-1;i++){
                  if(req.files[i].fieldname == 'profilePic'){
                    update.profilePic = req.files[i].location;
                  }else{
                    update.idProof = req.files[i].location;
                  }
                }

                if(requestBody.panNumber){
                  update.panNumber = requestBody.panNumber;
                }
                update.bankAccDetails ={};
                if(requestBody.bankAccountNumber){
                  update.bankAccDetails.bankAccNumber = requestBody.bankAccountNumber;
                }
                if(requestBody.ifsc){
                  update.bankAccDetails.ifsc = requestBody.ifsc;
                }
                if(requestBody.accountType){
                  update.bankAccDetails.accountType = requestBody.accountType;
                }
                if(requestBody.accountHolderName){
                  update.bankAccDetails.accHolderName = requestBody.accountHolderName;
                }
                if(requestBody.otherWorkingSite){
                  update.otherWorkingSite= requestBody.otherWorkingSite;
                }
                if(requestBody.monthlyEarning){
                  update.monthlyEarning = requestBody.monthlyEarning;
                }
               // update.password = user.astrologistDetails.password;
             
                try{
                  console.log("In try");
                 userCollection.update({_id:user._id},
                  {$set:
                    {email:requestBody.email,name:requestBody.name,astrologistDetails:update,profileUpdated:true}}, {upsert: false},
                    function(err,data){
                    if(err){
                     
                      __.out(res, 300, "Couldn't update data, please try again later",err);
                    }else{
                     
                      let upData = {
                        _id:user._id, email:user.email,contactNo:user.contactNo,name:user.name,astrologistDetails:update
                      }
                      __.out(res, 200,"data updated", upData);
                    }
                  })
                }catch(e){
                  console.log("In catch me here: ",e);
                }
                
              }
           }
          }
        }else{
          __.out(res, 300, "Profile photo and Id-proof are menadatory",null);
        }
        

       }catch(e){
      
        __.out(res, 500, "Something went wrong",e);
       }
     }

    
     async getAstrologersList(req,res){
        //const pageCount = Math.ceil(posts.length / 10);
        var page = req.body.page;
        if (page == undefined || !page)
        page = 1;
      var limit = 10;
      var skip = (page - 1) * limit;
     
         userCollection.find({userType:2,isApplicationAccepted:true},{_id:1, name:1, contactNo:1,userType:1,email:1,'astrologistDetails.profilePic':1,'astrologistDetails.skills':1,
         'astrologistDetails.language':1,'astrologistDetails.experience':1,userId:1,countryCode:1,activeStatus:1,firebaseUserId:1,currentCallStatus:1},{skip: skip, limit:limit},async function(err,users){
  
            if(err){
              __.out(res, 300,"Error when finding astrologer, please try again.", err);
            }else{
              let arr=[];
              for(let i=0;i<=users.length-1;i++) {
                var dt = JSON.stringify(users[i]);
                dt=JSON.parse(dt);
                let ccode="+91";
                let data={}
               if(dt.countryCode){
                  ccode = dt.countryCode;
               }
              
               if(ccode=="+91"){
                 data = await indianCollection.findOne({astrologerId:dt._id},{call:1,chat:1,report:1,qa:1}); 
               }else if(ccode=="+1"){
                data = await usCollection.findOne({astrologerId:dt._id},{call:1,chat:1,report:1,qa:1}); 
               }else{
                data = await taiwanCollection.findOne({astrologerId:dt._id},{call:1,chat:1,report:1,qa:1}); 
               }
               var name ="";
               name = dt.name.split(" ");
               name = name[0];
               dt.name=name;
               let price =data;
               dt.price = price;
              //  var name ="";
              //  name = obj.name.split(" ");
              //  name = name[0];
              //  obj.name=name;
              arr.push(dt);
              if(i==users.length-1){
                __.out(res, 200,"Successfully retrieved astrologer .", arr);
              }
            }
              console.log("DONE!!!");
             
            }
         });
      //  userCollection.find({$or:[{userType:2},{currentUser:2},{userType:3}]},
      //   {_id:1,name:1,email:1,contactNo:1,astrologistDetails:1,userId:1,activeStatus:1,countryCode:1},function(err,data){
      //    if(err){
      //      __.out(res,300,"Error when finding Astrologers");
      //    }else{
      //      __.out(res,200,"Successfully received data",data);
      //    }
      //  })
     }

     async getAstrologerDetails(req,res){
       console.log(req.params.id);
       if(req.params.id){
         let id=req.params.id;
         try{
        
           let data = await userCollection.findOne({_id:req.params.id});
           console.log("DATA1: ",data);
            if(!data || data==null){
              __.out(res, 300,"Error when finding astrologer, please try again.", err);
            }else{
              console.log("DATA: ",data);
              var detail = {
                _id: data._id,
                email:data.email,
               // name:data.name,
                contactNo:data.contactNo,
                personalDetails:data.astrologistDetails,
                userType:data.userType,
                userId:data.userId,
                countryCode:data.countryCode? data.countryCode : '+91',
                currentCallStatus:data.currentCallStatus
              }
              console.log("DATADetails: ",detail);
              var nm = data.name.split(" ");
              detail.name = nm[0];
              let ccode="+91";
              let data1={};
             if(detail.countryCode){
                ccode = detail.countryCode;
             }
             console.log("details: ",detail);
            
             if(ccode=="+91"){
               data1 = await indianCollection.findOne({astrologerId:detail._id},{call:1,chat:1,report:1,qa:1}); 
             }else if(ccode=="+1"){
              data1 = await usCollection.findOne({astrologerId:detail._id},{call:1,chat:1,report:1,qa:1}); 
             }else{
              data1 = await taiwanCollection.findOne({astrologerId:detail._id},{call:1,chat:1,report:1,qa:1}); 
             }
             let price =data1;
             detail.price = price;

              __.out(res, 200,"Successfully retrieved astrologer .", detail);

            }
         
         }catch(e){
          __.out(res, 500,"Something went wrong", e);
         }
          
       }else{
        __.out(res, 500, "Please send Astrologer Id ",e);
       }
     }

     async listOfAstrologers(req,res){

      //const pageCount = Math.ceil(posts.length / 10);
      var page = req.body.page;
      if (page == undefined || !page)
      page = 1;
    var limit = 10;
    var skip = (page - 1) * limit;
   
       userCollection.find({userType:2,isApplicationAccepted:true},{_id:1, name:1, contactNo:1,userType:1,email:1,'astrologistDetails.profilePic':1,
       'astrologistDetails.language':1,'astrologistDetails.experience':1,userId:1,isPriorityGiven:1,
       countryCode:1,activeStatus:1,currentCallStatus:1},{skip: skip, limit:limit},async function(err,users){

          if(err){
            __.out(res, 300,"Error when finding astrologer, please try again.", err);
          }else{
            let arr=[];
            let v=0;
            for(let i=0;i<=users.length-1;i++) {
              var dt = JSON.stringify(users[i]);
              dt=JSON.parse(dt);
              let ccode="+91";
              let data={}
             if(dt.countryCode){
                ccode = dt.countryCode;
             }

            
            
             if(ccode=="+91"){
               data = await indianCollection.findOne({astrologerId:dt._id},{call:1,chat:1,report:1,qa:1}); 
             }else if(ccode=="+1"){
              data = await usCollection.findOne({astrologerId:dt._id},{call:1,chat:1,report:1,qa:1}); 
             }else{
              data = await taiwanCollection.findOne({astrologerId:dt._id},{call:1,chat:1,report:1,qa:1}); 
             }
             var name ="";
             name = dt.name.split(" ");
             name = name[0];
             dt.name=name;
             let price =data;
             dt.price = price;
            //  var name ="";
            //  name = obj.name.split(" ");
            //  name = name[0];
            //  obj.name=name;
            arr.push(dt);
            if(dt.isPriorityGiven == true){
              arr.splice(0,0,dt);
            }
            if(i==users.length-1){
              const unique = arr.filter((elem,index)=>
                arr.findIndex(obj=>obj.userId===elem.userId)===index
              )
              __.out(res, 200,"Successfully retrieved astrologer .", unique);
            }
          }
            console.log("DONE!!!");
           
          }
       });
     }

     async askQuestion(req,res){
      try{
        let requiredResult = await __.checkRequiredFields(req, ['userId','astrologerId','reportSubType','firstName','lastName','mobileNumber']);
        if (requiredResult.status === false) {
          __.out(res, 400,requiredResult.missingFields+' fields mandatory', requiredResult.missingFields);
       }else{
          var data = req.body;
          console.log("data: ",data);
            data.reportType = 1;
          // if(req.files.length>0){
          //   data.file = req.files[0].location;
          //   console.log("file:",data.file);
          // }

          let d= new reportCollection(data);
          try{
            let saved = d.save();
            __.out(res, 200,"question request sent", d);
          }catch(ec){
            __.out(res, 300, "Error while sending report please try later",ec);
          }

       }
      }catch(e){
        console.log("In catch",e);
        __.out(res, 500, "Something went wrong",e);
      }
     }

     async sendReport(req,res){
      try{
        let requiredResult = await __.checkRequiredFields(req, ['userId','astrologerId','reportSubType','firstName','lastName','mobileNumber']);
        if (requiredResult.status === false) {
          __.out(res, 400,requiredResult.missingFields+' fields mandatory', requiredResult.missingFields);
       }else{
          var data = req.body;
          console.log("data: ",data);
            data.reportType = 2;
          // if(req.files.length>0){
          //   data.file = req.files[0].location;
          //   console.log("file:",data.file);
          // } 

          let d= new reportCollection(data);
          try{
            let saved = d.save();
            __.out(res, 200,"report request sent", d);
          }catch(ec){
            __.out(res, 300, "Error while sending report please try later",ec);
          }

       }
      }catch(e){
        console.log("In catch",e);
        __.out(res, 500, "Something went wrong",e);
      }
     }

     async getQuestions(req,res){
     
       var id= req.body.astrologerId;
    
       reportCollection.find({astrologerId:id,reportType:1},function(err,data){
         if(err || !data || data ==null){
          __.out(res, 300, "Error while getting data please try later",err);
         }else{
          __.out(res, 200,"Received data", data);
         }
       }).sort({_id:-1})
     }

     async getReports(req,res){
    
      var id= req.body.astrologerId;
    
      reportCollection.find({astrologerId:id,reportType:2},function(err,data){
        if(err || !data || data ==null){
         __.out(res, 300, "Error while getting data please try later",err);
        }else{
         __.out(res, 200,"Received data", data);
        }
      }).sort({_id:-1})
    }

    async respondReport(req,res){

      let body = req.body;
      
      let requiredResult = await __.checkRequiredFields(req, ['userId','astrologerId','message','queryId','reportType']);
      if (requiredResult.status === false) {
        __.out(res, 400,requiredResult.missingFields+' fields mandatory', requiredResult.missingFields);
     }else{
        let user = await userCollection.findOne({_id:body.userId,userType:1});
        if(!user || user==null){
          return __.out(res, 300, "This user does not present in system.",null);
        }

        let astrologer = await userCollection.findOne({_id:body.astrologerId,userType:2});
        if(!astrologer || astrologer==null){
          return __.out(res, 300, "Something went wrong, please contact administartor.",null);
        }

        let report;
          report = await reportCollection.findOne({_id:body.queryId},function(err,report){
                if(err){
                  __.out(res, 300, "Something went wrong, please contact administartor.",null);
                }else{
                    report.response=body.message;
                    report.isAnswered = true;
                    if(req.files && req.files.length>0){
                      console.log("req file: ",req.files);
                      report.attachment = req.files[0].location;
                    }

                    report.save();


                    //send this to user emailId
                    let msg= body.message;
                     //send SMS
                     let smsMsg = "Hi, "+"\n"+ "Query You asked to "+astrologer.name +" from astrolworld is beed answered please check your email."
                     sendSMS(smsMsg,user.contactNo,user.countryCode);
                     //send an email
                     var Attachments;
                     if(req.files.length>0){
                      Attachments= body.reportType==2? [{ filename: 'Report.pdf', path: req.files[0].location, contentType: 'application/pdf' }]:'';

                     }
                   var mailOptions = {
                     from: 'astroworldsai@gmail.com',
                     to: user.email,
                     subject: 'Response from Astrologer of AstroWorld...',
                     html: msg,
                     attachments: body.reportType==1? '' :Attachments
                   };
                   try{
                    sendEmail(mailOptions);
                   }catch(e){
                     return __.out(res,300,"Email not sent. ",e);
                   }
                  
                     __.out(res, 200, "responsed successfully....",null);
                   }

                });
       
        console.log(user);
     }
    }

    async updateActiveStatus(req,res){
      let body = req.body;
        
      let requiredResult = await __.checkRequiredFields(req, ['userId','status']);
      if (requiredResult.status === false) {
        __.out(res, 400,requiredResult.missingFields+' fields mandatory', requiredResult.missingFields);
     }else{
        userCollection.findOne({userId:body.userId},async function (error,user){
          if(error || user==null || !user){
             __.out(res, 300, "Couldn't find this user.",null);
          }else{
            if(user.userType==1){
               __.out(res, 300, "Only Astrologer can set Activity status.",null);
            }else{
              
              try{
                await userCollection.update({userId:body.userId},{
                  $set:{
                    activeStatus : body.status
                  }
                })
                // user.activeStatus== body.status;
                // await user.save();
                console.log("status updated..")
              }catch(e){
                __.out(res, 300, "Error when updating data",e);
              }
             
              let data = {
                userId:user.userId,
                activeStatus:body.status
              }
              __.out(res, 200, "user updated successfully.",data);
            }
          }
        })
     }
    }

    async acceptRequest(req,res){
      var reqbody = req.body; //send astrologer userId and queryId
      console.log("req:", typeof(reqbody.isRequestAccpted));
      let requiredResult = await __.checkRequiredFields(req, ['userId','queryId','isRequestAccpted']);
      if (requiredResult.status === false) {
        __.out(res, 400,requiredResult.missingFields+' fields mandatory', requiredResult.missingFields);
     }else{
      let user = await userCollection.findOne({userId:reqbody.userId});
      if(!user || user==null || user.userType==1){
        __.out(res, 300, "Couldn't find this astrologer, Please contact admin or try again later",null);
      }else{
        reportCollection.findOne({_id:reqbody.queryId},async function(err,report){
          if(err || !report || report==null){
            __.out(res, 300, "Error when searching report in database.",err);
          }else{
            
               await reportCollection.update({_id:reqbody.queryId},
                  {$set:
                    {isRequestAccpted:reqbody.isRequestAccpted}
                  });
                  report.isRequestAccpted=reqbody.isRequestAccpted;
                 
                  __.out(res, 200, "status updated successfully",report);
             
          }
        });
      }
     }
    }

    async updateFirebaseId(req,res){
      var reqbody = req.body; //send astrologer userId and queryId
      let requiredResult = await __.checkRequiredFields(req, ['userId','firebaseUserId']);
      if (requiredResult.status === false) {
        __.out(res, 400,requiredResult.missingFields+' fields mandatory', requiredResult.missingFields);
       }else{
        userCollection.findOne({userId:reqbody.userId},async function(error,userData){
          if(error || userData==null || !userData){
             __.out(res, 300, "User Not Found.",null);

          }else{
            console.log("reqbody: ",reqbody); 
              userData.firebaseUserId = reqbody.firebaseUserId;
              try{
              //  await userData.save();
             let dt = await userCollection.findOneAndUpdate({userId:reqbody.userId},
              {"$set":{"firebaseUserId":reqbody.firebaseUserId}});
             console.log("dt: ",dt);  
             let data = {
                  userId : dt.userId,
                  firebaseUserId :reqbody.firebaseUserId
                }
                __.out(res, 200, "status updated successfully",data);
              }catch(e){
                __.out(res, 300, "Couldn't update data.",e);
              }
          }
        })
     }
    }
 

    async retrieveCalls(req,res){
      client.calls.list({limit: 20})
            .then(calls =>res.send(calls));
    }

   async polling(req,res){
     console.log("polling req", req.body);
      console.log("REQ QUERY: ", req.query);
     //req needs astroId and userId
     //here astroNo is astrousetrId and userId is normal userId
      if(req.body.CallStatus=='initiated'){
        if(req.query && (req.query.astrologerId!==" "|| req.query.astrologerId!==null || req.query.astrologerId!==undefined)){
         console.log("In update queryto update astro");
          let update = userCollection.findOneAndUpdate({userId:req.query.astrologerId},{$set:{currentCallStatus:true}});
        }
       
      }
      else if(req.body.CallStatus=='completed' || req.body.CallStatus == 'Completed'){
        var minutes = (req.body.CallDuration/60)-1;//since the first minute is free substracting -1
        let pricings;
        let astrologer = await userCollection.findOne({userId:req.query.astrologerId},{_id:1});
        let update = await userCollection.findOneAndUpdate({userId:req.query.astrologerId},{$set:{currentCallStatus:false}});
        let userDetails = await userCollection.findOne({userId:req.query.userId},{_id:1,countryCode:1});
        let code = userDetails.countryCode ? userDetails.countryCode:'+91';
         if(code == "+91" || code =="91"){
           pricings = await indianCollection.findOne({astrologerId:astrologer._id},{call:1});

         }else if(code=="+1"||code=="1"){
          pricings= await usCollection.findOne({astrologerId:astrologer._id},{call:1});
         }else{
          pricings = await taiwanCollection.findOne({astrologerId:astrologer._id},{call:1});

         }
         console.log("Astrologer is: ",astrologer);
         console.log("pricins: ",pricings);
         let amount = minutes*pricings.call;
         console.log("Amoutn: ",amount);
         var options = {
          uri: "https://apisaiastroworld.com/payment/call/charges?userId="+req.query.userId+"&&amount="+amount+"&&astrologerId="+req.query.astrologerId+"&&type=call&&minutes="+minutes,
          method: "PATCH",
          headers: {
            'Content-Type': 'application/json'
          },
          rejectUnauthorized: false
        };
        console.log("REquest : ",options);
        request(options, async (err, response) => {
          if (response) {
            __.out(res, 200, "operatin Sucess",{data:response.body});
          }else{
            __.out(res,300, "Operation failed",err);
          }

         })
      }else{
        console.log("In not copleted state");
        var minutes = (req.body.CallDuration/60)-1;//since the first minute is free substracting -1
        var balance=req.query.balance;
        let pricings;
        let astrologer = await userCollection.findOne({userId:req.query.astrologerId},{_id:1});
        let userDetails = await userCollection.findOne({userId:req.query.userId},{_id:1,countryCode:1});
        let code = userDetails.countryCode ? userDetails.countryCode:'+91';
        if(code == "+91" || code =="91"){
          pricings = await indianCollection.findOne({astrologerId:astrologer._id},{call:1});

        }else if(code=="+1"||code=="1"){
         pricings= await usCollection.findOne({astrologerId:astrologer._id},{call:1});
        }else{
         pricings = await taiwanCollection.findOne({astrologerId:astrologer._id},{call:1});

        }
        let amount = minutes*pricings.call;
        if(amount>=balance){
          //disconect the call 
          //find call SID
          var callSID = req.body.CallSid;
          client.calls(callSID)
         .update({status: 'completed'})
          .then(call => console.log(call.to));

          var options = {
            uri: "https://apisaiastroworld.com/payment/call/charges?userId="+req.query.userId+"&&amount="+0+"&&astrologerId="+req.query.astrologerId+"&&type=call&&minutes="+minutes,
            method: "PATCH",
            headers: {
              'Content-Type': 'application/json'
            },
            rejectUnauthorized: false
          };
          console.log("REquest : ",options);
          request(options, async (err, response) => {
            if (response) {
              __.out(res, 200, "operatin Sucess",{data:response.body});
            }else{
              __.out(res,300, "Operation failed",err);
            }
  
           })
          //need to R nd D
        let update = await userCollection.findOneAndUpdate({userId:req.query.astrologerId},{$set:{currentCallStatus:false}});

        }
        
        __.out(res, 200, "Call is in process",{status:req.body.CallStatus});
       
      }
   }

   async notifyForMessage(req,res){
    let requiredResult = await __.checkRequiredFields(req, ['astrologerId','userName']);
    if (requiredResult.status === false) {
      __.out(res, 400,requiredResult.missingFields+' fields mandatory', requiredResult.missingFields);
   }else{
    let body=req.body;
    userCollection.findOne({userId:body.astrologerId},function(error,astrologer){
      if(error || astrologer==null){
        __.out(res, 300,"Problem when reaching to this astrologer..", err);

      }else{
        //send text message to astrloger
        let msg = "Hi "+astrologer.name+ ", \n"+body.userName +" have sent you a message, to check login to astroworld account."
        sendSMS(msg,astrologer.contactNo,astrologer.countryCode);
        __.out(res,200,"Message sent to astrologer.",null);
      }
    })
    }
   }

   async deductBalance(req,res){
     // for chat send minutes.
    let requiredResult = await __.checkRequiredFields(req, ['astrologerId','userId','type']);
    if (requiredResult.status === false) {
      __.out(res, 400,requiredResult.missingFields+' fields mandatory', requiredResult.missingFields);
   }else{
       let astro = await userCollection.findOne({_id:req.body.astrologerId},{_id:1,userId:1});
        userCollection.findOne({_id:req.body.userId},async function(err,user){
         let countryCode = "+91";
         if(user.countryCode){
           countryCode = user.countryCode;
         }
         let pricings;
         let countryIs = "IN";
         if(countryCode == "+91" || countryCode == "91"){
           pricings=await indianCollection.findOne({astrologerId:astro._id});
         }
         else if(countryCode == "+1" ||countryCode =="1"){
           pricings = await usCollection.findOne({astrologerId:astro._id});
           countryIs ="US";
         }
         else{
          pricings = await taiwanCollection.findOne({astrologerId:astro._id});
          countryIs ="TW";
         }
         //balance deductions
         let amount = 0;
         let minutes = req.body.minutes-1
         if(req.body.type == "chat"){
           console.log("PRICE IS: ",pricings);
            let chatpricing = pricings.chat;
            amount = chatpricing * minutes;//since First minute is free substracting with 1
         }
         if(req.body.type == "qa"){
          let qatpricing = pricings.qa;
          amount = qatpricing;
         }
         if(req.body.type == "report"){
          let reportpricing = pricings.report;
          amount = reportpricing;
         }

         var options = {
          uri: "https://apisaiastroworld.com/payment/call/charges?userId="+user.userId+"&&amount="+amount+"&&type="+req.body.type+"&&minutes="+minutes+"&&astrologerId="+astro.userId,
          method: "PATCH",
          headers: {
            'Content-Type': 'application/json'
          },
          rejectUnauthorized: false
        };
        console.log("REquest : ",options);
        request(options, async (err, response) => {
          if (response) {
            __.out(res, 200, "operatin Sucess",{data:response.body});
          }else{
            __.out(res,300, "Operation failed",err);
          }

         })

       })
    }
   }

   async getAmount(req,res){
    var options = {
      uri: "https://apisaiastroworld.com/payment/get/wallet?userId="+'a00',
      method: "GET",
      headers: {
        'Content-Type': 'application/json'
      },
      rejectUnauthorized: false
    };
    console.log("REquest : ",options);
    request(options, async (err, response) => {
      if (response) {
        __.out(res, 200, "operatin Sucess",{data:response.body});
      }else{
        __.out(res,300, "Operation failed",err);
      }

     })
   }

   async filterAstrolegers(req,res){
  
    let query ={userType:2,isApplicationAccepted:true};
    if(req.body.languages.length != 0){
      //let languages = JSON.parse(req.body.languages)
      let languages =req.body.languages;
      query["astrologistDetails.language"] = {"$in":languages}
    }
    if(req.body.skills.length != 0){
     // let skills = JSON.parse(req.body.skills);
     let skills = req.body.skills;
      query["astrologistDetails.skills"] = {"$in":skills}
    }
    if(req.body.experience !=0 || req.body.experience !="" ||req.body.experience != undefined || req.body.experience != null ){
      let experince = req.body.experience;
      if(experince=="m20"){
        query["astrologistDetails.experience"] ={"$gte":20}
      }
      if(experince == 10){
        query["astrologistDetails.experience"] ={"$lte":experince }
      }
      if(experince == 20){
        query["astrologistDetails.experience"] ={"$lte":experince }
      }
    }

    console.log("Query is:", query);
     try{
      let users = await userCollection.find(query,{_id:1, name:1, contactNo:1,userType:1,email:1,'astrologistDetails.profilePic':1,'astrologistDetails.skills':1,
      'astrologistDetails.language':1,'astrologistDetails.experience':1,userId:1,countryCode:1,activeStatus:1,firebaseUserId:1,currentCallStatus:1})
      //res.send(result)

      let arr=[];
      for(let i=0;i<=users.length-1;i++) {
        var dt = JSON.stringify(users[i]);
        dt=JSON.parse(dt);
        let ccode="+91";
        let data={}
       if(dt.countryCode){
          ccode = dt.countryCode;
       }
      
       if(ccode=="+91"){
         data = await indianCollection.findOne({astrologerId:dt._id},{call:1,chat:1,report:1,qa:1}); 
       }else if(ccode=="+1"){
        data = await usCollection.findOne({astrologerId:dt._id},{call:1,chat:1,report:1,qa:1}); 
       }else{
        data = await taiwanCollection.findOne({astrologerId:dt._id},{call:1,chat:1,report:1,qa:1}); 
       }
       var name ="";
       name = dt.name.split(" ");
       name = name[0];
       dt.name=name;
       let price =data;
       dt.price = price;
      //  var name ="";
      //  name = obj.name.split(" ");
      //  name = name[0];
      //  obj.name=name;
      arr.push(dt);
      // if(i==users.length-1){
      //   __.out(res, 200,"Successfully retrieved astrologer .", arr);
      // }
      }
      __.out(res, 200, "operatin Success",arr);
     }catch(err){
     // res.send(err);
      __.out(res, 300, "operatin failed",{data:null});

     }
     
   }

   async saveLang(req,res){
      //var arr = ["marathi","english","Hindi"];
      if(req.body.language){
        var sorted = [];
        for (var i = 0; i < req.body.language.length; i++) {
            sorted.push(req.body.language[i].toLowerCase());
        }
        languageCollection.findOneAndUpdate({ID:1},{ $addToSet: { languages: sorted } },function(err,data){
          if(err){
            console.log("ERR: ",err);
          }else{
            console.log("DATA: ",data);
          }
        })
      }
      if(req.body.expertise){
        var sorted = [];
        for (var i = 0; i < req.body.expertise.length; i++) {
            sorted.push(req.body.expertise[i].toLowerCase());
        }
        languageCollection.findOneAndUpdate({ID:2},{ $addToSet: { expertise: req.body.expertise } },function(err,data){
          if(err){
            console.log("ERR: ",err);
          }else{
            console.log("DATA: ",data);
          }
        })
      }
      __.out(res, 200, "Updated successfully",{});
     
    //  let data ={
    //    ID : 2,
    //    expertise : arr
    //  }
    //  let dt = new languageCollection(data);
    //  let d2 = await dt.save();
    //  console.log("D@: ",d2); 
   } 
   async userBlog(req,res){
     let blogInfo = {
       blogTitle:req.body.blogTitle,
       blogBody:req.body.blogBody,
       userId:req.body.userId
     }
     try{
      let blogColletion = new blogCollection(blogInfo);
      let blogResult = await blogColletion.save();
      res.send(blogResult)
     }catch(error){
      res.status(404).send({"msg":"Oops Something Went wrong","error":error})
     }
     
   }

   async getUserBlog(req,res){
     try{
      let result = await blogCollection.find()
      res.send(result);
     }catch(error){
      res.status(404).send({"msg":"Oops Something Went wrong","error":error})
     }
    
   }
   async updateUserBlog(req,res){
    let conditions = { "_id": req.body.id }
     ,update = req.body.blogContent
     ,options = {new:true}
     try{
      let result = await blogCollection.findOneAndUpdate(conditions,update,options)
      res.send({"msg":"Blog post updated successfully","data":result})
     }catch(error){
      res.status(404).send({"msg":"Oops Something Went wrong","error":error})
     }
      
   }
   async deleteBlogPost(req,res){
     try{
       let query = {"_id":req.query.id}
       console.log(query)
      let result = await blogCollection.deleteOne(query);
      res.send({"msg":"blog post deleted successfully"})
     }catch(error){
      res.status(404).send({"msg":"Oops Something Went wrong","error":error})

     }
   }

   async listOfexprtises(req,res){
    languageCollection.find({},function(err,data){
      if(err){
        __.out(res, 300,"Problem when reaching to this data..", err);
      }else{
        var languages =[]; var expertise=[];
        for(let i=0;i<=data.length-1;i++){
          if(data[i].ID == 1){
            languages = data[i].languages;
          }
          if(data[i].ID==2){
            expertise = data[i].expertise;
          }
        }
        var result = {lang:languages, expt: expertise};
        __.out(res, 200, "received successfully",result);
      }
    })
   }
  }
var user = new User();
module.exports = user;

