const mongoose = require('mongoose');
const adminCollection = require("../model/admin");
const userCollection = require("../model/user");
const reportCollection = require("../model/reports");
const indianCollection =require("../model/indiaPrices");
const usCollection = require("../model/usPrices");
const taiwanCollection = require("../model/taiwanPrices");
const comingUserCollection = require("../model/comingusers");
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const __ = require('../helpers/globalFunctions');
const twilioApp = require('../helpers/twillioConfig');
const salt = 10;
var jwt_key = "secret";
var nodemailer = require('nodemailer');



var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'astroworldproject@gmail.com',
        pass: 'Astroworld@123'
       }
   });

   function sendEmail(mailOptions) {
    transporter.sendMail(mailOptions, function(error, info){
      if (error) {
        console.log("in error: ",error);
      } else {
        console.log('Email sent: ' + info.response);
      }
    });
  
   }

   function sendSMS(message,contactNo){
   
   let c= '+91 '+contactNo;
    const welcomeMessage = message;

    twilioApp(c, welcomeMessage);
  //  __.out(res,200,"Successfully received data",null);
  }

class Admin{
    async createAdmin(req,res){
        try{
            let requiredResult = await __.checkRequiredFields(req, ['name','contactNo','password']);
            if (requiredResult.status === false) {
              __.out(res, 400,requiredResult.missingFields+'field mandatory', requiredResult.missingFields);
           }
           else{
                
                var user = req.body;
                bcrypt.genSalt(10, function(err, salt) {
                    bcrypt.hash(user.password, salt, async function(err, hash) {
                    if(err){
                      __.out(res,300,"Couldn't save record.. please contact to admin",err);
  
                     // res.status(300).json({status:300,data:err, message:"Coldn't save record.. please contact to admin"});
                    }else{
                        let userToSave={
                            name:user.name,
                            email:user.email,
                            contactNo : user.contactNo,
                            password:hash
                          }

                          try{
                            let userSave = new adminCollection(userToSave);
                            let userSaved = await userSave.save();
                            let msg='congratulations Mr/Ms.'+ user.name + 'You have been registered as an admin with Astroworld to login please use following credentials'
                               + ' Usename: '+user.contactNo+ ' Password: '+user.password;
                            //send SMS
                            sendSMS(msg,user.contactNo);
                            //send an email
                            if(user.email){
                                var mailOptions = {
                                    from: 'astroworldsai@gmail.com',
                                    to: user.email,
                                    subject: 'verification Otp from Astroworld',
                                    html: msg='congratulations Mr/Ms.'+ user.name + 'You have been registered as an admin with Astroworld to login please use following credentials'
                                    + ' Usename: '+user.contactNo+ ' Password: '+user.password
                                  };
                                  sendEmail(mailOptions);
                            }
                         
                          __.out(res,200,"User Successfully registered.",userSave);
                          }catch(e){
                            console.log("INHERE:",e)
                            __.out(res,500,"Something went wrong! please try again later.",e);
      
                          }
                    }
                })
            })
           }
        }catch(e){
            console.log("INHERE111:");
            __.out(res,500,"Somenthing went wrong! please cotact admin or try again later.",e);
        }
    }

    async login(req,res){
        try{
            let user=req.body;
            adminCollection.findOne({contactNo:user.contactNo},function(err,userdata){
                if(err){
                    __.out(res,300,"This contact number not found",err);

                }else if(userdata==null){
                  __.out(res,300,"This contact number not found",err);
                }else{
                  console.log("admin: ",user.password);
                  console.log("admindata: ",userdata.password)
                    bcrypt.compare(user.password, userdata.password, async function(err, result) {
                        if(err){
                          console.log("Eror ",err);
                             __.out(res, 300, "Something went wrong with password, Please try again",err);
                          }else{
                            console.log("result here is: ",result); 
                            if(result==false){
                             __.out(res, 300, "password does not match",result);
                            }else{
                             const token= jwt.sign({
                             
                                _id:userdata._id,
                                userType:userdata.userType,
                                contactNo:userdata.contactNo,
                                name:userdata.name
                              },
                              jwt_key,
                              {
                                expiresIn:"2h"
                              }
                              );
                            
                                await adminCollection.update({_id:userdata._id},{$set:{token:token}});
                            
                              let user ={
                                _id:userdata._id, name:userdata.name, email:userdata.email, userType:userdata.userType,
                                contactNo:userdata.contactNo
                              }
                            __.out(res, 200, "User login Successful..",{token:token,userData:user});
                            
         
         
                             // res.status(200).json({status:200,data:{token:token,userData:user},message:"Auth Succeeded.."});
                            }
                          }
                     });
                }
            })
        }catch(e){
            __.out(res,500,"Something went wrong! please try again later.",e);
        }
    }

    async resetPassword(req,res){
      let requiredResult = await __.checkRequiredFields(req, ['contactNo','password']);
      if (requiredResult.status === false) {
        __.out(res, 400, requiredResult.missingFields+'field mandatory',requiredResult.missingFields);
     }else{
      let User = req.body;
      adminCollection.findOne({contactNo: req.body.contactNo},
       function(err,user){
         if(err || user==null){
           //res.status(401).json({data:err, message:"User with this contact number not found please sign up.."});
           __.out(res, 300,"User with this contact number not found please sign up..", err);

         }
         else{
          bcrypt.hash(User.password, salt, async function(err, hash) {
            if(err){
             // res.json({status:401,data:err, message:"Colden't update new pwd.. please contact to admin"});
              __.out(res, 300,"Couldn't update password, please contact admin", err);

            }else{
              adminCollection.update({_id:user._id},{$set:{password:hash}},function(err2,update){
                if(err2){
                 //res.status(401).json({data:err, message:"Colden't update new pwd.. please contact to admin"});
                 __.out(res, 300,"Couldn't update password", err2);

                }else{
                 // res.status(200).json({data:update, message:"Password changed SUccessfully."});
                 __.out(res, 200,"Password changed SUccessfully.", update);

                }
              });
            }
          })
         }
        })
      }
    }

    async forgotPassword(req,res){
      let requiredResult = await __.checkRequiredFields(req, ['contactNo']);
      if (requiredResult.status === false) {
        __.out(res, 400,requiredResult.missingFields+'field mandatory', requiredResult.missingFields);
     }else{
      let phone = req.body.contactNo;
      adminCollection.findOne({contactNo:phone},async function(err,user){
        if(err || user==null){
          __.out(res, 300,"User with this contact number not found please sign up..", err);

         // res.status(401).json({data:err, message:"User with this contact number not found please sign up.."});
        }else{
          var sixdigitsrandom = Math.floor(100000 + Math.random() * 900000);
          user.otp=sixdigitsrandom;
          await user.save()
          //send an email
          var mailOptions = {
            from: 'astroworldsai@gmail.com',
            to: user.email,
            subject: 'verification Otp from Astroworld',
            html: 'Hello Mr/Ms.'+ user.name + ' your contact Number is '+
                    user.contactNo + ' to Verify your subscription please refer '+ sixdigitsrandom +' as OTP.' 
          };
          sendEmail(mailOptions);
         
          var data={otp:sixdigitsrandom,contactNo:user.contactNo,userType:user.userType};
        
          __.out(res,200,"verification code sent successfully.",data)
        }

      })
    }
  }

  async verifyOTP(req,res){
    let userdata = req.body;
    try{
      let requiredResult = await __.checkRequiredFields(req, ['contactNo','otp']);
      if (requiredResult.status === false) {
        __.out(res, 400,requiredResult.missingFields+'field mandatory', requiredResult.missingFields);
     }else{
      let userData=await adminCollection.findOne({contactNo:userdata.contactNo});
      
      if(!userData){
        __.out(res,300,"Something went wrong!,Couldn't find data with this contact number",userData);

      }else{
       
        if(userData.otp == userdata.otp){
          
          __.out(res,200,"user verified successfully..",null);

        }else{
        __.out(res,300,"invalid otp or userId please check again",null);

        }
      }
     }
    }catch(e){
        console.log("In catch",e);
        __.out(res, 500, "Something went wrong");
    }
  }

  async list(req,res){
    console.log("IN LIST...");
    userCollection.find({$or:[{userType:2},{currentUser:2},{userType:3}]},
      {_id:1,userId:1,name:1,email:1,contactNo:1,'astrologistDetails.profilePic':1,isApplicationAccepted:1,
      'astrologistDetails.language':1,'astrologistDetails.experience':1,isPriorityGiven:1}
      ,async function(err,data){
       if(err){
         __.out(res,300,"Error when finding Astrologers",err);
       }else{
         var arr=[];var priorAstrologers=[];
         for(let i=0;i<=data.length-1;i++){
           let obj=JSON.stringify(data[i]);
           obj=JSON.parse(obj);          
           var us = await usCollection.findOne({astrologerId:data[i]._id},{call:1,chat:1,report:1,qa:1});
           console.log("us: ",us);
           var india = await usCollection.findOne({astrologerId:data[i]._id},{call:1,chat:1,report:1,qa:1});
           var taiwan = await usCollection.findOne({astrologerId:data[i]._id},{call:1,chat:1,report:1,qa:1});
           obj.us = us;
           obj.india = india;
           obj.taiwan = taiwan;
           if(obj.isPriorityGiven == true){
             priorAstrologers.push(obj);
           }
           arr.push(obj);
           if(i==data.length-1){
              let totalData = ({astroList:arr,priorAstrologers:priorAstrologers});
            __.out(res,200,"Successfully received data",totalData);
           }else{
             console.log("list");
           }
         }
        
       }
     }).sort({_id:-1})
  }
  
  async getAstrologerDetail(req,res){
    console.log(req.params.id);
    if(req.params.id){
      let id=req.params.id;
      try{
       userCollection.findOne({_id:id},async function(err,data){
         if(err){
           __.out(res, 300,"Error when finding astrologer, please try again.", err);
         }else{
           var detail = {
             _id:data._id,
             email:data.email,
             name:data.name,
             contactNo:data.contactNo,
             personalDetails:data.astrologistDetails,
             userType:data.userType,
             isApplicationAccepted:data.isApplicationAccepted,
             countryCode:data.countryCode
           }
           let ccode="+91";
           let data1={};
          if(detail.countryCode){
             ccode = detail.countryCode;
          }
         
          if(ccode=="+91"){
            data1 = await indianCollection.findOne({astrologerId:detail._id},{call:1,chat:1,report:1,qa:1}); 
          }else if(ccode=="+1"){
           data1 = await usCollection.findOne({astrologerId:detail._id},{call:1,chat:1,report:1,qa:1}); 
          }else{
           data1 = await taiwanCollection.findOne({astrologerId:detail._id},{call:1,chat:1,report:1,qa:1}); 
          }
          let price =data1;
          detail.price = price;
           __.out(res, 200,"Successfully retrieved astrologer .", detail);

         }
       });
      }catch(e){
       __.out(res, 500,"Something went wrong", e);
      }
       
    }else{
     __.out(res, 500, "Please send Astrologer Id ",e);
    }
  }

  async acceptApplication(req,res){
    let body = req.body;
    userCollection.findByIdAndUpdate({_id:body.userId},{$set:{isApplicationAccepted:body.approve,
      acceptedBy:body.adminId}},async function(err, updated){
        if(err){
          __.out(res,300,"Error when updation",err);
        }else{
          let datanow= await userCollection.findOne({_id:body.userId},{_id:1,name:1,email:1,contactNo:1,'astrologistDetails.profilePic':1,isApplicationAccepted:1,
          'astrologistDetails.language':1,'astrologistDetails.experience':1});
          __.out(res,200,"Successfully updated data",datanow);
        }
      })
  }

  async listOfAdmins(req,res){
    adminCollection.find({userType:1,isDeleted:false},{password:0},function(err,data){
       if(err){
        __.out(res,300,"Error when finding All admins",err);
       }else{
        __.out(res,200,"Successfully received data",data);
       }
     })
  }

  async updateAdmin(req,res){
    let data = req.body;
    adminCollection.findById({_id:data.id},async function(err,admin){
      if(err || admin==null){
        _out(res,300,"Error finding this admin to update",err)
      }else{
        try{
          console.log("In try");
         adminCollection.update({_id:data.id},
          {$set:
            {email:data.email,name:data.name,contactNo:data.contactNo}}, {upsert: false},
            async function(err,data1){
            if(err){
              __.out(res, 300, "Couldn't update data, please try again later, check if admin with same contact number already exists.",err);
            }else{
              let user= await adminCollection.findOne({_id:data.id},{password:0})
              console.log("USER: ",user)
               __.out(res, 200,"data updated", user);
            }
          });
        }catch(e){
          console.log("In catch me here: ",e);
        }
      }
    })
  }

  async deleteAdmin(req,res){
      console.log("delete admin")
      let body = req.body;
      adminCollection.findByIdAndUpdate({_id:body.adminId},{$set:{isDeleted:true}},async function(err, updated){
          if(err){
            __.out(res,300,"Error when updation",err);
          }else{
           
            __.out(res,200,"Successfully deleted admin",null);
          }
        })
  }
  
  async updateAstrologerPrices(req,res){
    //object in form
    /*
      requestbody = {
        adminId:"admin id",
        astrologerId:"astrologer id",
        rates:[
          {india:{
            call:12,
            chat:12,
            report:13,
            qa:11
          }
         },
         us:{
           call:12,
           chat:12,
           report:13,
           qa:11
         },
         taiwan:{
            call:12,
           chat:12,
           report:13,
           qa:11
         }
        ]
      }

    */

    try{
      let requiredResult = await __.checkRequiredFields(req, ['adminId','astrologerId','rates']);
      if (requiredResult.status === false) {
        __.out(res, 400,requiredResult.missingFields+' fields mandatory', requiredResult.missingFields);
     }else{
        
        if(req.body.rates.length<3){
        __.out(res,300,"please full all country rates", null);

        }else{
          let counter=0;
          var datarecord={};
          for(let i=0;i<=req.body.rates.length-1;i++){
            let here = Object.keys(req.body.rates[i]);
            let currRate =Object.values(req.body.rates[i]);
            console.log("curre: ",currRate[0].call)
            var obj = {
              astrologerId:req.body.astrologerId,
              addedBy : req.body.adminId,
              call: currRate[0].call,
              chat:currRate[0].chat,
              report:currRate[0].report,
              qa:currRate[0].qa,
              enableCall:currRate[0].enableCall,
              enableChat:currRate[0].enableChat,
              enableQa:currRate[0].enableQa,
              enableReport:currRate[0].enableReport
            }
            console.log(obj);
            
            if(here[0] == 'india'){
              await indianCollection.remove({astrologerId:req.body.astrologerId});
              let country = new indianCollection(obj);
              let countrysave = await country.save();
              datarecord.india=true;
              counter=counter+1;
            }
            else if(here[0] == 'us'){
              await usCollection.remove({astrologerId:req.body.astrologerId});
              let country = new usCollection(obj);
              let countrysave = await country.save();
              datarecord.us=true;
              counter=counter+1;
            }
           else if(here[0] == 'taiwan'){
            await taiwanCollection.remove({astrologerId:req.body.astrologerId});
            let country = new taiwanCollection(obj);
            let countrysave = await country.save();
            datarecord.taiwan=true;
            counter=counter+1;
          }
            else{
              counter=counter+1;
            }
         
           
          }
          if(counter==req.body.rates.length){
            __.out(res,200,"records updated successfully", datarecord);
            console.log("here I am after fro loop", counter , "AND: ",req.body.rates.length);
          }else{
            __.out(res,300,"Couldn't save data properly please try again later", null);
          }
          
        }
     }
    }catch(e){
      __.out(res, 500, "Something went wrong",e);
    }
  }

  async getAstrologersReports(req,res){

    let reqbody = req.body;
    //In req body send astrologerId
    if(!reqbody.astrologerId){
      return  __.out(res, 400,astrologerId+' field mandatory', "atrologerId");
    }
    reportCollection.find({astrologerId:reqbody.astrologerId},
      {userId:1,firstName:1,lastName:1,mobileNumber:1,reportSubType:1,comment:1,response:1,language:1,maritalStatus:1,gender:1,isAnswered:1,isRequestAccpted:1},
      function(err,data){
      if(err){
        __.out(res,300,"Error when finding reports please try later..", null);
      }else if(data==null || !data.length>0){
        __.out(res,300,"No reports found..", null);
      }else{
        __.out(res,200,"data retrived!!", data);
      }
    });
  }
  
  async addComingUser(req,res){
    try{
      let requiredResult = await __.checkRequiredFields(req, ['contactNo']);
      if (requiredResult.status === false) {
        __.out(res, 400,requiredResult.missingFields+'field mandatory', requiredResult.missingFields);
     }
     else{
          let ifuser = await comingUserCollection.findOne({contactNo:req.body.contactNo});
          if(ifuser){
            return __.out(res,300,"User Already  registered.",ifuser);
          }
          let user = {
            contactNo : req.body.contactNo,
            email:req.body.email?req.body.email:"",
            name: req.body.name?req.body.name:""
          }

          var saveThis = new comingUserCollection(user);
          var saving = await saveThis.save();
          __.out(res,200,"User Successfully registered.",saving);
     }

  }catch(e){
            console.log("INHERE111:");
            __.out(res,500,"Somenthing went wrong! please cotact admin or try again later.",e);
        }
  }

  async getAllComngUsers(req,res){
    comingUserCollection.find({},function(err,data){
      if(err){
        res.send(err)
      }else{
        res.send({data:data});
      }
    })
  }

  async setPriority(req,res){
    console.log("In set priority");
    let reqbody = req.body;
    console.log("Req: ",reqbody.list);
    if(reqbody.list.length>3){
      return  __.out(res, 300,"cannot set astrologers more than 3");
    }
    else if(reqbody.list.length<2){
      return  __.out(res, 300,"Please set priority for any three astrologers.");
    }
    else{
      let unupdate = await userCollection.updateMany({isPriorityGiven:true},{$set:{isPriorityGiven:null}});
      console.log("Unupdate is: ",unupdate);
      for(let i=0;i<=reqbody.list.length-1;i++){
        console.log("In for: ",reqbody.list[i]); 
       let update=await userCollection.findOneAndUpdate({userId:reqbody.list[i]},{$set:{isPriorityGiven:true}});
       if(i == reqbody.list.length-1){
        __.out(res,200,"successfully updated!!");
       }
      }
     
    }
  }

}


var admin = new Admin();
module.exports = admin;
