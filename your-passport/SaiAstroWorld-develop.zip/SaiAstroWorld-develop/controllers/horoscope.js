var btoa = require('btoa');
var request = require('request');
const __ = require('../helpers/globalFunctions');
class HOroscope{
    async dailyHOroScope(req,res){
        console.log("Reached in horoscope");
        var userId = '614342';
        var apiKey = '968ddf491930d2bfb58162715eb38a83';
        var data = 'JSON Request Data';

        var clientServerOptions= {
            url: "https://json.astrologyapi.com/v1/sun_sign_prediction/daily/virgo",
            method: "POST",
            dataType:'json',
            headers: {
            "authorization": "Basic " + btoa(userId+":"+apiKey),
            "Content-Type":'application/json'
            }
        }

        request(clientServerOptions,async(err,response)=>{
            if(err){
                __.out(res,300,"Something went wrong!",err);
            }else{
                __.out(res,200,"Success!",response);
            }
        });
        
       
      
    }
   
}

var HR = new HOroscope();
module.exports = HR;