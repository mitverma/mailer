const mongoose = require("mongoose");
  Schema = mongoose.Schema;

  const UserSchema = new Schema(
    {
      countryCode:{
        type:String,
        default:"+91"
      },
      amount:{
        type:Number,
        default:0
      },
      contactNo:{
         type:String,
         unique:true
      },
      name:{
          type:String
      },
      email:{
        type: String,
        default: "",
        lowercase: true,
        trim: true,
        required: 'Email address is required',
        match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid Email address'],
        unique:true
      },
      userType:{
          type: Number //1-user, 2- Astrologer, 3-both
      },
      password:{
        type:String,
       // required:true,  //minimum 8 charachters, include at least 1 special Character and Number
        default:""
      },
      currentUser:Number,
       userDetails:{

       },
       astrologistDetails:{
        gender:String, //M-male, F-Female, O-others
        dob:Date,
        skills:[],
        experience:Number,
        city:String,
        country:String,
        bankAccDetails:{
          bankAccNumber:String,
          ifsc:String,
          accountType:String,
          accHolderName:String
        },
        language:[],
        expertise:[],
        address:{
          primary:String,
          state:String,
          pinCode:String
        },
        adharCardNumber:Number,
        workingWithOtherPortal:Boolean,
        shortBio:String,
        longBio:String,
        profilePic:String,
        idProof:String,
        panNumber:String,
        otherWorkingSite:String,
        monthlyEarning:String,
        callCharges:String,
        ReportCharges:String,
        chatCharges:String,
        
       },
       passwordAstrologer:{
        type:String,
       // required:true,  //minimum 8 charachters, include at least 1 special Character and Number
        default:""
      },
       otp:{
         type:Number
       },

       userToken:String,
       astroToken:String,
       isVerified:{
        type:Boolean
       },
       profileUpdated:{type:Boolean, default:false},
       pwdManage: {
        pwdUpdatedAt: {
          type: Date,
          default: Date.now
        },
        notifiedAt: {
          type: Date
        },
        pwdList: [
          {
            password: {
              type: String,
              required: true
            },
            createdAt: {
              type: Date,
              default: Date.now
            }
          }
        ]
      },
      isApplicationAccepted:{
        type:Boolean,
        default:null
      },
      acceptedBy:{
        type: Schema.Types.ObjectId,
        ref: "Admin"
      },
      userId:String,
      activeStatus:{
        type:String,
        enum:['Online','Offline','noStatus'],
        default:'noStatus'
      },
      location:String,
      firebaseUserId:{
        type:String,
        default:null
      },
      currentCallStatus:{
        type:Boolean,
        default:false
      },
      isPriorityGiven:{
        type:Boolean,
        default:null
      }
     

    })
    
  const User = mongoose.model("User", UserSchema);
  module.exports = User;