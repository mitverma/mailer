const mongoose = require("mongoose");
  Schema = mongoose.Schema;

  const comingSchema = new Schema(
    {
    
     contactNo:{
         type:String,
         unique:true
      },
      name:{
          type:String
      },
      email:{
        type: String,
                    default: "",
                    lowercase: true,
                    trim: true,
                    required: 'Email address is required',
                    match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid Email address']
      },
      
    })
    
  const comingUser = mongoose.model("cominguser", comingSchema);
  module.exports = comingUser;