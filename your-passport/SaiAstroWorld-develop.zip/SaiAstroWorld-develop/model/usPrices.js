const mongoose = require("mongoose");
  Schema = mongoose.Schema;

  const us = new Schema(
{
    astrologerId:{
        type: Schema.Types.ObjectId,
        ref: "User",
        unique:true
    },
    addedBy:{
        type: Schema.Types.ObjectId,
        ref: "Admin"
    },
    call:Number,
    chat:Number,
    report:Number,
    qa:Number,
    enableCall:{
        type:Boolean,
        default:false
    },
    enableChat:{
        type:Boolean,
        default:false
    },
    enableQa:{
        type:Boolean,
        default:false
    },
    enableReport:{
        type:Boolean,
        default:false
    },
   
    currency:{
        type:String,
        default:"U S Dollar"
    },
    code:{
        type:String,
        default:"$"
    },
    symbol:{
        type:String,
        default:"$"
    },
    createdAt:{
        type:Date,
        default:new Date()
    }
});

const usprice = mongoose.model("uSRate", us);
  module.exports = usprice;