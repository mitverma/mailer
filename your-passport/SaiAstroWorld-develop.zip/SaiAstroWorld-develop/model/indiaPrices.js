const mongoose = require("mongoose");
  Schema = mongoose.Schema;

  const india = new Schema(
{
    astrologerId:{
        type: Schema.Types.ObjectId,
        ref: "User",
        unique:true
    },
    addedBy:{
        type: Schema.Types.ObjectId,
        ref: "Admin"
    },
    call:Number,
    chat:Number,
    report:Number,
    qa:Number,
    enableCall:{
        type:Boolean,
        default:false
    },
    enableChat:{
        type:Boolean,
        default:false
    },
    enableQa:{
        type:Boolean,
        default:false
    },
    enableReport:{
        type:Boolean,
        default:false
    },
    currency:{
        type:String,
        default:"Indian rupee"
    },
    code:{
        type:String,
        default:"INR"
    },
    symbol:{
        type:String,
        default:"₹"
    },
    createdAt:{
        type:Date,
        default:new Date()
    }
});

const indiaprice = mongoose.model("indianRate", india);
  module.exports = indiaprice;