var express = require('express');
var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var counterSchema = new Schema({
	name: String,
	seq: Number
});
var Counters = mongoose.model("counter", counterSchema);

module.exports = Counters;