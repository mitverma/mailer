var express = require('express');
var mongoose = require('mongoose');
var counter = require('../model/counter_model');

var Schema = mongoose.Schema;

var userCounterSchema = new Schema({
   contactNo:String,
   userType:Number,
   order_id:Number
});
userCounterSchema.pre('save', function (next) {
    var doc = this;
    counter.findOneAndUpdate({ name: 'userCounter' }, { $inc: { seq: 1 } }, function (error, counter_res) {
        console.log(counter_res);
        if (error)
            return next(error);
        doc.order_id = counter_res.seq;
        next();
    });
}); 
var userCounter = mongoose.model("user_counter", userCounterSchema);
module.exports = userCounter;