const mongoose = require("mongoose");
  Schema = mongoose.Schema;

  const blogSchema = new Schema(
    {
     blogTitle:{
         type:String,
      },
      blogBody:{
          type:String
      },
      userId:{
        type:String,
        require:true
      }
    })
    
  const Blog = mongoose.model("Blog", blogSchema);
  module.exports = Blog;