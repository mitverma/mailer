const mongoose = require("mongoose");
  Schema = mongoose.Schema;

  const ReportsSchema = new Schema(
{
    reportType:{
        type:Number,
        required:true 
    },//1-Question Answer,  2- Reports
    userId:{
        type: Schema.Types.ObjectId,
        ref: "User"
    },
    astrologerId:{
        type: Schema.Types.ObjectId,
        ref: "User"
    },
    reportSubType:{
        type:String
    },
    firstName:String,
    lastName:String,
    mobileNumber:String,
    gender:String,
    dob:Date,
    dobTime:String,
    city:String,    
    state:String,
    country:String,
    maritalStatus:String,
    employment:String,
    language:String,
    comment:String,
    file:String,
    createdAt:{
        type:Date,
        default:new Date()
    },
    response:String,
    attachment:String,
    isAnswered:{
        type:Boolean,
        default:false
    }, //once replied set to true.
    isRequestAccpted:{
        type:Boolean,
        default:null
    },// once req accepted from astrlogers side set to true
    partnerInfo:{
        Name:String,
        dob:Date,
        pob:Date,
        ocupation:String
    }
})

const report = mongoose.model("Repot", ReportsSchema);
  module.exports = report;
