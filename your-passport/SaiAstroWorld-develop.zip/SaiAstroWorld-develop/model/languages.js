const mongoose = require("mongoose");
  Schema = mongoose.Schema;

  const languageSchema = new Schema(
{
    ID:Number,
    expertise:[{
        type:String,
        unique:true
    }],
    languages:[{
        type:String,
        unique:true
    }]

});

const language = mongoose.model("Language", languageSchema);
  module.exports = language;