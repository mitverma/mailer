const mongoose = require("mongoose");
  Schema = mongoose.Schema;

  const taiwan = new Schema(
{
    astrologerId:{
        type: Schema.Types.ObjectId,
        ref: "User",
        unique:true
    },
    addedBy:{
        type: Schema.Types.ObjectId,
        ref: "Admin"
    },
    call:Number,
    chat:Number,
    report:Number,
    qa:Number,
    enableCall:{
        type:Boolean,
        default:false
    },
    enableChat:{
        type:Boolean,
        default:false
    },
    enableQa:{
        type:Boolean,
        default:false
    },
    enableReport:{
        type:Boolean,
        default:false
    },
    currency:{
        type:String,
        default:"New Taiwan dollar"
    },
    code:{
        type:String,
        default:"TWD"
    },
    symbol:{
        type:String,
        default:" NT$"
    },
    createdAt:{
        type:Date,
        default:new Date()
    }
});

const taiwanprice = mongoose.model("taiwanRate", taiwan);
  module.exports = taiwanprice;