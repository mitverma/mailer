const mongoose = require("mongoose");
  Schema = mongoose.Schema;

  const adminSchema = new Schema(
    {
     contactNo:{
         type:String,
         unique:true
      },
      name:{
          type:String
      },
      email:{
        type: String,
                    default: "",
                    lowercase: true,
                    trim: true,
                    match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid Email address']
      },
      password:{
        type:String,
       // required:true,  //minimum 8 charachters, include at least 1 special Character and Number
        default:""
      },
       userType:{
         type:Number,
         default:1  //0-masterAdmin, 1 admin
       },
       token:String,
       isVerified:{
        type:Boolean
       },
       otp:{
        type:Number
      },
      isDeleted:{
        type:Boolean,
        default:false
      }
    })
    
  const Admin = mongoose.model("Admin", adminSchema);
  module.exports = Admin;