const _ = require('lodash');
class globalFunctions{
    async checkRequiredFields(req,requiredFields,source=false){
        let noMissingFields = _.reduce(requiredFields, (result, item) =>
        result && (item in req.body), true);
    if (!noMissingFields) {
        let missingFields = this.getMissingFields(req.body, requiredFields);

        return {
            status: false,
            missingFields: missingFields
        };
    } else {
        return {
            status: true
        };
     }
  }

  getMissingFields(requestedJsonInput, requiredFields) {
    let missingFields;
    missingFields = requiredFields.map(function (value, index) {
        if (!(value in requestedJsonInput))
            return value;
    });

    function removeUndefined(value) {
        return value !== undefined;
    }

    return missingFields.filter(removeUndefined);
  }

  out(res, statusCode, message,resultData = null) {
   
    if (statusCode === 401) {
        res.status(statusCode).json({
            status:statusCode,
            error: 'Unauthorized user'
        });
    }
    else if (statusCode === 204) {
        console.log("IN 300 me reached", message ,"and: ", resultData)
        res.status(statusCode).json({
            status:300,
            message: message,
            data:resultData
        });
    } else if (statusCode === 500) {
        res.status(statusCode).json({
            status:500,
            error: message,
            message:message,
            data:resultData
        });
    } else if (statusCode === 400) {
        res.status(statusCode).json({
            status:400,
            error: 'Required fields missing',
            fields: resultData,
            message:resultData +' fields mandatory.'
        });
    } else if (statusCode === 200) {
        res.status(statusCode).json({
            status:200,
            data: resultData,
            message:message
        });
    } else if (statusCode === 300) {
        res.status(statusCode).json({
            status:300,
            message: message,
            data:resultData
        });
    } else {
        /*200*/
        res.status(statusCode).json({
            message: resultData != null ? resultData : 'success'
        });
    }

}




}



globalFunctions = new globalFunctions();
module.exports = globalFunctions;
