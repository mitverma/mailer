let accountSid="ACbc3495679c2e90ac0c6dfbf866f16d2f";
let authToken="081d3f4b51925d9fa9b0916707171b47";
let contact="+15712537237";

const voiceCall = (req,response,phone,salesno,astrouserId,userId,balance) => {
  console.log("in send SqqqMS me",phone,"sales no:0",salesno);
    var url = 'http://ec2-3-21-75-140.us-east-2.compute.amazonaws.com:3000/users/connect/'+encodeURIComponent(salesno);
    console.log("in send SMS me",url);
    const client = require('twilio')(accountSid, authToken);
    client.calls
      .create({
        url: url,
        to: phone,
        from: contact,
        statusCallback: 'http://ec2-3-21-75-140.us-east-2.compute.amazonaws.com:3000/users/pollingstatus?userId='+userId+"&&astrologerId="+astrouserId+"&&balance="+balance,
        statusCallbackEvent: ['initiated', 'answered','ringing','completed','busy','canceled','failed','no-answer'],
        statusCallbackMethod: 'POST',
       })
       .then((message) => {
        console.log(message.responseText);
        response.send({
            message: 'Thank you! We will be calling you shortly.',
        });
      })
      .catch((error) => {
        console.log(error);
        response.status(500).send(error);
      });
  }
  
  module.exports = voiceCall;