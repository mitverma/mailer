let accountSid="ACbc3495679c2e90ac0c6dfbf866f16d2f";
let authToken="081d3f4b51925d9fa9b0916707171b47";
let contact="+15712537237";

const sendSms = (phone, message) => {
    console.log("in send SMS me");
    const client = require('twilio')(accountSid, authToken);
    client.messages
      .create({
         body: message,
         from: contact,
         to: phone
       })
      .then(message => console.log("message.sid",message));
  }
  
  module.exports = sendSms;