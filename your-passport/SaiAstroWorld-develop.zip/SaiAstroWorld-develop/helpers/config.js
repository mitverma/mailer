module.exports = {
    AWS_ACCESS_KEY_ID: 'AKIAJHGHKW2O2Z6D5QDA',
    AWS_SECRET_ACCESS_KEY: '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',
    BUCKET_NAME:'astrofiledata'
  }