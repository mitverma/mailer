const jsonwebtoken = require("jsonwebtoken")
const globalFunctions = require("../helpers/globalFunctions");


module.exports = function (req, res, next) {

	let jwt = req.header("authorization");

	if(!jwt) {
		globalFunctions.out(res, 401, "token not present");
	}
	else {

		jsonwebtoken.verify(jwt, process.env.JWT_SECRET, (err, data) => {

			if(err) return globalFunctions.out(res, 406, "Invalid token", jwt)

			req.body.jwt = data;
			console.log("payload", data)
			next();

		})

	}

}