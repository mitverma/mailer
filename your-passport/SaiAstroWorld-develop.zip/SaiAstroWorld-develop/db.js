//var dbConnect="mongodb://127.0.0.1:27017/astroDB";

//var dbConnect = "mongodb://astroUser:astroUserPass@cluster0-shard-00-00.dflyz.mongodb.net:27017,cluster0-shard-00-01.dflyz.mongodb.net:27017,cluster0-shard-00-02.dflyz.mongodb.net:27017/AstroLive?ssl=true&replicaSet=atlas-oxdy5k-shard-0&authSource=admin&retryWrites=true&w=majority";

var dbConnect = "mongodb://astroUser:astroUserPass@cluster0-shard-00-00.dflyz.mongodb.net:27017,cluster0-shard-00-01.dflyz.mongodb.net:27017,cluster0-shard-00-02.dflyz.mongodb.net:27017/test?ssl=true&replicaSet=atlas-oxdy5k-shard-0&authSource=admin&retryWrites=true&w=majority";
module.exports=dbConnect;

//"mongodb+srv://astroUser:astroUserPass@firstcluster-dflyz.mongodb.net/test?retryWrites=true&w=majority"

