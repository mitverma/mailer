var express = require('express');
var router = express.Router();
path = require('path')
var adminController = require("../controllers/adminController");
const jwt = require('jsonwebtoken');

/* GET home page. */
router.get('/', function(req, res, next) {
  console.log("ithech aloy .....");
  res.send("Node app works here!!....");
});

router.post('/create',function(req,res,next){
  adminController.createAdmin(req,res);
});

router.post('/login',function(req,res,next){
  adminController.login(req,res);
});

router.post('/resetpassword',function(req,res,next){
  adminController.resetPassword(req,res);
});

router.post('/forgotPassword',function(req,res,next){
  adminController.forgotPassword(req,res);
});

router.post('/verifyotp',function(req,res,next){
  adminController.verifyOTP(req,res);
});

router.post('/listOfAstrologers',verifyToken,function(req,res,next){
  adminController.list(req,res);
});

router.post('/getastrologerdetails/:id',verifyToken,(req,res)=>{
  adminController.getAstrologerDetail(req,res);
});

router.post('/acceptApplication',verifyToken,(req,res)=>{
  adminController.acceptApplication(req,res);
});

router.post('/listofadmin',verifyToken,(req,res)=>{
  adminController.listOfAdmins(req,res);
});

router.post('/updateadmin',verifyToken,(req,res)=>{
  adminController.updateAdmin(req,res);
});

router.post('/deleteadmin',verifyToken,(req,res)=>{
  adminController.deleteAdmin(req,res);
});

router.post('/updatePrices',verifyToken,(req,res)=>{
  adminController.updateAstrologerPrices(req,res);
});

router.post('/getreports',verifyToken,(req,res)=>{
  adminController.getAstrologersReports(req,res);
});

router.post('/addinline',(req,res)=>{
  adminController.addComingUser(req,res);
})

router.get('/getcomingusers',(req,res)=>{
  adminController.getAllComngUsers(req,res);
})

router.post('/setpriority',(req,res)=>{
   adminController.setPriority(req,res);
})

//verifyToken
function verifyToken(req,res,next)
{
  const bearer = req.headers['authorization'];
 
  if(typeof bearer !==undefined){
    jwt.verify(req.headers['authorization'], 'secret', (err, verifiedJwt) => {
      if(err){
       // console.log("in ERROR: ",err);
        res.send({status:300,message:err.message})
      }else{
        //res.send(verifiedJwt)
        next();
      }
    })
  }else{
    res.send({status:300, message: "Invalid token"});
  }
}



module.exports = router;
