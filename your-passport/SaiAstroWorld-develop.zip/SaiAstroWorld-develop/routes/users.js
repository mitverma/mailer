var express = require('express');
var router = express.Router();
path = require('path')
var userController = require("../controllers/userController");
var horoscope = require("../controllers/horoscope");
const jwt = require('jsonwebtoken');
/* GET users listing. */

//s3 bucket saving of files
const config = require('../helpers/config');
const aws = require('aws-sdk');
const multer = require('multer');
const multerS3 = require('multer-s3');


const s3 = new aws.S3();

aws.config.update({
  secretAccessKey: config.AWS_SECRET_ACCESS_KEY,
  accessKeyId: config.AWS_ACCESS_KEY_ID,
  region: 'ap-south-1'
});

const fileFilter = (req, file, cb) => {
  if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png' || file.mimetype === 'application/pdf') {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type, only JPEG and PNG is allowed!'), false);
  }
}


const upload = multer({
  fileFilter,
  storage: multerS3({
    s3: s3,
    bucket: 'astrofiledata',
    key: function (req, file, cb) {
      console.log(file);
      cb(null, file.originalname); //use Date.now() for unique file keys
    }
  })
});
//local saving
// var storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, 'public/images/')
//   },
//   filename: function (req, file, cb) {
//     cb(null, Date.now() + path.extname(file.originalname)) //Appending extension
//   }
// })

var storage = multer.memoryStorage();
//var upload = multer({ storage: storage });

router.post('/upload',upload.any(),function(req,res,next){
  console.log("REQ.files: ",req.files);
})

//var upload = multer({ storage: storage });

router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.post('/register',(req,res)=>{
  userController.registerUser(req,res);
});

router.post('/sendmail',(req,res)=>{
  userController.sendEmail(req,res);
});

router.post('/verifyotp',(req,res)=>{
  userController.verifyOtp(req,res);
});

router.post('/login',(req,res)=>{
  userController.login(req,res);
});

router.post('/forgetPwd',(req,res)=>{
  userController.forgotPassword(req,res);
});

router.post('/resetPwd',(req,res)=>{
  userController.resetPassword(req,res);
});

router.post('/updateprofile',verifyToken,upload.any(),(req,res)=>{
  userController.updateUser(req,res);
});

router.post('/getastrologerslist',(req,res)=>{
  userController.getAstrologersList(req,res);
});

router.get('/getastrologerdetails/:id',verifyToken,(req,res)=>{
  userController.getAstrologerDetails(req,res);
});

router.post('/send',(req,res)=>{
  userController.sendSMS(req,res)
});

router.post('/call',(req,res)=>{
  userController.calling(req,res);
});
router.post('/connect/:no',(req,res)=>{
  console.log("conn");
  userController.connect(req,res);
});

router.post('/listOfAstrologers',function(req,res,next){
  userController.listOfAstrologers(req,res);
});

router.post('/askquestion',verifyToken,function(req,res,next){
  userController.askQuestion(req,res);
});

router.post('/sendreport',verifyToken,function(req,res,next){
  userController.sendReport(req,res);
});

router.post('/getquestions',verifyToken,function(req,res,next){
 userController.getQuestions(req,res);
});

router.post('/getreports',verifyToken,function(req,res,next){
  userController.getReports(req,res);
 });

 router.post('/respondReport',verifyToken,upload.any(),function(req,res,next){
    userController.respondReport(req,res);
 });

 router.post('/dailyhoroscope',function(req,res,next){
  horoscope.dailyHOroScope(req,res);
 });

 router.post('/updateStatus',function(req,res){
   userController.updateActiveStatus(req,res);
 });

 router.post('/acceptqueryrequest',function(req,res){
  userController.acceptRequest(req,res);
 });

 router.post('/firebaseid',function(req,res){
   userController.updateFirebaseId(req,res);
 });

 router.post('/retrievecalls',function(req,res){
   userController.retrieveCalls(req,res);
 });

 router.post('/pollingstatus',function(req,res){
   userController.polling(req,res);
 });

 router.post('/notify',verifyToken,function(req,res){
  userController.notifyForMessage(req,res);
 });

 router.post('/deductbalance',verifyToken,function(req,res){
  userController.deductBalance(req,res);
 });

 router.get('/getAmount',function(req,res){
   userController.getAmount(req,res);
 });

 router.post('/filter',function(req,res){
   userController.filterAstrolegers(req,res);
 })
 router.post('/blog',function(req,res){
  userController.userBlog(req,res)
})

router.get('/blog',function(req,res){
  userController.getUserBlog(req,res)
})
router.put('/update/blog',function(req,res){
  userController.updateUserBlog(req,res)
})
router.delete('/delete/blog/post',function(req,res){
  userController.deleteBlogPost(req,res)
})

 router.post('/saveexplang',function(req,res){
   userController.saveLang(req,res);
 });

 router.post('/listexpertise',function(req,res){
   userController.listOfexprtises(req,res);
 });
 //verifyToken
function verifyToken(req,res,next)
{
  const bearer = req.headers['authorization'];
  if(typeof bearer !==undefined){
    jwt.verify(req.headers['authorization'], 'secret', (err, verifiedJwt) => {
      if(err){
        res.send({status:300,message:err.message})
      }else{
        //res.send(verifiedJwt)
        next();
      }
    })
  }else{
    res.send({status:300, message: "Invalid token"});
  }
}
module.exports = router;
